package com.example.data.model

import org.json.JSONArray
import org.json.JSONObject

enum class ColumnType {
    TEXT,
    NUMBER;

    fun toArabicLabel(): String {
        return when (this) {
            TEXT -> "نص"
            NUMBER -> "رقم"
        }
    }

    companion object {
        fun fromString(value: String): ColumnType {
            return try {
                valueOf(value.uppercase())
            } catch (e: Exception) {
                TEXT
            }
        }
    }
}

/**
 * Definition of a dynamic column attached to a specific Sheet.
 */
data class ColumnDefinition(
    val id: String,
    val name: String,
    val type: ColumnType = ColumnType.TEXT
) {
    fun toJson(): JSONObject {
        val obj = JSONObject()
        obj.put("id", id)
        obj.put("name", name)
        obj.put("type", type.name)
        return obj
    }

    companion object {
        fun fromJson(obj: JSONObject): ColumnDefinition {
            return ColumnDefinition(
                id = obj.optString("id", ""),
                name = obj.optString("name", ""),
                type = ColumnType.fromString(obj.optString("type", "TEXT"))
            )
        }

        fun parseList(jsonString: String?): List<ColumnDefinition> {
            if (jsonString.isNullOrBlank()) return emptyList()
            val list = mutableListOf<ColumnDefinition>()
            try {
                val array = JSONArray(jsonString)
                for (i in 0 until array.length()) {
                    val item = array.optJSONObject(i)
                    if (item != null) {
                        list.add(fromJson(item))
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
            return list
        }

        fun listToJsonString(list: List<ColumnDefinition>): String {
            val array = JSONArray()
            for (col in list) {
                array.put(col.toJson())
            }
            return array.toString()
        }
    }
}
