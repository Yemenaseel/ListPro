package com.example.data.model

data class DisplayedPersonItem(
    val person: PersonEntity,
    val sheetTitle: String,
    val isFromActiveSheet: Boolean
)
