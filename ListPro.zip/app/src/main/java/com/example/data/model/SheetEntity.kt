package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "sheets")
data class SheetEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val is_main: Boolean = false,
    val created_at: Long = System.currentTimeMillis(),
    val list_of_dynamic_columns: String = "[]"
) {
    fun getDynamicColumns(): List<ColumnDefinition> {
        return ColumnDefinition.parseList(list_of_dynamic_columns)
    }

    fun withDynamicColumns(columns: List<ColumnDefinition>): SheetEntity {
        return this.copy(list_of_dynamic_columns = ColumnDefinition.listToJsonString(columns))
    }
}
