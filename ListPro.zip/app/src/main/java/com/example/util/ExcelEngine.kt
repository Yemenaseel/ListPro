package com.example.util

import android.content.Context
import android.net.Uri
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.io.OutputStreamWriter
import java.nio.charset.StandardCharsets
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

data class ParsedExcelTable(
    val headers: List<String>,
    val rows: List<List<String>>
)

object ExcelEngine {

    /**
     * Reads an .xlsx file or .csv file from a given content Uri.
     */
    fun readExcel(context: Context, uri: Uri): ParsedExcelTable {
        val inputStream = context.contentResolver.openInputStream(uri)
            ?: throw IllegalArgumentException("تعذر فتح الملف المحدد")
        return readExcel(inputStream)
    }

    /**
     * Parses an .xlsx (or .csv) stream.
     */
    fun readExcel(inputStream: InputStream): ParsedExcelTable {
        val bytes = inputStream.readBytes()

        // Check if file is ZIP (PK.. magic header: 0x50, 0x4B, 0x03, 0x04)
        if (bytes.size >= 4 && bytes[0] == 0x50.toByte() && bytes[1] == 0x4B.toByte()) {
            return parseXlsxFromBytes(bytes)
        } else {
            // Fallback: parse as CSV / Plain Text with auto-detected delimiter (comma, semicolon, tab)
            return parseCsv(String(bytes, StandardCharsets.UTF_8))
        }
    }

    private fun parseXlsxFromBytes(bytes: ByteArray): ParsedExcelTable {
        val sharedStrings = mutableListOf<String>()
        var sheetXmlBytes: ByteArray? = null

        // 1. Pass through ZIP to find sharedStrings.xml and first sheet (sheet1.xml)
        var zis = ZipInputStream(ByteArrayInputStream(bytes))
        var entry: ZipEntry? = zis.nextEntry
        while (entry != null) {
            val name = entry.name
            if (name.contains("sharedStrings.xml", ignoreCase = true)) {
                sharedStrings.addAll(parseSharedStrings(zis.readBytes()))
            } else if (name.contains("sheet1.xml", ignoreCase = true) || (name.contains("sheet", ignoreCase = true) && name.endsWith(".xml") && sheetXmlBytes == null)) {
                sheetXmlBytes = zis.readBytes()
            }
            zis.closeEntry()
            entry = zis.nextEntry
        }
        zis.close()

        if (sheetXmlBytes == null) {
            // Second attempt if names differed
            zis = ZipInputStream(ByteArrayInputStream(bytes))
            entry = zis.nextEntry
            while (entry != null) {
                if (entry.name.endsWith(".xml") && entry.name.contains("worksheets/")) {
                    sheetXmlBytes = zis.readBytes()
                    break
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
            zis.close()
        }

        if (sheetXmlBytes == null) {
            throw IllegalStateException("لم يتم العثور على أوراق عمل داخل ملف الإكسل (XLSX).")
        }

        val rawRows = parseSheetXml(sheetXmlBytes, sharedStrings)
        if (rawRows.isEmpty()) {
            return ParsedExcelTable(headers = emptyList(), rows = emptyList())
        }

        val headerRow = rawRows.first()
        val dataRows = if (rawRows.size > 1) rawRows.subList(1, rawRows.size) else emptyList()

        // Normalize header names
        val headers = headerRow.mapIndexed { idx, col ->
            col.ifBlank { "عمود ${idx + 1}" }
        }

        return ParsedExcelTable(headers = headers, rows = dataRows)
    }

    private fun parseSharedStrings(xmlBytes: ByteArray): List<String> {
        val list = mutableListOf<String>()
        val factory = XmlPullParserFactory.newInstance()
        factory.isNamespaceAware = true
        val parser = factory.newPullParser()
        parser.setInput(ByteArrayInputStream(xmlBytes), "UTF-8")

        var eventType = parser.eventType
        var currentString: StringBuilder? = null
        var inText = false

        while (eventType != XmlPullParser.END_DOCUMENT) {
            when (eventType) {
                XmlPullParser.START_TAG -> {
                    val tagName = parser.name
                    if (tagName == "si") {
                        currentString = StringBuilder()
                    } else if (tagName == "t") {
                        inText = true
                    }
                }
                XmlPullParser.TEXT -> {
                    if (inText && currentString != null) {
                        currentString.append(parser.text)
                    }
                }
                XmlPullParser.END_TAG -> {
                    val tagName = parser.name
                    if (tagName == "t") {
                        inText = false
                    } else if (tagName == "si") {
                        list.add(currentString?.toString() ?: "")
                        currentString = null
                    }
                }
            }
            eventType = parser.next()
        }
        return list
    }

    private fun parseSheetXml(xmlBytes: ByteArray, sharedStrings: List<String>): List<List<String>> {
        val rows = mutableListOf<MutableList<String>>()
        val factory = XmlPullParserFactory.newInstance()
        factory.isNamespaceAware = true
        val parser = factory.newPullParser()
        parser.setInput(ByteArrayInputStream(xmlBytes), "UTF-8")

        var eventType = parser.eventType
        var currentRow: MutableList<String>? = null
        var cellType = ""
        var cellValue: StringBuilder? = null
        var cellColIndex = -1
        var inV = false
        var inInlineStr = false

        while (eventType != XmlPullParser.END_DOCUMENT) {
            when (eventType) {
                XmlPullParser.START_TAG -> {
                    when (parser.name) {
                        "row" -> {
                            currentRow = mutableListOf()
                        }
                        "c" -> {
                            cellType = parser.getAttributeValue(null, "t") ?: ""
                            val cellRef = parser.getAttributeValue(null, "r") ?: ""
                            cellColIndex = parseColumnIndexFromRef(cellRef)
                            cellValue = StringBuilder()
                        }
                        "v" -> inV = true
                        "is" -> inInlineStr = true
                        "t" -> if (inInlineStr) inV = true
                    }
                }
                XmlPullParser.TEXT -> {
                    if (inV && cellValue != null) {
                        cellValue.append(parser.text)
                    }
                }
                XmlPullParser.END_TAG -> {
                    when (parser.name) {
                        "v" -> inV = false
                        "is" -> inInlineStr = false
                        "c" -> {
                            val raw = cellValue?.toString()?.trim() ?: ""
                            val formattedVal = when (cellType) {
                                "s" -> {
                                    val idx = raw.toIntOrNull()
                                    if (idx != null && idx in sharedStrings.indices) {
                                        sharedStrings[idx]
                                    } else raw
                                }
                                "b" -> if (raw == "1") "نعم" else "لا"
                                else -> raw
                            }

                            if (currentRow != null) {
                                // Pad empty cells if column indexes skipped
                                if (cellColIndex >= 0) {
                                    while (currentRow.size < cellColIndex) {
                                        currentRow.add("")
                                    }
                                }
                                currentRow.add(formattedVal)
                            }
                            cellValue = null
                            cellType = ""
                            cellColIndex = -1
                        }
                        "row" -> {
                            if (currentRow != null && currentRow.any { it.isNotBlank() }) {
                                rows.add(currentRow)
                            }
                            currentRow = null
                        }
                    }
                }
            }
            eventType = parser.next()
        }
        return rows
    }

    private fun parseColumnIndexFromRef(ref: String): Int {
        var col = 0
        var i = 0
        while (i < ref.length && ref[i].isLetter()) {
            col = col * 26 + (ref[i].uppercaseChar() - 'A' + 1)
            i++
        }
        return if (col > 0) col - 1 else -1
    }

    private fun parseCsv(csvText: String): ParsedExcelTable {
        val lines = csvText.lines().filter { it.isNotBlank() }
        if (lines.isEmpty()) return ParsedExcelTable(emptyList(), emptyList())

        // Detect delimiter: comma, semicolon, tab
        val firstLine = lines.first()
        val commaCount = firstLine.count { it == ',' }
        val semiCount = firstLine.count { it == ';' }
        val tabCount = firstLine.count { it == '\t' }
        val delimiter = when {
            semiCount > commaCount && semiCount > tabCount -> ';'
            tabCount > commaCount && tabCount > semiCount -> '\t'
            else -> ','
        }

        val rows = lines.map { line ->
            splitCsvLine(line, delimiter)
        }

        val headers = rows.first()
        val dataRows = if (rows.size > 1) rows.subList(1, rows.size) else emptyList()
        return ParsedExcelTable(headers = headers, rows = dataRows)
    }

    private fun splitCsvLine(line: String, delimiter: Char): List<String> {
        val result = mutableListOf<String>()
        val current = StringBuilder()
        var inQuotes = false
        var i = 0
        while (i < line.length) {
            val c = line[i]
            if (c == '"') {
                if (inQuotes && i + 1 < line.length && line[i + 1] == '"') {
                    current.append('"')
                    i++
                } else {
                    inQuotes = !inQuotes
                }
            } else if (c == delimiter && !inQuotes) {
                result.add(current.toString().trim())
                current.clear()
            } else {
                current.append(c)
            }
            i++
        }
        result.add(current.toString().trim())
        return result
    }

    // -------------------------------------------------------------------------
    // Export Operations: XLSX & CSV
    // -------------------------------------------------------------------------

    /**
     * Exports rows to a standard .xlsx format into an OutputStream.
     */
    fun exportToXlsx(headers: List<String>, rows: List<List<String>>, outputStream: OutputStream) {
        val zos = ZipOutputStream(outputStream)

        // 1. [Content_Types].xml
        zos.putNextEntry(ZipEntry("[Content_Types].xml"))
        val contentTypes = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
  <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
  <Override PartName="/xl/sharedStrings.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"/>
</Types>""".trimIndent()
        zos.write(contentTypes.toByteArray(StandardCharsets.UTF_8))
        zos.closeEntry()

        // 2. _rels/.rels
        zos.putNextEntry(ZipEntry("_rels/.rels"))
        val rootRels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>""".trimIndent()
        zos.write(rootRels.toByteArray(StandardCharsets.UTF_8))
        zos.closeEntry()

        // 3. xl/_rels/workbook.xml.rels
        zos.putNextEntry(ZipEntry("xl/_rels/workbook.xml.rels"))
        val wbRels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings" Target="sharedStrings.xml"/>
</Relationships>""".trimIndent()
        zos.write(wbRels.toByteArray(StandardCharsets.UTF_8))
        zos.closeEntry()

        // 4. xl/workbook.xml
        zos.putNextEntry(ZipEntry("xl/workbook.xml"))
        val workbook = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <sheets>
    <sheet name="Sheet1" sheetId="1" r:id="rId1"/>
  </sheets>
</workbook>""".trimIndent()
        zos.write(workbook.toByteArray(StandardCharsets.UTF_8))
        zos.closeEntry()

        // Build shared strings list
        val sharedStrings = mutableListOf<String>()
        val stringMap = mutableMapOf<String, Int>()

        fun getStringIndex(s: String): Int {
            return stringMap.getOrPut(s) {
                val idx = sharedStrings.size
                sharedStrings.add(s)
                idx
            }
        }

        // Prepopulate strings from headers and rows
        for (h in headers) getStringIndex(h)
        for (r in rows) {
            for (c in r) getStringIndex(c)
        }

        // 5. xl/worksheets/sheet1.xml
        zos.putNextEntry(ZipEntry("xl/worksheets/sheet1.xml"))
        val sheetXml = StringBuilder()
        sheetXml.append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <sheetViews>
    <sheetView tabSelected="1" workbookViewId="0" rightToLeft="1"/>
  </sheetViews>
  <sheetData>
""")

        // Header row (row 1)
        sheetXml.append("""    <row r="1">""").append("\n")
        headers.forEachIndexed { colIdx, h ->
            val ref = "${getColLetter(colIdx + 1)}1"
            val sIdx = getStringIndex(h)
            sheetXml.append("""      <c r="$ref" t="s"><v>$sIdx</v></c>""").append("\n")
        }
        sheetXml.append("""    </row>""").append("\n")

        // Data rows (row 2..)
        rows.forEachIndexed { rowIdx, rowData ->
            val rNum = rowIdx + 2
            sheetXml.append("""    <row r="$rNum">""").append("\n")
            rowData.forEachIndexed { colIdx, cellVal ->
                val ref = "${getColLetter(colIdx + 1)}$rNum"
                val sIdx = getStringIndex(cellVal)
                sheetXml.append("""      <c r="$ref" t="s"><v>$sIdx</v></c>""").append("\n")
            }
            sheetXml.append("""    </row>""").append("\n")
        }

        sheetXml.append("""  </sheetData>
</worksheet>""")
        zos.write(sheetXml.toString().toByteArray(StandardCharsets.UTF_8))
        zos.closeEntry()

        // 6. xl/sharedStrings.xml
        zos.putNextEntry(ZipEntry("xl/sharedStrings.xml"))
        val ssXml = StringBuilder()
        ssXml.append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="${sharedStrings.size}" uniqueCount="${sharedStrings.size}">
""")
        for (str in sharedStrings) {
            val escaped = escapeXml(str)
            ssXml.append("""  <si><t xml:space="preserve">$escaped</t></si>""").append("\n")
        }
        ssXml.append("</sst>")
        zos.write(ssXml.toString().toByteArray(StandardCharsets.UTF_8))
        zos.closeEntry()

        zos.finish()
        zos.flush()
    }

    /**
     * Exports data to CSV with UTF-8 BOM so Excel opens Arabic correctly.
     */
    fun exportToCsv(headers: List<String>, rows: List<List<String>>, outputStream: OutputStream) {
        val writer = OutputStreamWriter(outputStream, StandardCharsets.UTF_8)
        // Write UTF-8 BOM: \uFEFF
        writer.write("\uFEFF")

        // Write header
        writer.write(headers.joinToString(",") { escapeCsvCell(it) })
        writer.write("\r\n")

        // Write rows
        for (row in rows) {
            writer.write(row.joinToString(",") { escapeCsvCell(it) })
            writer.write("\r\n")
        }
        writer.flush()
    }

    private fun escapeCsvCell(cell: String): String {
        return if (cell.contains(",") || cell.contains("\"") || cell.contains("\n") || cell.contains("\r")) {
            "\"" + cell.replace("\"", "\"\"") + "\""
        } else {
            cell
        }
    }

    private fun escapeXml(str: String): String {
        return str.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
            .replace("'", "&apos;")
    }

    private fun getColLetter(colNum: Int): String {
        var num = colNum
        val sb = StringBuilder()
        while (num > 0) {
            val rem = (num - 1) % 26
            sb.append(('A'.code + rem).toChar())
            num = (num - 1) / 26
        }
        return sb.reverse().toString()
    }
}
