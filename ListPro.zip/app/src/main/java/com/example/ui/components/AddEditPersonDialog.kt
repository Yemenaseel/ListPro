package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.DriveFileMove
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.ColumnType
import com.example.data.model.PersonEntity
import com.example.data.model.SheetEntity
import com.example.data.repository.DuplicateCheckResult
import com.example.ui.theme.AmberTertiary
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.TealSecondary

@Composable
fun AddEditPersonDialog(
    personToEdit: PersonEntity? = null,
    activeSheet: SheetEntity,
    allSheets: List<SheetEntity>,
    onDismiss: () -> Unit,
    onSavePerson: (
        primaryName: String,
        cardId: String?,
        dynamicData: Map<String, String>,
        forceCurrentSheetDuplicate: Boolean,
        onDuplicate: (DuplicateCheckResult) -> Unit,
        onSuccess: (String) -> Unit
    ) -> Unit,
    onMovePerson: (personId: Long, targetSheetId: Long) -> Unit
) {
    var primaryName by remember { mutableStateOf(personToEdit?.primary_name ?: "") }
    var uniqueCardId by remember { mutableStateOf(personToEdit?.unique_card_id ?: "") }

    val dynamicValues = remember {
        mutableStateMapOf<String, String>().apply {
            personToEdit?.let { putAll(it.getDynamicData()) }
        }
    }

    var errorMessage by remember { mutableStateOf<String?>(null) }
    var currentSheetDuplicateWarning by remember { mutableStateOf<String?>(null) }
    var showMoveDialog by remember { mutableStateOf(false) }

    val columns = activeSheet.getDynamicColumns()

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .heightIn(max = 680.dp)
                .imePadding(),
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (personToEdit == null) "إضافة شخص جديد" else "تعديل بيانات الشخص",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = NavyPrimary
                            )
                        )
                        Text(
                            text = "الكشف: ${activeSheet.title}",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Outlined.Close,
                            contentDescription = "إغلاق"
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Scrollable content
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                ) {
                    // Error Banner (Rejection for other sheet or card clash)
                    if (errorMessage != null) {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.errorContainer
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Error,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.error
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = errorMessage!!,
                                    color = MaterialTheme.colorScheme.onErrorContainer,
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium)
                                )
                            }
                        }
                    }

                    // Warning Banner (Duplicate in Current Sheet)
                    if (currentSheetDuplicateWarning != null) {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.secondaryContainer
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Warning,
                                        contentDescription = null,
                                        tint = AmberTertiary
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = currentSheetDuplicateWarning!!,
                                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                                    )
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Button(
                                    onClick = {
                                        // Force save despite duplicate in current sheet
                                        onSavePerson(
                                            primaryName,
                                            uniqueCardId,
                                            dynamicValues,
                                            true,
                                            { /* duplicate ignored */ },
                                            { onDismiss() }
                                        )
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = AmberTertiary
                                    ),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("تأكيد الحفظ رغم التكرار في الكشف الحالي")
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Permanent Field 1: الاسم الرباعي (Mandatory)
                    OutlinedTextField(
                        value = primaryName,
                        onValueChange = {
                            primaryName = it
                            errorMessage = null
                            currentSheetDuplicateWarning = null
                        },
                        label = { Text("الاسم الرباعي (إجباري) *") },
                        placeholder = { Text("مثال: محمد أحمد عبد الله علي") },
                        leadingIcon = {
                            Icon(Icons.Default.Person, contentDescription = null, tint = NavyPrimary)
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("primary_name_input")
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Permanent Field 2: رقم البطاقة (Optional)
                    OutlinedTextField(
                        value = uniqueCardId,
                        onValueChange = {
                            uniqueCardId = it
                            errorMessage = null
                        },
                        label = { Text("رقم البطاقة (اختياري - فريد)") },
                        placeholder = { Text("أدخل رقم الهوية أو البطاقة...") },
                        leadingIcon = {
                            Icon(Icons.Default.Badge, contentDescription = null, tint = TealSecondary)
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("card_id_input")
                    )

                    // Dynamic Fields Section
                    if (columns.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "الحقول الإضافية للكشف:",
                            style = MaterialTheme.typography.labelLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        for (col in columns) {
                            val currentVal = dynamicValues[col.id] ?: ""
                            val isNumeric = col.type == ColumnType.NUMBER

                            OutlinedTextField(
                                value = currentVal,
                                onValueChange = { dynamicValues[col.id] = it },
                                label = { Text("${col.name} (${col.type.toArabicLabel()})") },
                                keyboardOptions = KeyboardOptions(
                                    keyboardType = if (isNumeric) KeyboardType.Number else KeyboardType.Text
                                ),
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 5.dp)
                            )
                        }
                    }

                    // Move to another sheet button (Edit mode only)
                    if (personToEdit != null && allSheets.size > 1) {
                        Spacer(modifier = Modifier.height(18.dp))
                        OutlinedButton(
                            onClick = { showMoveDialog = true },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.DriveFileMove, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("نقل هذا الشخص إلى كشف آخر")
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Bottom Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("إلغاء")
                    }

                    Button(
                        onClick = {
                            if (primaryName.trim().isBlank()) {
                                errorMessage = "يرجى إدخال الاسم الرباعي."
                                return@Button
                            }

                            onSavePerson(
                                primaryName,
                                uniqueCardId,
                                dynamicValues,
                                false,
                                { duplicateResult ->
                                    when (duplicateResult) {
                                        is DuplicateCheckResult.CardDuplicate -> {
                                            errorMessage = duplicateResult.message
                                        }
                                        is DuplicateCheckResult.OtherSheetNameDuplicate -> {
                                            errorMessage = duplicateResult.message
                                        }
                                        is DuplicateCheckResult.CurrentSheetDuplicate -> {
                                            currentSheetDuplicateWarning = "تنبيه: الاسم مكرر في الكشف الحالي."
                                        }
                                        is DuplicateCheckResult.Valid -> {}
                                    }
                                },
                                {
                                    onDismiss()
                                }
                            )
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("save_person_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary)
                    ) {
                        Text("حفظ البيانات")
                    }
                }
            }
        }
    }

    // Move to another sheet selection dialog
    if (showMoveDialog && personToEdit != null) {
        val targetSheets = allSheets.filterNot { it.id == activeSheet.id }
        var selectedSheetId by remember { mutableStateOf(targetSheets.firstOrNull()?.id ?: 0L) }

        AlertDialog(
            onDismissRequest = { showMoveDialog = false },
            title = { Text("اختر الكشف المراد النقل إليه") },
            text = {
                Column {
                    Text("سيتم نقل السجل '${personToEdit.primary_name}' إلى الكشف المحدد:")
                    Spacer(modifier = Modifier.height(12.dp))
                    for (sheet in targetSheets) {
                        Surface(
                            onClick = { selectedSheetId = sheet.id },
                            shape = RoundedCornerShape(8.dp),
                            color = if (selectedSheetId == sheet.id) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Text(
                                text = sheet.title,
                                modifier = Modifier.padding(12.dp),
                                fontWeight = if (selectedSheetId == sheet.id) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onMovePerson(personToEdit.id, selectedSheetId)
                        showMoveDialog = false
                        onDismiss()
                    }
                ) {
                    Text("نقل الآن")
                }
            },
            dismissButton = {
                TextButton(onClick = { showMoveDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }
}
