package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DriveFileMove
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.GroupAdd
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SearchOff
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.DisplayedPersonItem
import com.example.data.model.PersonEntity
import com.example.data.model.SheetEntity
import com.example.ui.components.BulkMoveSheetDialog
import com.example.ui.theme.AmberTertiary
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.NavyPrimaryVariant
import com.example.ui.theme.TealSecondary
import com.example.ui.viewmodel.PersonFilter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

private val AVATAR_GRADIENTS = listOf(
    listOf(Color(0xFF1E3A8A), Color(0xFF3B82F6)), // Navy - Blue
    listOf(Color(0xFF0F766E), Color(0xFF14B8A6)), // Teal - Cyan
    listOf(Color(0xFF7C2D12), Color(0xFFEA580C)), // Rust - Orange
    listOf(Color(0xFF4C1D95), Color(0xFF8B5CF6)), // Indigo - Purple
    listOf(Color(0xFF14532D), Color(0xFF22C55E)), // Forest - Emerald
    listOf(Color(0xFF831843), Color(0xFFEC4899))  // Berry - Pink
)

private fun getInitials(name: String): String {
    val clean = name.trim().split(Regex("\\s+")).filter { it.isNotBlank() }
    return when {
        clean.isEmpty() -> "؟"
        clean.size == 1 -> clean[0].take(1)
        else -> "${clean[0].take(1)}.${clean.last().take(1)}"
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class, ExperimentalLayoutApi::class)
@Composable
fun RecordsScreen(
    activeSheet: SheetEntity?,
    availableSheets: List<SheetEntity>,
    displayedPersons: List<DisplayedPersonItem>,
    searchQuery: String,
    filterMode: PersonFilter,
    onSearchChange: (String) -> Unit,
    onFilterChange: (PersonFilter) -> Unit,
    onBack: () -> Unit,
    onAddPersonClick: () -> Unit,
    onBulkAddClick: () -> Unit,
    onEditPersonClick: (PersonEntity) -> Unit,
    onDeletePerson: (PersonEntity) -> Unit,
    onMovePersonClick: (PersonEntity) -> Unit,
    onBulkMovePersons: (personIds: List<Long>, targetSheetId: Long) -> Unit,
    onBulkDeletePersons: (personIds: List<Long>) -> Unit
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    // Multi-Selection State
    var isMultiSelectMode by remember { mutableStateOf(false) }
    var selectedIds by remember { mutableStateOf(setOf<Long>()) }

    var personToDelete by remember { mutableStateOf<PersonEntity?>(null) }
    var showBulkMoveDialog by remember { mutableStateOf(false) }
    var showBulkDeleteConfirmDialog by remember { mutableStateOf(false) }

    val isGlobalSearchActive = searchQuery.isNotBlank()

    Scaffold(
        topBar = {
            if (isMultiSelectMode) {
                // Contextual Multi-Selection TopAppBar
                TopAppBar(
                    title = {
                        Text(
                            text = "تم تحديد ${selectedIds.size} من أصل ${displayedPersons.size}",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = {
                            isMultiSelectMode = false
                            selectedIds = emptySet()
                        }) {
                            Icon(Icons.Default.Close, contentDescription = "إلغاء التحديد")
                        }
                    },
                    actions = {
                        // Select All / Deselect All
                        IconButton(onClick = {
                            selectedIds = if (selectedIds.size == displayedPersons.size) {
                                emptySet()
                            } else {
                                displayedPersons.map { it.person.id }.toSet()
                            }
                        }) {
                            Icon(Icons.Default.SelectAll, contentDescription = "تحديد الكل")
                        }

                        // Bulk Move button
                        IconButton(
                            onClick = { showBulkMoveDialog = true },
                            enabled = selectedIds.isNotEmpty()
                        ) {
                            Icon(Icons.Default.DriveFileMove, contentDescription = "نقل لكشف آخر", tint = NavyPrimary)
                        }

                        // Bulk Delete button
                        IconButton(
                            onClick = { showBulkDeleteConfirmDialog = true },
                            enabled = selectedIds.isNotEmpty()
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = "حذف المحدد", tint = MaterialTheme.colorScheme.error)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer
                    )
                )
            } else {
                // Standard TopAppBar
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = if (isGlobalSearchActive) "البحث الشامل في الكشوفات" else (activeSheet?.title ?: "قائمة الأسماء والسجلات"),
                                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "${displayedPersons.size} سجل معروض",
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                        }
                    },
                    actions = {
                        // Enter selection mode button
                        IconButton(
                            onClick = { isMultiSelectMode = true },
                            modifier = Modifier.testTag("multi_select_button")
                        ) {
                            Icon(Icons.Default.Checklist, contentDescription = "تحديد متعدد")
                        }

                        FilledTonalButton(
                            onClick = onBulkAddClick,
                            modifier = Modifier
                                .padding(end = 8.dp)
                                .testTag("bulk_add_button"),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.GroupAdd,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp),
                                tint = TealSecondary
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "إضافة جماعية",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TealSecondary
                                )
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
            }
        },
        floatingActionButton = {
            if (!isMultiSelectMode) {
                FloatingActionButton(
                    onClick = onAddPersonClick,
                    containerColor = NavyPrimary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.testTag("fab_add_person")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "إضافة شخص")
                }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .imePadding(),
            contentPadding = PaddingValues(bottom = 88.dp)
        ) {
            // ==========================================
            // Sticky Search & Real-time Filter Bar
            // ==========================================
            stickyHeader {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    shadowElevation = 4.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 10.dp)
                    ) {
                        // Search Bar TextField
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = onSearchChange,
                            placeholder = { Text("ابحث بالاسم أو رقم البطاقة في جميع الكشوفات...") },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.Search,
                                    contentDescription = "بحث",
                                    tint = if (isGlobalSearchActive) NavyPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            },
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(onClick = { onSearchChange("") }) {
                                        Icon(
                                            imageVector = Icons.Default.Clear,
                                            contentDescription = "مسح البحث"
                                        )
                                    }
                                }
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(16.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = NavyPrimary,
                                unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("search_text_field")
                        )

                        // Global Search Indicator Banner
                        if (isGlobalSearchActive) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Surface(
                                color = NavyPrimary.copy(alpha = 0.08f),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        Icons.Default.Search,
                                        contentDescription = null,
                                        tint = NavyPrimary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "البحث نشط عبر كافة الكشوفات: تم العثور على ${displayedPersons.size} نتيجة",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = NavyPrimary
                                        )
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Filter Chips Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            FilterChip(
                                selected = filterMode == PersonFilter.ALL,
                                onClick = { onFilterChange(PersonFilter.ALL) },
                                label = { Text("الكل") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = NavyPrimary,
                                    selectedLabelColor = Color.White
                                )
                            )
                            FilterChip(
                                selected = filterMode == PersonFilter.WITH_CARD,
                                onClick = { onFilterChange(PersonFilter.WITH_CARD) },
                                label = { Text("مع بطاقة") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = TealSecondary,
                                    selectedLabelColor = Color.White
                                )
                            )
                            FilterChip(
                                selected = filterMode == PersonFilter.WITHOUT_CARD,
                                onClick = { onFilterChange(PersonFilter.WITHOUT_CARD) },
                                label = { Text("بدون بطاقة") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = AmberTertiary,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }
                }
            }

            // ==========================================
            // Empty State
            // ==========================================
            if (displayedPersons.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 24.dp, vertical = 64.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Surface(
                                modifier = Modifier.size(80.dp),
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = if (searchQuery.isNotEmpty()) Icons.Default.SearchOff else Icons.Default.Person,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.outline,
                                        modifier = Modifier.size(40.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            Text(
                                text = if (searchQuery.isNotEmpty()) "لا توجد نتائج مطابقة في أي كشف" else "الكشف فارغ حالياً",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            Text(
                                text = if (searchQuery.isNotEmpty())
                                    "تأكد من كتابة الاسم أو رقم البطاقة بشكل صحيح أو جرب كلمات أخرى"
                                else
                                    "اضغط على زر (+) لإضافة أول شخص أو استورد السجلات من ملف إكسل",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                ),
                                modifier = Modifier.padding(horizontal = 16.dp)
                            )

                            Spacer(modifier = Modifier.height(20.dp))

                            if (searchQuery.isNotEmpty()) {
                                OutlinedButton(onClick = { onSearchChange("") }) {
                                    Text("مسح البحث وعرض الكل")
                                }
                            }
                        }
                    }
                }
            } else {
                // ==========================================
                // Cards for Persons
                // ==========================================
                items(displayedPersons, key = { it.person.id }) { item ->
                    val person = item.person
                    val isSelected = selectedIds.contains(person.id)
                    val gradientIdx = abs(person.primary_name.hashCode()) % AVATAR_GRADIENTS.size
                    val avatarGradient = AVATAR_GRADIENTS[gradientIdx]

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp)
                    ) {
                        ElevatedCard(
                            modifier = Modifier
                                .fillMaxWidth()
                                .combinedClickable(
                                    onClick = {
                                        if (isMultiSelectMode) {
                                            selectedIds = if (isSelected) selectedIds - person.id else selectedIds + person.id
                                        } else {
                                            onEditPersonClick(person)
                                        }
                                    },
                                    onLongClick = {
                                        if (!isMultiSelectMode) {
                                            isMultiSelectMode = true
                                            selectedIds = setOf(person.id)
                                        } else {
                                            selectedIds = if (isSelected) selectedIds - person.id else selectedIds + person.id
                                        }
                                    }
                                )
                                .testTag("person_card_${person.id}"),
                            shape = RoundedCornerShape(20.dp),
                            elevation = androidx.compose.material3.CardDefaults.elevatedCardElevation(
                                defaultElevation = if (isSelected) 6.dp else 2.dp
                            ),
                            colors = androidx.compose.material3.CardDefaults.elevatedCardColors(
                                containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
                            )
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp)
                            ) {
                                // Top row: Checkbox (if multi-select) + Avatar + Primary Name + Card Badge
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    if (isMultiSelectMode) {
                                        Checkbox(
                                            checked = isSelected,
                                            onCheckedChange = { checked ->
                                                selectedIds = if (checked) selectedIds + person.id else selectedIds - person.id
                                            },
                                            colors = CheckboxDefaults.colors(checkedColor = NavyPrimary)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                    }

                                    // Initials Avatar
                                    Box(
                                        modifier = Modifier
                                            .size(46.dp)
                                            .clip(CircleShape)
                                            .background(Brush.linearGradient(avatarGradient)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = getInitials(person.primary_name),
                                            style = MaterialTheme.typography.titleSmall.copy(
                                                color = Color.White,
                                                fontWeight = FontWeight.Bold
                                            )
                                        )
                                    }

                                    Spacer(modifier = Modifier.width(12.dp))

                                    // Name and creation date
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = person.primary_name,
                                            style = MaterialTheme.typography.titleMedium.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                        )
                                        Text(
                                            text = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault()).format(Date(person.timestamp)),
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = MaterialTheme.colorScheme.outline
                                            )
                                        )
                                    }

                                    // Unique Card Pill Badge
                                    if (!person.unique_card_id.isNullOrBlank()) {
                                        Surface(
                                            color = TealSecondary.copy(alpha = 0.12f),
                                            shape = RoundedCornerShape(10.dp),
                                            modifier = Modifier.clickable {
                                                clipboardManager.setText(AnnotatedString(person.unique_card_id))
                                                Toast.makeText(context, "تم نسخ رقم البطاقة", Toast.LENGTH_SHORT).show()
                                            }
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                            ) {
                                                Icon(
                                                    Icons.Default.Badge,
                                                    contentDescription = null,
                                                    tint = TealSecondary,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text(
                                                    text = person.unique_card_id,
                                                    style = MaterialTheme.typography.labelMedium.copy(
                                                        color = TealSecondary,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                )
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Icon(
                                                    Icons.Default.ContentCopy,
                                                    contentDescription = "نسخ رقم البطاقة",
                                                    tint = TealSecondary.copy(alpha = 0.7f),
                                                    modifier = Modifier.size(14.dp)
                                                )
                                            }
                                        }
                                    } else {
                                        Surface(
                                            color = MaterialTheme.colorScheme.surfaceVariant,
                                            shape = RoundedCornerShape(10.dp)
                                        ) {
                                            Text(
                                                text = "بدون بطاقة",
                                                style = MaterialTheme.typography.labelSmall.copy(
                                                    color = MaterialTheme.colorScheme.outline
                                                ),
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                            )
                                        }
                                    }
                                }

                                // Crucial Sheet Indicator Badge (Prominently shows which sheet the person belongs to!)
                                if (isGlobalSearchActive || !item.isFromActiveSheet || activeSheet == null) {
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Surface(
                                        color = if (item.isFromActiveSheet) TealSecondary.copy(alpha = 0.15f) else AmberTertiary.copy(alpha = 0.2f),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Folder,
                                                contentDescription = null,
                                                modifier = Modifier.size(14.dp),
                                                tint = if (item.isFromActiveSheet) TealSecondary else AmberTertiary
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = "الكشف: ${item.sheetTitle}",
                                                style = MaterialTheme.typography.labelSmall.copy(
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (item.isFromActiveSheet) TealSecondary else AmberTertiary
                                                )
                                            )
                                        }
                                    }
                                }

                                // Dynamic fields chips
                                val dynamicData = person.getDynamicData()
                                if (dynamicData.isNotEmpty()) {
                                    Spacer(modifier = Modifier.height(12.dp))
                                    FlowRow(
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        verticalArrangement = Arrangement.spacedBy(6.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        dynamicData.forEach { (colId, valStr) ->
                                            if (valStr.isNotBlank()) {
                                                Surface(
                                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                                                    shape = RoundedCornerShape(8.dp)
                                                ) {
                                                    Row(
                                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Text(
                                                            text = valStr,
                                                            style = MaterialTheme.typography.labelSmall.copy(
                                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                                            )
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }

                                // Action Buttons (shown only when not in multi-selection mode)
                                if (!isMultiSelectMode) {
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.End,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        // Edit
                                        IconButton(
                                            onClick = { onEditPersonClick(person) },
                                            modifier = Modifier.size(36.dp)
                                        ) {
                                            Icon(
                                                Icons.Default.Edit,
                                                contentDescription = "تعديل",
                                                tint = NavyPrimaryVariant,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }

                                        Spacer(modifier = Modifier.width(6.dp))

                                        // Move
                                        IconButton(
                                            onClick = { onMovePersonClick(person) },
                                            modifier = Modifier.size(36.dp)
                                        ) {
                                            Icon(
                                                Icons.Default.DriveFileMove,
                                                contentDescription = "نقل لكشف آخر",
                                                tint = TealSecondary,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }

                                        Spacer(modifier = Modifier.width(6.dp))

                                        // Delete (Soft delete to Recycle Bin)
                                        IconButton(
                                            onClick = { personToDelete = person },
                                            modifier = Modifier.size(36.dp)
                                        ) {
                                            Icon(
                                                Icons.Default.Delete,
                                                contentDescription = "حذف إلى السلة",
                                                tint = MaterialTheme.colorScheme.error,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Single Delete confirmation
    if (personToDelete != null) {
        AlertDialog(
            onDismissRequest = { personToDelete = null },
            title = { Text("حذف السجل") },
            text = { Text("هل تريد نقل '${personToDelete!!.primary_name}' إلى سلة المحذوفات؟ يمكنك استرجاعه في أي وقت.") },
            confirmButton = {
                Button(
                    onClick = {
                        onDeletePerson(personToDelete!!)
                        personToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("نقل للسلة")
                }
            },
            dismissButton = {
                TextButton(onClick = { personToDelete = null }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // Bulk Delete confirmation
    if (showBulkDeleteConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showBulkDeleteConfirmDialog = false },
            title = { Text("حذف السجلات المحددة") },
            text = { Text("هل تريد نقل ${selectedIds.size} سجلات محددة إلى سلة المحذوفات؟") },
            confirmButton = {
                Button(
                    onClick = {
                        onBulkDeletePersons(selectedIds.toList())
                        selectedIds = emptySet()
                        isMultiSelectMode = false
                        showBulkDeleteConfirmDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("نعم، حذف الكل للسلة")
                }
            },
            dismissButton = {
                TextButton(onClick = { showBulkDeleteConfirmDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // Bulk Move Dialog
    if (showBulkMoveDialog) {
        BulkMoveSheetDialog(
            selectedCount = selectedIds.size,
            currentSheetId = activeSheet?.id,
            availableSheets = availableSheets,
            onDismiss = { showBulkMoveDialog = false },
            onConfirmMove = { targetSheetId ->
                onBulkMovePersons(selectedIds.toList(), targetSheetId)
                selectedIds = emptySet()
                isMultiSelectMode = false
                showBulkMoveDialog = false
            }
        )
    }
}
