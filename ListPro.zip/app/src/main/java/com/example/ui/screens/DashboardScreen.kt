package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ViewColumn
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PersonEntity
import com.example.data.model.SheetEntity
import com.example.ui.theme.AmberTertiary
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.TealSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    activeSheet: SheetEntity?,
    sheets: List<SheetEntity>,
    personsInActiveSheet: List<PersonEntity>,
    isImporting: Boolean,
    importSummaryMessage: String?,
    onClearImportSummary: () -> Unit,
    onOpenSheetSelector: () -> Unit,
    onNavigateToAddPerson: () -> Unit,
    onNavigateToRecords: () -> Unit,
    onNavigateToImportExcel: () -> Unit,
    onNavigateToExport: () -> Unit,
    onNavigateToColumns: () -> Unit,
    onNavigateToStatistics: () -> Unit,
    onNavigateToBackup: () -> Unit,
    onChangePasswordClick: () -> Unit,
    onLogout: () -> Unit
) {
    val totalInActiveSheet = personsInActiveSheet.size
    val withCardInActiveSheet = personsInActiveSheet.count { !it.unique_card_id.isNullOrBlank() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape),
                            color = NavyPrimary
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    Icons.Default.Description,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onPrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "إدارة الكشوفات والأسماء",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "قاعدة بيانات محلية متقدمة",
                                style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                            )
                        }
                    }
                },
                actions = {
                    IconButton(onClick = onChangePasswordClick, modifier = Modifier.testTag("change_password_button")) {
                        Icon(Icons.Default.VpnKey, contentDescription = "تغيير كلمة المرور", tint = NavyPrimary)
                    }
                    IconButton(onClick = onLogout, modifier = Modifier.testTag("logout_button")) {
                        Icon(Icons.Default.Logout, contentDescription = "تسجيل الخروج", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
    ) { padding ->
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Import Summary notification banner
            if (importSummaryMessage != null) {
                item(span = { GridItemSpan(2) }) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onClearImportSummary() },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Outlined.CheckCircle, contentDescription = null, tint = NavyPrimary)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = importSummaryMessage,
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold, color = NavyPrimary),
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // Active Sheet Header Card
            item(span = { GridItemSpan(2) }) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("active_sheet_card"),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = NavyPrimary
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                color = Color.White.copy(alpha = 0.2f),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = "الكشف النشط الحالي",
                                    color = Color.White,
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }

                            // Sheet Switcher Dropdown button
                            Surface(
                                onClick = onOpenSheetSelector,
                                shape = RoundedCornerShape(10.dp),
                                color = Color.White.copy(alpha = 0.15f),
                                modifier = Modifier.testTag("switch_sheet_button")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "تبديل الكشف",
                                        color = Color.White,
                                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold)
                                    )
                                    Icon(
                                        Icons.Outlined.KeyboardArrowDown,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = activeSheet?.title ?: "الكشف الأساسي",
                            style = MaterialTheme.typography.headlineSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // Stats counters row inside header
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            QuickCountBadge(
                                label = "الأشخاص المسجلين",
                                value = "$totalInActiveSheet",
                                modifier = Modifier.weight(1f)
                            )
                            QuickCountBadge(
                                label = "يحملون بطاقة",
                                value = "$withCardInActiveSheet",
                                modifier = Modifier.weight(1f)
                            )
                            QuickCountBadge(
                                label = "الأعمدة المخصصة",
                                value = "${activeSheet?.getDynamicColumns()?.size ?: 0}",
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // Section Label
            item(span = { GridItemSpan(2) }) {
                Text(
                    text = "لوحة التحكم والعمليات السريعة:",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    ),
                    modifier = Modifier.padding(top = 4.dp)
                )
            }

            // 1. Add Person Action Card
            item {
                DashboardActionCard(
                    title = "إضافة شخص",
                    subtitle = "تسجيل شخص جديد في الكشف",
                    icon = Icons.Default.PersonAdd,
                    accentColor = NavyPrimary,
                    testTag = "action_add_person",
                    onClick = onNavigateToAddPerson
                )
            }

            // 2. Search & List Action Card
            item {
                DashboardActionCard(
                    title = "البحث والسجلات",
                    subtitle = "عرض وتصفية سجلات الكشف",
                    icon = Icons.Default.Search,
                    accentColor = TealSecondary,
                    testTag = "action_search_records",
                    onClick = onNavigateToRecords
                )
            }

            // 3. Bulk Excel Import Action Card
            item {
                DashboardActionCard(
                    title = "استيراد إكسل",
                    subtitle = "استيراد ملف .xlsx ومطابقة الأعمدة",
                    icon = Icons.Default.FileUpload,
                    accentColor = TealSecondary,
                    testTag = "action_bulk_import",
                    isLoading = isImporting,
                    onClick = onNavigateToImportExcel
                )
            }

            // 4. Export Action Card
            item {
                DashboardActionCard(
                    title = "تصدير البيانات",
                    subtitle = "تصدير إلى Excel, CSV, PDF",
                    icon = Icons.Default.FileDownload,
                    accentColor = NavyPrimary,
                    testTag = "action_export_data",
                    onClick = onNavigateToExport
                )
            }

            // 5. Manage Columns Action Card
            item {
                DashboardActionCard(
                    title = "إدارة الأعمدة",
                    subtitle = "إضافة وتعديل وحذف الحقول",
                    icon = Icons.Default.ViewColumn,
                    accentColor = AmberTertiary,
                    testTag = "action_manage_columns",
                    onClick = onNavigateToColumns
                )
            }

            // 6. Statistics Action Card
            item {
                DashboardActionCard(
                    title = "الإحصائيات",
                    subtitle = "إحصائيات الكشف والإجمالي العام",
                    icon = Icons.Default.Insights,
                    accentColor = NavyPrimary,
                    testTag = "action_statistics",
                    onClick = onNavigateToStatistics
                )
            }

            // 7. Backup & Restore Action Card
            item {
                DashboardActionCard(
                    title = "النسخ الاحتياطي",
                    subtitle = "تصدير واستعادة كامل النظام JSON",
                    icon = Icons.Default.Backup,
                    accentColor = TealSecondary,
                    testTag = "action_backup_sync",
                    onClick = onNavigateToBackup
                )
            }

            // 8. Manage Sheets Action Card
            item {
                DashboardActionCard(
                    title = "إدارة الكشوفات",
                    subtitle = "إنشاء وتبديل وتعديل الكشوفات",
                    icon = Icons.Default.Description,
                    accentColor = AmberTertiary,
                    testTag = "action_manage_sheets",
                    onClick = onOpenSheetSelector
                )
            }

            item(span = { GridItemSpan(2) }) {
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

@Composable
private fun QuickCountBadge(
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Surface(
        color = Color.White.copy(alpha = 0.15f),
        shape = RoundedCornerShape(10.dp),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(
                    color = Color.White.copy(alpha = 0.8f),
                    fontSize = 10.sp
                )
            )
        }
    }
}

@Composable
private fun DashboardActionCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color,
    testTag: String,
    isLoading: Boolean = false,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .height(140.dp)
            .testTag(testTag),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = accentColor.copy(alpha = 0.14f),
                    modifier = Modifier.size(42.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        if (isLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                strokeWidth = 2.dp,
                                color = accentColor
                            )
                        } else {
                            Icon(
                                imageVector = icon,
                                contentDescription = null,
                                tint = accentColor,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }
                }
            }

            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 11.sp
                    ),
                    maxLines = 2
                )
            }
        }
    }
}
