package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DriveFileMove
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.GroupAdd
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PersonOff
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SearchOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.PersonEntity
import com.example.data.model.SheetEntity
import com.example.ui.theme.AmberTertiary
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.NavyPrimaryVariant
import com.example.ui.theme.TealSecondary
import com.example.ui.viewmodel.PersonFilter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

private val AVATAR_GRADIENTS = listOf(
    listOf(Color(0xFF1E3A8A), Color(0xFF3B82F6)), // Navy - Blue
    listOf(Color(0xFF0F766E), Color(0xFF14B8A6)), // Teal - Cyan
    listOf(Color(0xFF7C2D12), Color(0xFFEA580C)), // Rust - Orange
    listOf(Color(0xFF4C1D95), Color(0xFF8B5CF6)), // Indigo - Purple
    listOf(Color(0xFF14532D), Color(0xFF22C55E)), // Forest - Emerald
    listOf(Color(0xFF831843), Color(0xFFEC4899))  // Berry - Pink
)

private fun getInitials(name: String): String {
    val clean = name.trim().split(Regex("\\s+")).filter { it.isNotBlank() }
    return when {
        clean.isEmpty() -> "؟"
        clean.size == 1 -> clean[0].take(1)
        else -> "${clean[0].take(1)}.${clean.last().take(1)}"
    }
}

/**
 * Enhanced List & Search screen using LazyColumn with a stickyHeader search bar
 * that filters entries by name or card number in real-time, displaying them
 * as rich Material 3 cards.
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class, ExperimentalLayoutApi::class)
@Composable
fun RecordsScreen(
    activeSheet: SheetEntity?,
    persons: List<PersonEntity>,
    searchQuery: String,
    filterMode: PersonFilter,
    onSearchChange: (String) -> Unit,
    onFilterChange: (PersonFilter) -> Unit,
    onBack: () -> Unit,
    onAddPersonClick: () -> Unit,
    onBulkAddClick: () -> Unit,
    onEditPersonClick: (PersonEntity) -> Unit,
    onDeletePerson: (PersonEntity) -> Unit,
    onMovePersonClick: (PersonEntity) -> Unit
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    var personToDelete by remember { mutableStateOf<PersonEntity?>(null) }

    val dynamicColumns = activeSheet?.getDynamicColumns() ?: emptyList()
    val columnsMap = remember(dynamicColumns) { dynamicColumns.associateBy { it.id } }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = activeSheet?.title ?: "قائمة الأسماء والسجلات",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "${persons.size} سجل معروض",
                            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                    }
                },
                actions = {
                    FilledTonalButton(
                        onClick = onBulkAddClick,
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .testTag("bulk_add_button"),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.GroupAdd,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp),
                            tint = TealSecondary
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "إضافة جماعية",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TealSecondary
                            )
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onAddPersonClick,
                containerColor = NavyPrimary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.testTag("fab_add_person")
            ) {
                Icon(Icons.Default.Add, contentDescription = "إضافة شخص")
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .imePadding(),
            contentPadding = PaddingValues(bottom = 88.dp)
        ) {
            // ==========================================
            // Sticky Search & Real-time Filter Bar
            // ==========================================
            stickyHeader {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    shadowElevation = 4.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 10.dp)
                    ) {
                        // Search Bar TextField
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = onSearchChange,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("search_records_input"),
                            placeholder = { Text("بحث بالاسم، رقم البطاقة، أو الحقول...") },
                            leadingIcon = {
                                Icon(Icons.Default.Search, contentDescription = null, tint = NavyPrimary)
                            },
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(onClick = { onSearchChange("") }) {
                                        Icon(Icons.Default.Clear, contentDescription = "مسح البحث")
                                    }
                                }
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(16.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = NavyPrimary,
                                unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant,
                                focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                                unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f)
                            )
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Filter Chips Row with real-time stats
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            FilterChip(
                                selected = filterMode == PersonFilter.ALL,
                                onClick = { onFilterChange(PersonFilter.ALL) },
                                label = { Text("الكل") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = NavyPrimary,
                                    selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                                )
                            )
                            FilterChip(
                                selected = filterMode == PersonFilter.WITH_CARD,
                                onClick = { onFilterChange(PersonFilter.WITH_CARD) },
                                label = { Text("يحمل بطاقة") },
                                leadingIcon = if (filterMode == PersonFilter.WITH_CARD) {
                                    { Icon(Icons.Default.Badge, contentDescription = null, modifier = Modifier.size(16.dp)) }
                                } else null,
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = TealSecondary,
                                    selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                                )
                            )
                            FilterChip(
                                selected = filterMode == PersonFilter.WITHOUT_CARD,
                                onClick = { onFilterChange(PersonFilter.WITHOUT_CARD) },
                                label = { Text("بدون بطاقة") },
                                leadingIcon = if (filterMode == PersonFilter.WITHOUT_CARD) {
                                    { Icon(Icons.Default.PersonOff, contentDescription = null, modifier = Modifier.size(16.dp)) }
                                } else null,
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = AmberTertiary,
                                    selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                                )
                            )
                        }

                        // Search Results Count indicator
                        if (searchQuery.isNotBlank()) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "نتائج البحث عن: \"$searchQuery\"",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = MaterialTheme.colorScheme.primary,
                                        fontWeight = FontWeight.Medium
                                    )
                                )
                                Text(
                                    text = "${persons.size} مطابق",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                )
                            }
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(8.dp))
            }

            // ==========================================
            // Empty State Handling
            // ==========================================
            if (persons.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 24.dp, vertical = 64.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Surface(
                                modifier = Modifier.size(80.dp),
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = if (searchQuery.isNotEmpty()) Icons.Default.SearchOff else Icons.Default.Person,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.outline,
                                        modifier = Modifier.size(40.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            Text(
                                text = if (searchQuery.isNotEmpty()) "لا توجد نتائج مطابقة" else "الكشف فارغ حالياً",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            Text(
                                text = if (searchQuery.isNotEmpty())
                                    "تأكد من كتابة الاسم أو رقم البطاقة بشكل صحيح أو جرب كلمات أخرى"
                                else
                                    "اضغط على زر (+) لإضافة أول شخص أو استورد السجلات من ملف إكسل",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                ),
                                modifier = Modifier.padding(horizontal = 16.dp)
                            )

                            Spacer(modifier = Modifier.height(20.dp))

                            if (searchQuery.isNotEmpty()) {
                                OutlinedButton(onClick = { onSearchChange("") }) {
                                    Text("مسح البحث وعرض الكل")
                                }
                            } else {
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Button(
                                        onClick = onAddPersonClick,
                                        colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary)
                                    ) {
                                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("إضافة شخص")
                                    }

                                    FilledTonalButton(
                                        onClick = onBulkAddClick
                                    ) {
                                        Icon(Icons.Default.GroupAdd, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("إضافة جماعية")
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                // ==========================================
                // Material 3 Cards for Persons
                // ==========================================
                items(persons, key = { it.id }) { person ->
                    val dynamicData = person.getDynamicData()
                    val gradientIdx = abs(person.primary_name.hashCode()) % AVATAR_GRADIENTS.size
                    val avatarGradient = AVATAR_GRADIENTS[gradientIdx]

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp)
                    ) {
                        ElevatedCard(
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("person_card_${person.id}"),
                            shape = RoundedCornerShape(20.dp),
                            elevation = androidx.compose.material3.CardDefaults.elevatedCardElevation(
                                defaultElevation = 2.dp,
                                pressedElevation = 4.dp
                            )
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp)
                            ) {
                                // Top row: Avatar + Primary Name + Card Badge
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // Initials Avatar with Gradient
                                    Box(
                                        modifier = Modifier
                                            .size(46.dp)
                                            .clip(CircleShape)
                                            .background(Brush.linearGradient(avatarGradient)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = getInitials(person.primary_name),
                                            style = MaterialTheme.typography.titleSmall.copy(
                                                color = Color.White,
                                                fontWeight = FontWeight.Bold
                                            )
                                        )
                                    }

                                    Spacer(modifier = Modifier.width(12.dp))

                                    // Name and creation date
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = person.primary_name,
                                            style = MaterialTheme.typography.titleMedium.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                        )
                                        Text(
                                            text = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault()).format(Date(person.timestamp)),
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = MaterialTheme.colorScheme.outline
                                            )
                                        )
                                    }

                                    // Unique Card Pill Badge
                                    if (!person.unique_card_id.isNullOrBlank()) {
                                        Surface(
                                            color = TealSecondary.copy(alpha = 0.12f),
                                            shape = RoundedCornerShape(10.dp),
                                            modifier = Modifier.clickable {
                                                clipboardManager.setText(AnnotatedString(person.unique_card_id))
                                                Toast.makeText(context, "تم نسخ رقم البطاقة", Toast.LENGTH_SHORT).show()
                                            }
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                            ) {
                                                Icon(
                                                    Icons.Default.Badge,
                                                    contentDescription = null,
                                                    tint = TealSecondary,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text(
                                                    text = person.unique_card_id,
                                                    style = MaterialTheme.typography.labelMedium.copy(
                                                        color = TealSecondary,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                )
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Icon(
                                                    Icons.Default.ContentCopy,
                                                    contentDescription = "نسخ رقم البطاقة",
                                                    tint = TealSecondary.copy(alpha = 0.7f),
                                                    modifier = Modifier.size(14.dp)
                                                )
                                            }
                                        }
                                    } else {
                                        Surface(
                                            color = MaterialTheme.colorScheme.surfaceVariant,
                                            shape = RoundedCornerShape(10.dp)
                                        ) {
                                            Text(
                                                text = "بدون بطاقة",
                                                style = MaterialTheme.typography.labelSmall.copy(
                                                    color = MaterialTheme.colorScheme.outline
                                                ),
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                                            )
                                        }
                                    }
                                }

                                // Dynamic fields flow
                                if (dynamicData.isNotEmpty()) {
                                    Spacer(modifier = Modifier.height(12.dp))
                                    FlowRow(
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        for ((colId, valStr) in dynamicData) {
                                            if (valStr.isNotBlank()) {
                                                val colName = columnsMap[colId]?.name ?: colId
                                                Surface(
                                                    color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.45f),
                                                    shape = RoundedCornerShape(8.dp)
                                                ) {
                                                    Row(
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                                    ) {
                                                        Text(
                                                            text = "$colName: ",
                                                            style = MaterialTheme.typography.labelSmall.copy(
                                                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                                                fontWeight = FontWeight.Bold
                                                            )
                                                        )
                                                        Text(
                                                            text = valStr,
                                                            style = MaterialTheme.typography.labelSmall.copy(
                                                                color = MaterialTheme.colorScheme.onSecondaryContainer
                                                            )
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                // Divider line
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(1.dp)
                                        .background(MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                                )

                                Spacer(modifier = Modifier.height(8.dp))

                                // Action Buttons Row: Move Sheet, Edit, Delete
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // Move person button
                                    TextButton(
                                        onClick = { onMovePersonClick(person) },
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.DriveFileMove,
                                            contentDescription = null,
                                            tint = TealSecondary,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            "نقل لكشف",
                                            style = MaterialTheme.typography.labelMedium.copy(color = TealSecondary)
                                        )
                                    }

                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        // Edit person button
                                        FilledTonalButton(
                                            onClick = { onEditPersonClick(person) },
                                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                            shape = RoundedCornerShape(10.dp)
                                        ) {
                                            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(15.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("تعديل", style = MaterialTheme.typography.labelMedium)
                                        }

                                        Spacer(modifier = Modifier.width(6.dp))

                                        // Delete person button
                                        IconButton(
                                            onClick = { personToDelete = person },
                                            modifier = Modifier.size(38.dp)
                                        ) {
                                            Icon(
                                                Icons.Default.Delete,
                                                contentDescription = "حذف الشخص",
                                                tint = MaterialTheme.colorScheme.error,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Delete Confirmation Dialog
    personToDelete?.let { p ->
        AlertDialog(
            onDismissRequest = { personToDelete = null },
            title = { Text("حذف السجل") },
            text = { Text("هل أنت متأكد من رغبتك في حذف '${p.primary_name}' نهائياً من هذا الكشف؟") },
            confirmButton = {
                Button(
                    onClick = {
                        onDeletePerson(p)
                        personToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("نعم، حذف")
                }
            },
            dismissButton = {
                TextButton(onClick = { personToDelete = null }) {
                    Text("إلغاء")
                }
            }
        )
    }
}
