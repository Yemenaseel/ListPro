package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.SheetEntity
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.TealSecondary
import com.example.util.ParsedExcelTable

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExcelColumnMappingDialog(
    table: ParsedExcelTable,
    activeSheet: SheetEntity,
    isImporting: Boolean,
    onDismiss: () -> Unit,
    onConfirmImport: (nameColIdx: Int, cardColIdx: Int, dynamicColsMapping: Map<String, Int>) -> Unit
) {
    val excelColumns = table.headers
    val dynamicColumns = activeSheet.getDynamicColumns()

    // Smart initial mapping
    val initialNameIdx = excelColumns.indexOfFirst {
        it.contains("اسم", ignoreCase = true) || it.contains("name", ignoreCase = true)
    }.let { if (it >= 0) it else 0 }

    val initialCardIdx = excelColumns.indexOfFirst {
        it.contains("بطاق", ignoreCase = true) || it.contains("هوي", ignoreCase = true) || it.contains("card", ignoreCase = true) || it.contains("id", ignoreCase = true)
    }

    var selectedNameColIdx by remember { mutableIntStateOf(initialNameIdx) }
    var selectedCardColIdx by remember { mutableIntStateOf(initialCardIdx) }

    val dynamicMapping = remember {
        mutableStateMapOf<String, Int>().apply {
            for (col in dynamicColumns) {
                val matchIdx = excelColumns.indexOfFirst { it.contains(col.name, ignoreCase = true) }
                if (matchIdx >= 0) {
                    put(col.id, matchIdx)
                }
            }
        }
    }

    Dialog(
        onDismissRequest = { if (!isImporting) onDismiss() },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .heightIn(max = 680.dp)
                .imePadding(),
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.TableChart,
                            contentDescription = null,
                            tint = TealSecondary,
                            modifier = Modifier.padding(end = 8.dp)
                        )
                        Column {
                            Text(
                                text = "مطابقة أعمدة الإكسل",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = NavyPrimary
                                )
                            )
                            Text(
                                text = "تم العثور على ${table.rows.size} صف في الملف",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                        }
                    }

                    if (!isImporting) {
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Outlined.Close, contentDescription = "إلغاء")
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Scrollable Column Mappings
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                ) {
                    Text(
                        text = "قم بربط كل حقل في الكشف بالعمود المقابل له في ملف الإكسل:",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // 1. Mandatory Primary Name Dropdown
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "الاسم الرباعي (إجباري) *",
                                style = MaterialTheme.typography.labelLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = NavyPrimary
                                )
                            )
                            Spacer(modifier = Modifier.height(6.dp))

                            var expanded by remember { mutableStateOf(false) }
                            ExposedDropdownMenuBox(
                                expanded = expanded,
                                onExpandedChange = { if (!isImporting) expanded = !expanded }
                            ) {
                                OutlinedTextField(
                                    value = if (selectedNameColIdx in excelColumns.indices) excelColumns[selectedNameColIdx] else "اختر العمود...",
                                    onValueChange = {},
                                    readOnly = true,
                                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                                    modifier = Modifier
                                        .menuAnchor()
                                        .fillMaxWidth()
                                )
                                ExposedDropdownMenu(
                                    expanded = expanded,
                                    onDismissRequest = { expanded = false }
                                ) {
                                    excelColumns.forEachIndexed { index, colName ->
                                        DropdownMenuItem(
                                            text = { Text("عمود: $colName") },
                                            onClick = {
                                                selectedNameColIdx = index
                                                expanded = false
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // 2. Card ID Dropdown
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "رقم البطاقة / الهوية (اختياري)",
                                style = MaterialTheme.typography.labelLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TealSecondary
                                )
                            )
                            Spacer(modifier = Modifier.height(6.dp))

                            var expanded by remember { mutableStateOf(false) }
                            val displayCard = if (selectedCardColIdx in excelColumns.indices) excelColumns[selectedCardColIdx] else "[بدون تعيين]"

                            ExposedDropdownMenuBox(
                                expanded = expanded,
                                onExpandedChange = { if (!isImporting) expanded = !expanded }
                            ) {
                                OutlinedTextField(
                                    value = displayCard,
                                    onValueChange = {},
                                    readOnly = true,
                                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                                    modifier = Modifier
                                        .menuAnchor()
                                        .fillMaxWidth()
                                )
                                ExposedDropdownMenu(
                                    expanded = expanded,
                                    onDismissRequest = { expanded = false }
                                ) {
                                    DropdownMenuItem(
                                        text = { Text("[بدون تعيين]") },
                                        onClick = {
                                            selectedCardColIdx = -1
                                            expanded = false
                                        }
                                    )
                                    excelColumns.forEachIndexed { index, colName ->
                                        DropdownMenuItem(
                                            text = { Text("عمود: $colName") },
                                            onClick = {
                                                selectedCardColIdx = index
                                                expanded = false
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // 3. Dynamic Columns Mapping
                    if (dynamicColumns.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "الحقول الإضافية الخاصة بالكشف:",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        for (col in dynamicColumns) {
                            val currentMappedIdx = dynamicMapping[col.id] ?: -1
                            val displayVal = if (currentMappedIdx in excelColumns.indices) excelColumns[currentMappedIdx] else "[بدون تعيين]"

                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                                ),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(
                                        text = "${col.name} (${col.type.toArabicLabel()})",
                                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold)
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))

                                    var expanded by remember { mutableStateOf(false) }
                                    ExposedDropdownMenuBox(
                                        expanded = expanded,
                                        onExpandedChange = { if (!isImporting) expanded = !expanded }
                                    ) {
                                        OutlinedTextField(
                                            value = displayVal,
                                            onValueChange = {},
                                            readOnly = true,
                                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                                            modifier = Modifier
                                                .menuAnchor()
                                                .fillMaxWidth()
                                        )
                                        ExposedDropdownMenu(
                                            expanded = expanded,
                                            onDismissRequest = { expanded = false }
                                        ) {
                                            DropdownMenuItem(
                                                text = { Text("[بدون تعيين]") },
                                                onClick = {
                                                    dynamicMapping.remove(col.id)
                                                    expanded = false
                                                }
                                            )
                                            excelColumns.forEachIndexed { index, colName ->
                                                DropdownMenuItem(
                                                    text = { Text("عمود: $colName") },
                                                    onClick = {
                                                        dynamicMapping[col.id] = index
                                                        expanded = false
                                                    }
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Notice on Duplicates
                    Spacer(modifier = Modifier.height(16.dp))
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                        ),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = NavyPrimary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "سيتم فحص الازدواجية تلقائياً وتخطي أي سجل مكرر في أي كشف بالكامل.",
                                style = MaterialTheme.typography.bodySmall.copy(color = NavyPrimary)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Bottom Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        enabled = !isImporting,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("إلغاء")
                    }

                    Button(
                        onClick = {
                            onConfirmImport(
                                selectedNameColIdx,
                                selectedCardColIdx,
                                dynamicMapping.toMap()
                            )
                        },
                        enabled = !isImporting && selectedNameColIdx in excelColumns.indices,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("confirm_import_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        if (isImporting) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = MaterialTheme.colorScheme.onPrimary,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("جارٍ الاستيراد...")
                        } else {
                            Text("بدء الاستيراد")
                        }
                    }
                }
            }
        }
    }
}
