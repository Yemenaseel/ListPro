package com.example.ui.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AuthPreferences
import com.example.data.model.ColumnDefinition
import com.example.data.model.ColumnType
import com.example.data.model.DisplayedPersonItem
import com.example.data.model.PersonEntity
import com.example.data.model.SheetEntity
import com.example.data.repository.DuplicateCheckResult
import com.example.data.repository.RegistryRepository
import com.example.data.repository.SheetStatistics
import com.example.util.ArabicNormalizer
import com.example.util.ExcelEngine
import com.example.util.FileSharingHelper
import com.example.util.ParsedExcelTable
import com.example.util.PdfExporter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

enum class ExportScope {
    ACTIVE_SHEET,
    ALL_SHEETS
}

enum class ExportFormat {
    EXCEL,
    CSV,
    PDF
}

enum class PersonFilter {
    ALL,
    WITH_CARD,
    WITHOUT_CARD
}

data class BulkWizardRow(
    val index: Int,
    val name: String,
    val card: String?,
    val dynamicValues: Map<String, String>,
    val status: BulkWizardStatus,
    val statusMessage: String,
    val targetPersonId: Long? = null,
    val targetSheetId: Long? = null,
    val targetSheetTitle: String? = null
)

enum class BulkWizardStatus {
    VALID,                             // جديد سليم - سيتم إضافته للكشف الحالي
    UPDATE_EXISTING,                   // مسجل مسبقاً - سيتم تحديث بياناته في كشفه السابق دون تكرار
    REJECTED_DUPLICATE,                // مكرر بالكامل - سيتم رفضه وتجاوزه لمنع التكرار
    WARNING_CURRENT_SHEET_DUPLICATE,   // تشابه أسماء
    ERROR_CARD_DUPLICATE,              // رقم البطاقة يخص شخصاً آخر - مرفوض
    ERROR_OTHER_SHEET_DUPLICATE,       // مكرر في كشف آخر - مرفوض
    ERROR_BATCH_DUPLICATE,             // مكرر داخل نفس القائمة المدخلة - مرفوض
    ERROR_EMPTY_NAME                   // الاسم فارغ - مرفوض
}

class RegistryViewModel(
    private val repository: RegistryRepository,
    private val authPreferences: AuthPreferences
) : ViewModel() {

    // -------------------------------------------------------------------------
    // 1. Authentication State
    // -------------------------------------------------------------------------
    private val _isPasswordSet = MutableStateFlow(authPreferences.isPasswordSet())
    val isPasswordSet: StateFlow<Boolean> = _isPasswordSet.asStateFlow()

    private val _isAuthenticated = MutableStateFlow(false)
    val isAuthenticated: StateFlow<Boolean> = _isAuthenticated.asStateFlow()

    private val _loginError = MutableStateFlow<String?>(null)
    val loginError: StateFlow<String?> = _loginError.asStateFlow()

    fun setupMasterPassword(password: String): Boolean {
        if (password.length < 4) {
            _loginError.value = "يجب أن تتكون كلمة المرور من 4 خانات على الأقل."
            return false
        }
        val success = authPreferences.setMasterPassword(password)
        if (success) {
            _isPasswordSet.value = true
            _isAuthenticated.value = true
            _loginError.value = null
        }
        return success
    }

    fun login(password: String): Boolean {
        return if (authPreferences.verifyPassword(password)) {
            _isAuthenticated.value = true
            _loginError.value = null
            true
        } else {
            _loginError.value = "كلمة المرور غير صحيحة، يرجى المحاولة مجدداً."
            false
        }
    }

    fun changePassword(oldPassword: String, newPassword: String): Boolean {
        if (newPassword.length < 4) {
            _loginError.value = "يجب أن تتكون كلمة المرور الجديدة من 4 خانات على الأقل."
            return false
        }
        val success = authPreferences.changePassword(oldPassword, newPassword)
        if (success) {
            _loginError.value = null
        } else {
            _loginError.value = "كلمة المرور الحالية غير صحيحة."
        }
        return success
    }

    fun authenticateWithBiometric(): Boolean {
        _isAuthenticated.value = true
        _loginError.value = null
        return true
    }

    fun logout() {
        _isAuthenticated.value = false
    }

    fun clearLoginError() {
        _loginError.value = null
    }

    // -------------------------------------------------------------------------
    // 2. Sheets Management
    // -------------------------------------------------------------------------
    val sheets: StateFlow<List<SheetEntity>> = repository.allSheets
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val _activeSheetId = MutableStateFlow<Long?>(null)
    val activeSheetId: StateFlow<Long?> = _activeSheetId.asStateFlow()

    val activeSheet: StateFlow<SheetEntity?> = combine(sheets, _activeSheetId) { list, id ->
        if (list.isEmpty()) null
        else if (id == null) list.firstOrNull()
        else list.find { it.id == id } ?: list.firstOrNull()
    }.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    init {
        viewModelScope.launch {
            val main = repository.ensureMainSheetExists()
            if (_activeSheetId.value == null) {
                _activeSheetId.value = main?.id
            }
        }
    }

    fun setActiveSheet(sheetId: Long) {
        _activeSheetId.value = sheetId
    }

    fun createSheet(title: String, onSuccess: (SheetEntity) -> Unit = {}) {
        val trimmed = title.trim()
        if (trimmed.isBlank()) return
        viewModelScope.launch {
            val newSheet = SheetEntity(
                title = trimmed,
                is_main = false,
                created_at = System.currentTimeMillis(),
                list_of_dynamic_columns = "[]"
            )
            val newId = repository.insertSheet(newSheet)
            val created = newSheet.copy(id = newId)
            _activeSheetId.value = newId
            onSuccess(created)
        }
    }

    fun renameSheet(sheetId: Long, newTitle: String) {
        val trimmed = newTitle.trim()
        if (trimmed.isBlank()) return
        viewModelScope.launch {
            val current = repository.getSheetById(sheetId)
            if (current != null) {
                repository.updateSheet(current.copy(title = trimmed))
            }
        }
    }

    fun deleteSheet(sheet: SheetEntity, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            repository.deleteSheet(sheet)
            // Switch active sheet to remaining sheet
            val remaining = repository.getAllSheetsList()
            _activeSheetId.value = remaining.firstOrNull()?.id
            onResult(true, "تم حذف الكشف بنجاح.")
        }
    }

    // -------------------------------------------------------------------------
    // 3. Dynamic Columns Engine
    // -------------------------------------------------------------------------
    fun addDynamicColumn(name: String, type: ColumnType, onResult: (Boolean, String) -> Unit) {
        val sheet = activeSheet.value ?: return
        val trimmed = name.trim()
        if (trimmed.isBlank()) {
            onResult(false, "اسم العمود لا يمكن أن يكون فارغاً.")
            return
        }
        val currentColumns = sheet.getDynamicColumns()
        if (currentColumns.any { it.name.equals(trimmed, ignoreCase = true) }) {
            onResult(false, "يوجد عمود بنفس الاسم بالفعل في هذا الكشف.")
            return
        }

        val newCol = ColumnDefinition(
            id = "col_${UUID.randomUUID().toString().take(8)}",
            name = trimmed,
            type = type
        )
        val updatedList = currentColumns + newCol
        viewModelScope.launch {
            repository.updateSheet(sheet.withDynamicColumns(updatedList))
            onResult(true, "تمت إضافة العمود بنجاح.")
        }
    }

    fun renameDynamicColumn(columnId: String, newName: String, onResult: (Boolean, String) -> Unit) {
        val sheet = activeSheet.value ?: return
        val trimmed = newName.trim()
        if (trimmed.isBlank()) {
            onResult(false, "اسم العمود لا يمكن أن يكون فارغاً.")
            return
        }
        val currentColumns = sheet.getDynamicColumns()
        val updated = currentColumns.map {
            if (it.id == columnId) it.copy(name = trimmed) else it
        }
        viewModelScope.launch {
            repository.updateSheet(sheet.withDynamicColumns(updated))
            onResult(true, "تم تعديل اسم العمود.")
        }
    }

    fun deleteDynamicColumn(columnId: String, onResult: (Boolean, String) -> Unit) {
        val sheet = activeSheet.value ?: return
        val currentColumns = sheet.getDynamicColumns()
        val updated = currentColumns.filterNot { it.id == columnId }
        viewModelScope.launch {
            repository.updateSheet(sheet.withDynamicColumns(updated))
            onResult(true, "تم حذف العمود من الكشف.")
        }
    }

    // -------------------------------------------------------------------------
    // 4. Persons & Records State
    // -------------------------------------------------------------------------
    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val personsInActiveSheet: StateFlow<List<PersonEntity>> = _activeSheetId.flatMapLatest { id ->
        if (id == null) {
            repository.allSheets.flatMapLatest { sheets ->
                val firstId = sheets.firstOrNull()?.id ?: 0L
                repository.getPersonsBySheet(firstId)
            }
        } else {
            repository.getPersonsBySheet(id)
        }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _filterMode = MutableStateFlow(PersonFilter.ALL)
    val filterMode: StateFlow<PersonFilter> = _filterMode.asStateFlow()

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setFilterMode(mode: PersonFilter) {
        _filterMode.value = mode
    }

    val allActivePersons: StateFlow<List<PersonEntity>> = repository.allPersons
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val searchAndFilterState = combine(_searchQuery, _filterMode) { q, f -> Pair(q, f) }

    val displayedPersons: StateFlow<List<DisplayedPersonItem>> = combine(
        personsInActiveSheet,
        allActivePersons,
        sheets,
        searchAndFilterState
    ) { activeList: List<PersonEntity>, allList: List<PersonEntity>, sheetList: List<SheetEntity>, params: Pair<String, PersonFilter> ->
        val query = params.first
        val filter = params.second
        val sheetMap = sheetList.associateBy { it.id }
        val q = query.trim()
        val currentSheetId = _activeSheetId.value

        if (q.isNotEmpty()) {
            // GLOBAL CROSS-SHEET SEARCH: Search in all active records across all sheets
            val normQuery = ArabicNormalizer.normalizeArabic(q)
            val cleanCardQuery = ArabicNormalizer.cleanCardNumber(q)

            var matching = allList.filter { person ->
                val normName = ArabicNormalizer.normalizeArabic(person.primary_name)
                val cleanCard = ArabicNormalizer.cleanCardNumber(person.unique_card_id)

                val nameMatches = normName.contains(normQuery)
                val cardMatches = cleanCardQuery.isNotBlank() && cleanCard.contains(cleanCardQuery)

                val dynamicMatches = person.getDynamicData().values.any { valStr ->
                    ArabicNormalizer.normalizeArabic(valStr).contains(normQuery) ||
                            (cleanCardQuery.isNotBlank() && ArabicNormalizer.cleanCardNumber(valStr).contains(cleanCardQuery))
                }

                nameMatches || cardMatches || dynamicMatches
            }

            matching = when (filter) {
                PersonFilter.ALL -> matching
                PersonFilter.WITH_CARD -> matching.filter { !it.unique_card_id.isNullOrBlank() }
                PersonFilter.WITHOUT_CARD -> matching.filter { it.unique_card_id.isNullOrBlank() }
            }

            matching.sortedWith(compareBy { ArabicNormalizer.normalizeArabic(it.primary_name) })
                .map { person ->
                    DisplayedPersonItem(
                        person = person,
                        sheetTitle = sheetMap[person.sheet_id]?.title ?: "كشف رقم ${person.sheet_id}",
                        isFromActiveSheet = person.sheet_id == currentSheetId
                    )
                }
        } else {
            // ACTIVE SHEET RECORDS ONLY
            var list = activeList
            list = when (filter) {
                PersonFilter.ALL -> list
                PersonFilter.WITH_CARD -> list.filter { !it.unique_card_id.isNullOrBlank() }
                PersonFilter.WITHOUT_CARD -> list.filter { it.unique_card_id.isNullOrBlank() }
            }

            val activeTitle = sheetMap[currentSheetId]?.title ?: ""
            list.sortedWith(compareBy { ArabicNormalizer.normalizeArabic(it.primary_name) })
                .map { person ->
                    DisplayedPersonItem(
                        person = person,
                        sheetTitle = activeTitle,
                        isFromActiveSheet = true
                    )
                }
        }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val filteredPersons: StateFlow<List<PersonEntity>> = displayedPersons
        .combine(_searchQuery) { displayed, _ -> displayed.map { it.person } }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // -------------------------------------------------------------------------
    // 4.5. Recycle Bin (سلة المحذوفات) & Bulk Move
    // -------------------------------------------------------------------------
    val deletedPersons: StateFlow<List<PersonEntity>> = repository.deletedPersons
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val deletedCount: StateFlow<Int> = repository.deletedCount
        .stateIn(viewModelScope, SharingStarted.Eagerly, 0)

    fun softDeletePerson(id: Long, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            repository.softDeletePerson(id)
            onDone()
        }
    }

    fun softDeletePersons(ids: List<Long>, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            repository.softDeletePersons(ids)
            onDone()
        }
    }

    fun restorePerson(id: Long, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            repository.restorePerson(id)
            onDone()
        }
    }

    fun restorePersons(ids: List<Long>, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            repository.restorePersons(ids)
            onDone()
        }
    }

    fun deletePermanently(id: Long, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            repository.deletePermanently(id)
            onDone()
        }
    }

    fun emptyRecycleBin(onDone: () -> Unit = {}) {
        viewModelScope.launch {
            repository.emptyRecycleBin()
            onDone()
        }
    }

    fun movePersonsToSheet(ids: List<Long>, targetSheetId: Long, onDone: (Boolean) -> Unit) {
        viewModelScope.launch {
            repository.movePersonsToSheet(ids, targetSheetId)
            onDone(true)
        }
    }

    // -------------------------------------------------------------------------
    // 5. Add / Edit / Move / Delete Person
    // -------------------------------------------------------------------------
    fun checkAndSavePerson(
        personId: Long? = null,
        targetSheetId: Long,
        primaryName: String,
        cardId: String?,
        dynamicData: Map<String, String>,
        forceCurrentSheetDuplicate: Boolean = false,
        onDuplicate: (DuplicateCheckResult) -> Unit,
        onSuccess: (String) -> Unit
    ) {
        val trimmedName = primaryName.trim()
        if (trimmedName.isBlank()) {
            onDuplicate(DuplicateCheckResult.OtherSheetNameDuplicate("", "الاسم الرباعي إجباري ولا يمكن تركه فارغاً."))
            return
        }

        viewModelScope.launch {
            val cleanedCard = ArabicNormalizer.cleanCardNumber(cardId).ifBlank { null }
            val checkResult = repository.checkDuplicate(
                targetSheetId = targetSheetId,
                primaryName = trimmedName,
                cardId = cleanedCard,
                editingPersonId = personId
            )

            when (checkResult) {
                is DuplicateCheckResult.CardDuplicate -> {
                    onDuplicate(checkResult)
                    return@launch
                }
                is DuplicateCheckResult.OtherSheetNameDuplicate -> {
                    onDuplicate(checkResult)
                    return@launch
                }
                is DuplicateCheckResult.CurrentSheetDuplicate -> {
                    if (!forceCurrentSheetDuplicate) {
                        onDuplicate(checkResult)
                        return@launch
                    }
                    // If user confirmed to proceed with current sheet duplicate, proceed to save
                }
                is DuplicateCheckResult.Valid -> {
                    // Valid
                }
            }

            if (personId == null) {
                // New person
                val newPerson = PersonEntity(
                    sheet_id = targetSheetId,
                    primary_name = trimmedName,
                    unique_card_id = cleanedCard,
                    dynamic_data_map = PersonEntity.mapToJsonString(dynamicData),
                    timestamp = System.currentTimeMillis()
                )
                repository.insertPerson(newPerson)
                onSuccess("تمت إضافة السجل بنجاح.")
            } else {
                // Update person
                val existing = repository.getPersonsBySheetList(targetSheetId).find { it.id == personId }
                    ?: repository.getAllPersonsList().find { it.id == personId }

                val updatedPerson = PersonEntity(
                    id = personId,
                    sheet_id = targetSheetId,
                    primary_name = trimmedName,
                    unique_card_id = cleanedCard,
                    dynamic_data_map = PersonEntity.mapToJsonString(dynamicData),
                    timestamp = existing?.timestamp ?: System.currentTimeMillis()
                )
                repository.updatePerson(updatedPerson)
                onSuccess("تم تعديل السجل بنجاح.")
            }
        }
    }

    fun movePerson(personId: Long, targetSheetId: Long, onSuccess: () -> Unit) {
        viewModelScope.launch {
            repository.movePerson(personId, targetSheetId)
            onSuccess()
        }
    }

    fun deletePerson(person: PersonEntity, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            repository.deletePerson(person)
            onSuccess()
        }
    }

    // -------------------------------------------------------------------------
    // 6. Statistics
    // -------------------------------------------------------------------------
    private val _statistics = MutableStateFlow<SheetStatistics?>(null)
    val statistics: StateFlow<SheetStatistics?> = _statistics.asStateFlow()

    fun loadStatistics() {
        viewModelScope.launch {
            val sheetId = _activeSheetId.value ?: return@launch
            _statistics.value = repository.getStatistics(sheetId)
        }
    }

    // -------------------------------------------------------------------------
    // 7. Bulk Excel Import Engine
    // -------------------------------------------------------------------------
    private val _importPreviewTable = MutableStateFlow<ParsedExcelTable?>(null)
    val importPreviewTable: StateFlow<ParsedExcelTable?> = _importPreviewTable.asStateFlow()

    private val _isImporting = MutableStateFlow(false)
    val isImporting: StateFlow<Boolean> = _isImporting.asStateFlow()

    private val _importSummaryMessage = MutableStateFlow<String?>(null)
    val importSummaryMessage: StateFlow<String?> = _importSummaryMessage.asStateFlow()

    fun setImportPreview(table: ParsedExcelTable?) {
        _importPreviewTable.value = table
    }

    fun clearImportSummary() {
        _importSummaryMessage.value = null
    }

    /**
     * Executes the bulk import using column mapping:
     * - nameColIdx: index in Excel row for Primary Name
     * - cardColIdx: index in Excel row for Card ID (optional, -1 if none)
     * - dynamicColsMapping: map of Dynamic Column ID -> index in Excel row
     */
    fun executeBulkImport(
        sheetId: Long,
        nameColIdx: Int,
        cardColIdx: Int,
        dynamicColsMapping: Map<String, Int>,
        onFinished: (importedCount: Int, updatedCount: Int, skippedCount: Int) -> Unit
    ) {
        val table = _importPreviewTable.value ?: return
        _isImporting.value = true

        viewModelScope.launch(Dispatchers.IO) {
            val allPersons = repository.getAllPersonsList().toMutableList()
            val existingCards = mutableMapOf<String, PersonEntity>()
            val existingNames = mutableMapOf<String, PersonEntity>()

            for (p in allPersons) {
                val c = ArabicNormalizer.cleanCardNumber(p.unique_card_id)
                if (c.isNotBlank()) existingCards[c] = p

                val n = ArabicNormalizer.normalizeArabic(p.primary_name)
                if (n.isNotBlank() && !existingNames.containsKey(n)) {
                    existingNames[n] = p
                }
            }

            var importedCount = 0
            var updatedCount = 0
            var skippedCount = 0

            val personsToInsert = mutableListOf<PersonEntity>()
            val personsToUpdate = mutableListOf<PersonEntity>()

            val batchSeenCards = mutableSetOf<String>()
            val batchSeenNames = mutableSetOf<String>()

            for (row in table.rows) {
                val rawName = if (nameColIdx in row.indices) row[nameColIdx].trim() else ""
                if (rawName.isBlank()) {
                    skippedCount++
                    continue
                }

                val normName = ArabicNormalizer.normalizeArabic(rawName)
                val rawCard = if (cardColIdx >= 0 && cardColIdx in row.indices) row[cardColIdx].trim() else ""
                val cleanedCard = ArabicNormalizer.cleanCardNumber(rawCard).ifBlank { null }

                // Check intra-batch duplicate
                if ((cleanedCard != null && batchSeenCards.contains(cleanedCard)) || batchSeenNames.contains(normName)) {
                    skippedCount++
                    continue
                }

                val dynamicMap = mutableMapOf<String, String>()
                for ((colId, colIdx) in dynamicColsMapping) {
                    if (colIdx in row.indices) {
                        val v = row[colIdx].trim()
                        if (v.isNotBlank()) dynamicMap[colId] = v
                    }
                }

                val existingWithName = existingNames[normName]
                val existingWithCard = if (cleanedCard != null) existingCards[cleanedCard] else null

                if (existingWithName != null) {
                    val existingCard = ArabicNormalizer.cleanCardNumber(existingWithName.unique_card_id).ifBlank { null }

                    if (existingCard == null && cleanedCard != null) {
                        // Card clash with another person?
                        if (existingWithCard != null && existingWithCard.id != existingWithName.id) {
                            skippedCount++
                            continue
                        }
                        // SMART UPDATE: Add card and missing dynamic fields in original sheet!
                        val mergedDynamic = existingWithName.getDynamicData().toMutableMap()
                        dynamicMap.forEach { (k, v) ->
                            if (v.isNotBlank() && mergedDynamic[k].isNullOrBlank()) {
                                mergedDynamic[k] = v
                            }
                        }
                        val updated = existingWithName.copy(
                            sheet_id = existingWithName.sheet_id, // PRESERVE EXACT ORIGINAL SHEET
                            unique_card_id = cleanedCard,
                            dynamic_data_map = PersonEntity.mapToJsonString(mergedDynamic),
                            timestamp = System.currentTimeMillis()
                        )
                        personsToUpdate.add(updated)
                        existingCards[cleanedCard] = updated
                        existingNames[normName] = updated
                        batchSeenCards.add(cleanedCard)
                        batchSeenNames.add(normName)
                        updatedCount++
                    } else if (existingCard == null && cleanedCard == null) {
                        // Both have no card: check if incoming has missing dynamic fields
                        val existingDyn = existingWithName.getDynamicData()
                        val hasNewFields = dynamicMap.any { (k, v) -> v.isNotBlank() && existingDyn[k].isNullOrBlank() }
                        if (hasNewFields) {
                            val mergedDynamic = existingDyn.toMutableMap()
                            dynamicMap.forEach { (k, v) ->
                                if (v.isNotBlank() && mergedDynamic[k].isNullOrBlank()) {
                                    mergedDynamic[k] = v
                                }
                            }
                            val updated = existingWithName.copy(
                                sheet_id = existingWithName.sheet_id, // PRESERVE EXACT ORIGINAL SHEET
                                dynamic_data_map = PersonEntity.mapToJsonString(mergedDynamic),
                                timestamp = System.currentTimeMillis()
                            )
                            personsToUpdate.add(updated)
                            existingNames[normName] = updated
                            batchSeenNames.add(normName)
                            updatedCount++
                        } else {
                            // Completely duplicate -> REJECT / SKIP
                            skippedCount++
                        }
                    } else if (existingCard != null && existingCard == cleanedCard) {
                        // Both have same card: check if incoming has missing dynamic fields
                        val existingDyn = existingWithName.getDynamicData()
                        val hasNewFields = dynamicMap.any { (k, v) -> v.isNotBlank() && existingDyn[k].isNullOrBlank() }
                        if (hasNewFields) {
                            val mergedDynamic = existingDyn.toMutableMap()
                            dynamicMap.forEach { (k, v) ->
                                if (v.isNotBlank() && mergedDynamic[k].isNullOrBlank()) {
                                    mergedDynamic[k] = v
                                }
                            }
                            val updated = existingWithName.copy(
                                sheet_id = existingWithName.sheet_id, // PRESERVE EXACT ORIGINAL SHEET
                                dynamic_data_map = PersonEntity.mapToJsonString(mergedDynamic),
                                timestamp = System.currentTimeMillis()
                            )
                            personsToUpdate.add(updated)
                            existingNames[normName] = updated
                            batchSeenNames.add(normName)
                            batchSeenCards.add(cleanedCard)
                            updatedCount++
                        } else {
                            // Completely duplicate -> REJECT / SKIP
                            skippedCount++
                        }
                    } else {
                        // Different card or duplicate without card -> REJECT / SKIP
                        skippedCount++
                    }
                } else if (existingWithCard != null) {
                    // Card belongs to another person with different name -> REJECT / SKIP
                    skippedCount++
                } else {
                    // New person -> INSERT into active sheet
                    val newEntity = PersonEntity(
                        sheet_id = sheetId,
                        primary_name = rawName,
                        unique_card_id = cleanedCard,
                        dynamic_data_map = PersonEntity.mapToJsonString(dynamicMap),
                        timestamp = System.currentTimeMillis()
                    )
                    personsToInsert.add(newEntity)
                    if (cleanedCard != null) {
                        existingCards[cleanedCard] = newEntity
                        batchSeenCards.add(cleanedCard)
                    }
                    existingNames[normName] = newEntity
                    batchSeenNames.add(normName)
                    importedCount++
                }
            }

            if (personsToInsert.isNotEmpty()) {
                repository.insertPersons(personsToInsert)
            }
            if (personsToUpdate.isNotEmpty()) {
                repository.updatePersons(personsToUpdate)
            }

            withContext(Dispatchers.Main) {
                _isImporting.value = false
                _importPreviewTable.value = null
                val summary = "تمت العملية: تم إضافة $importedCount سجل جديد، وتحديث $updatedCount في كشوفاتهم السابقة، وتجاوز $skippedCount مكرر."
                _importSummaryMessage.value = summary
                onFinished(importedCount, updatedCount, skippedCount)
            }
        }
    }

    // -------------------------------------------------------------------------
    // 7.1 Multi-Column Bulk Paste Wizard
    // -------------------------------------------------------------------------
    suspend fun validateBulkWizardRows(
        sheetId: Long,
        names: List<String>,
        cards: List<String>,
        dynamicColumnsValues: Map<String, List<String>>
    ): List<BulkWizardRow> = withContext(Dispatchers.IO) {
        val allPersons = repository.getAllPersonsList()
        val allSheets = repository.getAllSheetsList().associateBy { it.id }

        val dbCards = mutableMapOf<String, PersonEntity>()
        val dbNames = mutableMapOf<String, PersonEntity>()

        for (p in allPersons) {
            val c = ArabicNormalizer.cleanCardNumber(p.unique_card_id)
            if (c.isNotBlank()) dbCards[c] = p

            val n = ArabicNormalizer.normalizeArabic(p.primary_name)
            if (n.isNotBlank() && !dbNames.containsKey(n)) {
                dbNames[n] = p
            }
        }

        val batchSeenCards = mutableSetOf<String>()
        val batchSeenNames = mutableSetOf<String>()

        val rowCount = names.size
        val result = mutableListOf<BulkWizardRow>()

        for (i in 0 until rowCount) {
            val rawName = names[i].trim()
            if (rawName.isBlank()) {
                result.add(
                    BulkWizardRow(
                        index = i + 1,
                        name = "",
                        card = null,
                        dynamicValues = emptyMap(),
                        status = BulkWizardStatus.ERROR_EMPTY_NAME,
                        statusMessage = "الاسم فارغ (مرفوض)"
                    )
                )
                continue
            }

            val rawCard = cards.getOrNull(i)?.trim() ?: ""
            val cleanCard = ArabicNormalizer.cleanCardNumber(rawCard).ifBlank { null }
            val normName = ArabicNormalizer.normalizeArabic(rawName)

            val dynamicRowMap = mutableMapOf<String, String>()
            for ((colId, valuesList) in dynamicColumnsValues) {
                val v = valuesList.getOrNull(i)?.trim() ?: ""
                if (v.isNotBlank()) {
                    dynamicRowMap[colId] = v
                }
            }

            // 1. Intra-batch duplicate check
            if (cleanCard != null && batchSeenCards.contains(cleanCard)) {
                result.add(
                    BulkWizardRow(
                        index = i + 1,
                        name = rawName,
                        card = cleanCard,
                        dynamicValues = dynamicRowMap,
                        status = BulkWizardStatus.ERROR_BATCH_DUPLICATE,
                        statusMessage = "رقم البطاقة ($cleanCard) مكرر في أكثر من سطر داخل القائمة (مرفوض)"
                    )
                )
                continue
            }

            if (batchSeenNames.contains(normName)) {
                result.add(
                    BulkWizardRow(
                        index = i + 1,
                        name = rawName,
                        card = cleanCard,
                        dynamicValues = dynamicRowMap,
                        status = BulkWizardStatus.ERROR_BATCH_DUPLICATE,
                        statusMessage = "الاسم ($rawName) مكرر في أكثر من سطر داخل القائمة (مرفوض)"
                    )
                )
                continue
            }

            // 2. Check against Database
            val existingWithName = dbNames[normName]
            val existingWithCard = if (cleanCard != null) dbCards[cleanCard] else null

            var status = BulkWizardStatus.VALID
            var msg = "سجل جديد - جاهز للإضافة إلى الكشف الحالي"
            var targetPersonId: Long? = null
            var targetSheetId: Long? = null
            var targetSheetTitle: String? = null

            if (existingWithName != null) {
                val origSheetTitle = allSheets[existingWithName.sheet_id]?.title ?: "كشف رقم ${existingWithName.sheet_id}"
                val existingCard = ArabicNormalizer.cleanCardNumber(existingWithName.unique_card_id).ifBlank { null }

                if (existingCard == null && cleanCard != null) {
                    // Existing person had NO card, incoming row has card
                    if (existingWithCard != null && existingWithCard.id != existingWithName.id) {
                        status = BulkWizardStatus.ERROR_CARD_DUPLICATE
                        msg = "رقم البطاقة ($cleanCard) مسجل لشخص آخر (${existingWithCard.primary_name}) - مرفوض"
                    } else {
                        status = BulkWizardStatus.UPDATE_EXISTING
                        msg = "مسجل سابقاً في كشف '$origSheetTitle' بدون بطاقة. سيتم تحديث سجله في كشفه الأصلي وإضافة البطاقة دون تكرار."
                        targetPersonId = existingWithName.id
                        targetSheetId = existingWithName.sheet_id
                        targetSheetTitle = origSheetTitle
                    }
                } else if (existingCard == null && cleanCard == null) {
                    val existingDyn = existingWithName.getDynamicData()
                    val hasNewFields = dynamicRowMap.any { (k, v) -> v.isNotBlank() && existingDyn[k].isNullOrBlank() }
                    if (hasNewFields) {
                        status = BulkWizardStatus.UPDATE_EXISTING
                        msg = "مسجل سابقاً في كشف '$origSheetTitle'. سيتم إكمال بياناته الناقصة في كشفه الأصلي دون تكرار."
                        targetPersonId = existingWithName.id
                        targetSheetId = existingWithName.sheet_id
                        targetSheetTitle = origSheetTitle
                    } else {
                        status = BulkWizardStatus.REJECTED_DUPLICATE
                        msg = "الاسم مسجل مسبقاً في كشف '$origSheetTitle' ببيانات مطابقة - تم رفضه وتجاوزه منعاً للتكرار"
                    }
                } else if (existingCard != null && existingCard == cleanCard) {
                    val existingDyn = existingWithName.getDynamicData()
                    val hasNewFields = dynamicRowMap.any { (k, v) -> v.isNotBlank() && existingDyn[k].isNullOrBlank() }
                    if (hasNewFields) {
                        status = BulkWizardStatus.UPDATE_EXISTING
                        msg = "مسجل سابقاً في كشف '$origSheetTitle'. سيتم تحديث الحقول الناقصة في كشفه الأصلي دون تكرار."
                        targetPersonId = existingWithName.id
                        targetSheetId = existingWithName.sheet_id
                        targetSheetTitle = origSheetTitle
                    } else {
                        status = BulkWizardStatus.REJECTED_DUPLICATE
                        msg = "الاسم ورقم البطاقة مسجلان مسبقاً في كشف '$origSheetTitle' - تم رفضه وتجاوزه منعاً للتكرار"
                    }
                } else if (existingCard != null && cleanCard == null) {
                    status = BulkWizardStatus.REJECTED_DUPLICATE
                    msg = "الاسم مسجل مسبقاً مع بطاقة في كشف '$origSheetTitle' - تم رفضه وتجاوزه منعاً للتكرار"
                } else {
                    status = BulkWizardStatus.ERROR_CARD_DUPLICATE
                    msg = "تعارض: الاسم مسجل في كشف '$origSheetTitle' ببطاقة مختلفة عن المدخل ($cleanCard) - مرفوض"
                }
            } else if (existingWithCard != null) {
                val cardHolderSheet = allSheets[existingWithCard.sheet_id]?.title ?: "كشف آخر"
                status = BulkWizardStatus.ERROR_CARD_DUPLICATE
                msg = "رقم البطاقة ($cleanCard) مسجل مسبقاً باسم '${existingWithCard.primary_name}' في كشف '$cardHolderSheet' - مرفوض"
            }

            if (cleanCard != null) batchSeenCards.add(cleanCard)
            batchSeenNames.add(normName)

            result.add(
                BulkWizardRow(
                    index = i + 1,
                    name = rawName,
                    card = cleanCard,
                    dynamicValues = dynamicRowMap,
                    status = status,
                    statusMessage = msg,
                    targetPersonId = targetPersonId,
                    targetSheetId = targetSheetId,
                    targetSheetTitle = targetSheetTitle
                )
            )
        }

        result
    }

    fun saveBulkWizardRows(
        sheetId: Long,
        rowsToSave: List<BulkWizardRow>,
        onSuccess: (insertedCount: Int, updatedCount: Int, skippedCount: Int) -> Unit
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val allPersons = repository.getAllPersonsList()
            val personsToInsert = mutableListOf<PersonEntity>()
            val personsToUpdate = mutableListOf<PersonEntity>()
            var skippedCount = 0

            for (row in rowsToSave) {
                when (row.status) {
                    BulkWizardStatus.VALID -> {
                        personsToInsert.add(
                            PersonEntity(
                                sheet_id = sheetId,
                                primary_name = row.name,
                                unique_card_id = row.card,
                                dynamic_data_map = PersonEntity.mapToJsonString(row.dynamicValues),
                                timestamp = System.currentTimeMillis()
                            )
                        )
                    }
                    BulkWizardStatus.UPDATE_EXISTING -> {
                        val existing = allPersons.find { it.id == row.targetPersonId }
                        if (existing != null) {
                            val mergedDynamic = existing.getDynamicData().toMutableMap()
                            row.dynamicValues.forEach { (k, v) ->
                                if (v.isNotBlank()) mergedDynamic[k] = v
                            }
                            val updated = existing.copy(
                                // CRITICAL: PRESERVE EXACT ORIGINAL SHEET
                                sheet_id = existing.sheet_id,
                                unique_card_id = if (!row.card.isNullOrBlank()) row.card else existing.unique_card_id,
                                dynamic_data_map = PersonEntity.mapToJsonString(mergedDynamic),
                                timestamp = System.currentTimeMillis()
                            )
                            personsToUpdate.add(updated)
                        } else {
                            skippedCount++
                        }
                    }
                    else -> {
                        // REJECTED_DUPLICATE or any ERROR: Skip!
                        skippedCount++
                    }
                }
            }

            if (personsToInsert.isNotEmpty()) {
                repository.insertPersons(personsToInsert)
            }
            if (personsToUpdate.isNotEmpty()) {
                repository.updatePersons(personsToUpdate)
            }

            withContext(Dispatchers.Main) {
                onSuccess(personsToInsert.size, personsToUpdate.size, skippedCount)
            }
        }
    }

    // -------------------------------------------------------------------------
    // 8. Dynamic Export System (XLSX, CSV, PDF)
    // -------------------------------------------------------------------------
    fun exportData(
        context: Context,
        scope: ExportScope,
        format: ExportFormat
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val allSheets = repository.getAllSheetsList().associateBy { it.id }
            val active = activeSheet.value

            val (title, headers, rows) = buildExportDataset(scope, active, allSheets)

            val safeTitle = title.replace(Regex("[^a-zA-Z0-9\\u0600-\\u06FF]"), "_")

            when (format) {
                ExportFormat.EXCEL -> {
                    val fileName = "${safeTitle}_${System.currentTimeMillis()}.xlsx"
                    FileSharingHelper.shareFile(context, fileName, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") { fos ->
                        ExcelEngine.exportToXlsx(headers, rows, fos)
                    }
                }
                ExportFormat.CSV -> {
                    val fileName = "${safeTitle}_${System.currentTimeMillis()}.csv"
                    FileSharingHelper.shareFile(context, fileName, "text/csv") { fos ->
                        ExcelEngine.exportToCsv(headers, rows, fos)
                    }
                }
                ExportFormat.PDF -> {
                    val fileName = "${safeTitle}_${System.currentTimeMillis()}.pdf"
                    FileSharingHelper.shareFile(context, fileName, "application/pdf") { fos ->
                        PdfExporter.exportToPdf(context, title, headers, rows, fos)
                    }
                }
            }
        }
    }

    private suspend fun buildExportDataset(
        scope: ExportScope,
        activeSheet: SheetEntity?,
        allSheetsMap: Map<Long, SheetEntity>
    ): Triple<String, List<String>, List<List<String>>> {
        return if (scope == ExportScope.ACTIVE_SHEET && activeSheet != null) {
            val dynamicCols = activeSheet.getDynamicColumns()
            val headers = mutableListOf<String>()
            headers.add("الاسم")
            headers.add("رقم البطاقة")
            for (c in dynamicCols) {
                headers.add(c.name)
            }

            val persons = repository.getPersonsBySheetList(activeSheet.id)
                .sortedWith(compareBy { ArabicNormalizer.normalizeArabic(it.primary_name) })

            val rows = persons.map { p ->
                val dyn = p.getDynamicData()
                val r = mutableListOf<String>()
                r.add(p.primary_name)
                r.add(p.unique_card_id ?: "")
                for (c in dynamicCols) {
                    r.add(dyn[c.id] ?: "")
                }
                r
            }
            Triple(activeSheet.title, headers, rows)
        } else {
            // ALL SHEETS
            // Collect all unique dynamic columns across sheets
            val allPersons = repository.getAllPersonsList()
                .sortedWith(compareBy({ it.sheet_id }, { ArabicNormalizer.normalizeArabic(it.primary_name) }))
            val headers = mutableListOf<String>()
            headers.add("اسم الكشف")
            headers.add("الاسم الرباعي")
            headers.add("رقم البطاقة")

            // Collect all column names
            val colMap = mutableMapOf<String, String>() // colId to colName
            for (s in allSheetsMap.values) {
                for (c in s.getDynamicColumns()) {
                    colMap[c.id] = c.name
                }
            }
            for (colName in colMap.values.distinct()) {
                headers.add(colName)
            }

            val distinctColNames = colMap.values.distinct()

            val rows = allPersons.map { p ->
                val sTitle = allSheetsMap[p.sheet_id]?.title ?: "غير معروف"
                val dyn = p.getDynamicData()
                val r = mutableListOf<String>()
                r.add(sTitle)
                r.add(p.primary_name)
                r.add(p.unique_card_id ?: "")

                // Fill by distinct column names
                for (targetColName in distinctColNames) {
                    val matchingKey = dyn.keys.find { k -> colMap[k] == targetColName }
                    r.add(matchingKey?.let { dyn[it] } ?: "")
                }
                r
            }
            Triple("كافة_الكشوفات_والسجلات", headers, rows)
        }
    }

    // -------------------------------------------------------------------------
    // 9. Full System Backup & Restore (JSON)
    // -------------------------------------------------------------------------
    fun exportBackup(context: Context) {
        viewModelScope.launch(Dispatchers.IO) {
            val json = repository.exportAllDataAsJson()
            val fileName = "backup_sheets_registry_${System.currentTimeMillis()}.json"
            FileSharingHelper.shareFile(context, fileName, "application/json") { fos ->
                fos.write(json.toByteArray(Charsets.UTF_8))
            }
        }
    }

    fun restoreBackup(jsonString: String, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val success = repository.restoreAllDataFromJson(jsonString)
            if (success) {
                val sheets = repository.getAllSheetsList()
                _activeSheetId.value = sheets.firstOrNull()?.id
                onResult(true, "تمت استعادة كافة البيانات بنجاح.")
            } else {
                onResult(false, "فشلت استعادة البيانات. يرجى التحقق من تنسيق ملف النسخة الاحتياطية.")
            }
        }
    }
}
