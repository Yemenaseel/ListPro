package com.example.util

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import androidx.core.content.res.ResourcesCompat
import com.example.R
import java.io.OutputStream

/**
 * PDF Exporter providing layout and typography matching the official registry format:
 * - Dynamic orientation: Landscape if columns > 4, Portrait if columns <= 4.
 * - Sheet title centered at the top in PT Bold Heading size 16.
 * - RTL table with auto-numbering column 'م' on the far right.
 * - Table header in #D9D9D9 background with solid black borders and PT Bold Heading size 16.
 * - Strict black grid borders for all data rows and cells.
 */
object PdfExporter {

    fun exportToPdf(
        context: Context,
        title: String,
        headers: List<String>,
        rows: List<List<String>>,
        outputStream: OutputStream
    ) {
        // Complete table columns: 'م' on the far right, followed by user columns
        val fullHeaders = mutableListOf<String>()
        fullHeaders.add("م")
        fullHeaders.addAll(headers)

        val totalColumns = fullHeaders.size

        // Orientation rule: > 4 columns -> Landscape, <= 4 columns -> Portrait
        val isLandscape = totalColumns > 4
        val pageWidth = if (isLandscape) 842 else 595
        val pageHeight = if (isLandscape) 595 else 842
        val margin = 32f

        val document = PdfDocument()

        // Load PT Bold Heading font or fallback to bold
        val ptBoldHeadingTypeface = try {
            ResourcesCompat.getFont(context, R.font.pt_bold_heading) ?: Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        } catch (_: Exception) {
            Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }

        // Paints
        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            textSize = 16f
            typeface = ptBoldHeadingTypeface
            textAlign = Paint.Align.CENTER
        }

        val headerTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            textSize = 14f
            typeface = ptBoldHeadingTypeface
            textAlign = Paint.Align.CENTER
        }

        val headerBgPaint = Paint().apply {
            color = Color.parseColor("#D9D9D9")
            style = Paint.Style.FILL
        }

        val cellBorderPaint = Paint().apply {
            color = Color.BLACK
            strokeWidth = 1f
            style = Paint.Style.STROKE
        }

        val cellTextBoldPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            textSize = 11f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }

        val cellTextRegularPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            textSize = 11f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        }

        val footerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.DKGRAY
            textSize = 9f
            textAlign = Paint.Align.CENTER
        }

        // Available table width
        val availableWidth = pageWidth - (margin * 2)

        // Calculate RTL column widths:
        // Index 0: 'م' (approx 36-40pt)
        // Index 1: 'الاسم' (large width)
        // Index 2: 'رقم البطاقة'
        // Index 3..: dynamic custom columns
        val colWidths = calculateRtlColumnWidths(fullHeaders, availableWidth)

        val headerHeight = 32f
        val rowHeight = 25f
        val startY = 68f
        val bottomMargin = 36f

        val maxRowsPerPage = ((pageHeight - startY - bottomMargin - headerHeight) / rowHeight).toInt().coerceAtLeast(1)
        val totalPages = if (rows.isEmpty()) 1 else ((rows.size + maxRowsPerPage - 1) / maxRowsPerPage).coerceAtLeast(1)

        var currentRowIdx = 0

        for (pageNumber in 1..totalPages) {
            val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
            val page = document.startPage(pageInfo)
            val canvas = page.canvas

            // 1. Title: Centered at top, PT Bold Heading 16pt
            canvas.drawText(title, pageWidth / 2f, 44f, titlePaint)

            // 2. Table Header
            var y = startY
            drawTableHeader(
                canvas = canvas,
                headers = fullHeaders,
                colWidths = colWidths,
                startY = y,
                headerHeight = headerHeight,
                margin = margin,
                pageWidth = pageWidth,
                bgPaint = headerBgPaint,
                borderPaint = cellBorderPaint,
                textPaint = headerTextPaint
            )
            y += headerHeight

            // 3. Table Rows
            val rowsForThisPage = minOf(maxRowsPerPage, rows.size - currentRowIdx)
            for (i in 0 until rowsForThisPage) {
                val rowNumber = currentRowIdx + 1
                val rawRowData = rows[currentRowIdx]

                // Full row: [rowNumber] + rawRowData
                val fullRowData = mutableListOf<String>()
                fullRowData.add(rowNumber.toString())
                fullRowData.addAll(rawRowData)

                drawTableRow(
                    canvas = canvas,
                    fullRowData = fullRowData,
                    colWidths = colWidths,
                    startY = y,
                    rowHeight = rowHeight,
                    margin = margin,
                    pageWidth = pageWidth,
                    borderPaint = cellBorderPaint,
                    boldPaint = cellTextBoldPaint,
                    regularPaint = cellTextRegularPaint
                )

                y += rowHeight
                currentRowIdx++
            }

            // 4. Footer
            val footerText = "صفحة $pageNumber من $totalPages"
            canvas.drawText(footerText, pageWidth / 2f, pageHeight - 16f, footerPaint)

            document.finishPage(page)
        }

        document.writeTo(outputStream)
        document.close()
    }

    private fun calculateRtlColumnWidths(headers: List<String>, availableWidth: Float): List<Float> {
        val count = headers.size
        if (count == 0) return emptyList()

        val widths = MutableList(count) { 0f }
        // Col 0: 'م' (serial number)
        widths[0] = 38f

        val remainingWidth = (availableWidth - widths[0]).coerceAtLeast(100f)

        if (count == 1) {
            widths[0] = availableWidth
            return widths
        }

        // If count == 2: 'م' + 'الاسم'
        if (count == 2) {
            widths[1] = remainingWidth
            return widths
        }

        // If count == 3: 'م' + 'الاسم' + 'رقم البطاقة'
        if (count == 3) {
            widths[1] = remainingWidth * 0.60f
            widths[2] = remainingWidth * 0.40f
            return widths
        }

        // If count >= 4: 'م' + 'الاسم' + 'رقم البطاقة' + dynamic columns
        val otherColsCount = count - 3
        val nameWidth = remainingWidth * 0.40f
        val cardWidth = remainingWidth * 0.28f
        val remainingForOthers = (remainingWidth - nameWidth - cardWidth).coerceAtLeast(otherColsCount * 40f)
        val eachOtherWidth = remainingForOthers / otherColsCount

        widths[1] = nameWidth
        widths[2] = cardWidth
        for (i in 3 until count) {
            widths[i] = eachOtherWidth
        }

        return widths
    }

    private fun drawTableHeader(
        canvas: Canvas,
        headers: List<String>,
        colWidths: List<Float>,
        startY: Float,
        headerHeight: Float,
        margin: Float,
        pageWidth: Int,
        bgPaint: Paint,
        borderPaint: Paint,
        textPaint: Paint
    ) {
        val totalTableWidth = colWidths.sum()
        val rightX = (pageWidth - margin)

        // Draw header background rectangle
        canvas.drawRect(
            rightX - totalTableWidth,
            startY,
            rightX,
            startY + headerHeight,
            bgPaint
        )

        // Draw cells from Right to Left (RTL)
        var currentRight = rightX
        for (i in headers.indices) {
            val w = colWidths[i]
            val left = currentRight - w
            val right = currentRight
            val top = startY
            val bottom = startY + headerHeight

            // Cell border
            canvas.drawRect(left, top, right, bottom, borderPaint)

            // Header text centered horizontally & vertically
            val text = headers[i]
            val textY = top + (headerHeight / 2f) - ((textPaint.descent() + textPaint.ascent()) / 2f)
            val textX = left + (w / 2f)

            canvas.drawText(text, textX, textY, textPaint)

            currentRight -= w
        }
    }

    private fun drawTableRow(
        canvas: Canvas,
        fullRowData: List<String>,
        colWidths: List<Float>,
        startY: Float,
        rowHeight: Float,
        margin: Float,
        pageWidth: Int,
        borderPaint: Paint,
        boldPaint: Paint,
        regularPaint: Paint
    ) {
        val rightX = (pageWidth - margin)
        var currentRight = rightX

        for (i in colWidths.indices) {
            val w = colWidths[i]
            val left = currentRight - w
            val right = currentRight
            val top = startY
            val bottom = startY + rowHeight

            // Draw crisp solid black border
            canvas.drawRect(left, top, right, bottom, borderPaint)

            val text = if (i < fullRowData.size) fullRowData[i] else ""
            if (text.isNotBlank()) {
                val yPos = top + (rowHeight / 2f) - ((boldPaint.descent() + boldPaint.ascent()) / 2f)

                when (i) {
                    0 -> {
                        // 'م' column: Centered, Bold
                        boldPaint.textAlign = Paint.Align.CENTER
                        canvas.drawText(text, left + (w / 2f), yPos, boldPaint)
                    }
                    1 -> {
                        // 'الاسم' column: Bold, Right-aligned with slight padding
                        boldPaint.textAlign = Paint.Align.RIGHT
                        val paddingRight = 8f
                        canvas.drawText(text, right - paddingRight, yPos, boldPaint)
                    }
                    2 -> {
                        // 'رقم البطاقة': Centered, Bold
                        boldPaint.textAlign = Paint.Align.CENTER
                        canvas.drawText(text, left + (w / 2f), yPos, boldPaint)
                    }
                    else -> {
                        // Custom columns: Centered, Regular
                        regularPaint.textAlign = Paint.Align.CENTER
                        canvas.drawText(text, left + (w / 2f), yPos, regularPaint)
                    }
                }
            }

            currentRight -= w
        }
    }
}
