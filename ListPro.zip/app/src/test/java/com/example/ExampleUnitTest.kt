package com.example

import com.example.data.local.PersonDao
import com.example.data.local.SheetDao
import com.example.data.model.PersonEntity
import com.example.data.model.SheetEntity
import com.example.data.repository.DuplicateCheckResult
import com.example.data.service.DuplicationCheckService
import com.example.util.ArabicNormalizer
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testArabicNormalizer_AlefVariations() {
        val input = "أحمد إبراهيم آمنة ٱسماعيل"
        val expected = "احمد ابراهيم امنه اسماعيل"
        assertEquals(expected, ArabicNormalizer.normalizeArabic(input))
    }

    @Test
    fun testArabicNormalizer_TaaMarbuta() {
        val input = "فاطمة عائشة مكتبة"
        val expected = "فاطمه عائشه مكتبه"
        assertEquals(expected, ArabicNormalizer.normalizeArabic(input))
    }

    @Test
    fun testArabicNormalizer_AbdullahUnification() {
        val input1 = "عبد الله"
        val input2 = "عبــد الله"
        val input3 = "عبد  الله"
        assertEquals("عبدالله", ArabicNormalizer.normalizeArabic(input1))
        assertEquals("عبدالله", ArabicNormalizer.normalizeArabic(input2))
        assertEquals("عبدالله", ArabicNormalizer.normalizeArabic(input3))
    }

    @Test
    fun testArabicNormalizer_MultipleSpacesAndTatweel() {
        val input = "  محمــد    علــي   ســالم  "
        val expected = "محمد علي سالم"
        assertEquals(expected, ArabicNormalizer.normalizeArabic(input))
    }

    @Test
    fun testArabicNormalizer_CleanCardNumber() {
        val input = " (٠٥٩) - ٩١٢.٣٤٥ "
        val expected = "059912345"
        assertEquals(expected, ArabicNormalizer.cleanCardNumber(input))
    }

    @Test
    fun testDuplicationCheckService_CrossSheetValidation() = runBlocking {
        val sheets = listOf(
            SheetEntity(id = 1, title = "الكشف الأساسي", is_main = true),
            SheetEntity(id = 2, title = "كشف الموظفين", is_main = false)
        )

        val persons = listOf(
            PersonEntity(id = 101, sheet_id = 1, primary_name = "أحمد محمد عبدالله", unique_card_id = "987654"),
            PersonEntity(id = 102, sheet_id = 2, primary_name = "محمود حسن خليل", unique_card_id = "112233")
        )

        val fakeSheetDao = object : SheetDao {
            override fun getAllSheets(): Flow<List<SheetEntity>> = flowOf(sheets)
            override suspend fun getAllSheetsList(): List<SheetEntity> = sheets
            override suspend fun getSheetById(id: Long): SheetEntity? = sheets.find { it.id == id }
            override suspend fun getMainSheet(): SheetEntity? = sheets.find { it.is_main }
            override suspend fun getSheetCount(): Int = sheets.size
            override suspend fun insertSheet(sheet: SheetEntity): Long = sheet.id
            override suspend fun insertSheets(sheets: List<SheetEntity>): List<Long> = sheets.map { it.id }
            override suspend fun updateSheet(sheet: SheetEntity) {}
            override suspend fun deleteSheet(sheet: SheetEntity) {}
            override suspend fun deleteSheetById(id: Long) {}
            override suspend fun deleteAllSheets() {}
        }

        val fakePersonDao = object : PersonDao {
            override fun getPersonsBySheet(sheetId: Long): Flow<List<PersonEntity>> = flowOf(persons.filter { it.sheet_id == sheetId })
            override suspend fun getPersonsBySheetList(sheetId: Long): List<PersonEntity> = persons.filter { it.sheet_id == sheetId }
            override fun getAllPersons(): Flow<List<PersonEntity>> = flowOf(persons)
            override suspend fun getAllPersonsList(): List<PersonEntity> = persons
            override fun getDeletedPersons(): Flow<List<PersonEntity>> = flowOf(emptyList())
            override fun countDeletedPersons(): Flow<Int> = flowOf(0)
            override suspend fun getPersonById(id: Long): PersonEntity? = persons.find { it.id == id }
            override suspend fun insertPerson(person: PersonEntity): Long = person.id
            override suspend fun insertPersons(persons: List<PersonEntity>): List<Long> = persons.map { it.id }
            override suspend fun updatePerson(person: PersonEntity) {}
            override suspend fun updatePersons(persons: List<PersonEntity>) {}
            override suspend fun softDeletePerson(id: Long, deletedAt: Long) {}
            override suspend fun softDeletePersons(ids: List<Long>, deletedAt: Long) {}
            override suspend fun restorePerson(id: Long) {}
            override suspend fun restorePersons(ids: List<Long>) {}
            override suspend fun deletePermanently(id: Long) {}
            override suspend fun emptyRecycleBin() {}
            override suspend fun deletePersonsBySheet(sheetId: Long) {}
            override suspend fun movePersonsToSheet(ids: List<Long>, targetSheetId: Long) {}
            override suspend fun countPersonsInSheet(sheetId: Long): Int = persons.count { it.sheet_id == sheetId }
            override suspend fun countPersonsTotal(): Int = persons.size
            override suspend fun countPersonsWithCardInSheet(sheetId: Long): Int = persons.count { it.sheet_id == sheetId && !it.unique_card_id.isNullOrBlank() }
            override suspend fun countPersonsWithoutCardInSheet(sheetId: Long): Int = persons.count { it.sheet_id == sheetId && it.unique_card_id.isNullOrBlank() }
            override suspend fun deleteAllPersons() {}
        }

        val service = DuplicationCheckService(fakePersonDao, fakeSheetDao)

        // 1. Card clash across another sheet -> Rejection
        val cardClashResult = service.checkDuplicate(
            targetSheetId = 1,
            primaryName = "سالم علي مصطفى",
            cardId = "11-22-33" // exists in sheet 2
        )
        assertTrue(cardClashResult is DuplicateCheckResult.CardDuplicate)
        assertEquals("كشف الموظفين", (cardClashResult as DuplicateCheckResult.CardDuplicate).sheetTitle)

        // 2. Name clash in another sheet -> Rejection
        val otherSheetNameResult = service.checkDuplicate(
            targetSheetId = 1,
            primaryName = "محمود حسن خليل", // exists in sheet 2
            cardId = "555555"
        )
        assertTrue(otherSheetNameResult is DuplicateCheckResult.OtherSheetNameDuplicate)
        assertEquals("كشف الموظفين", (otherSheetNameResult as DuplicateCheckResult.OtherSheetNameDuplicate).sheetTitle)

        // 3. Name clash in the SAME sheet -> CurrentSheetDuplicate
        val sameSheetNameResult = service.checkDuplicate(
            targetSheetId = 1,
            primaryName = "احمد محمد عبد الله", // normalized matches "أحمد محمد عبدالله" in sheet 1
            cardId = null
        )
        assertTrue(sameSheetNameResult is DuplicateCheckResult.CurrentSheetDuplicate)

        // 4. Editing oneself without conflict -> Valid
        val selfEditResult = service.checkDuplicate(
            targetSheetId = 1,
            primaryName = "أحمد محمد عبدالله",
            cardId = "987654",
            editingPersonId = 101 // same person ID
        )
        assertTrue(selfEditResult is DuplicateCheckResult.Valid)

        // 5. Completely unique person -> Valid
        val uniqueResult = service.checkDuplicate(
            targetSheetId = 1,
            primaryName = "خالد عمر فاروق",
            cardId = "778899"
        )
        assertTrue(uniqueResult is DuplicateCheckResult.Valid)
    }

    @Test
    fun testBulkWizard_RowBindingAndMapping() {
        val names = listOf("محمد أحمد عبدالله علي", "أحمد خالد محمد حسن", "عبدالله سامي محمود صالح")
        val cards = listOf("123456789012", "274819563027", "583104927615")
        val dobValues = listOf("1998/04/17", "2001/09/23", "1995/12/08")

        val dynamicMap = mapOf("dob" to dobValues)

        // Verify parallel column row binding:
        assertEquals(3, names.size)
        assertEquals("محمد أحمد عبدالله علي", names[0])
        assertEquals("123456789012", cards[0])
        assertEquals("1998/04/17", dynamicMap["dob"]?.get(0))

        assertEquals("أحمد خالد محمد حسن", names[1])
        assertEquals("274819563027", cards[1])
        assertEquals("2001/09/23", dynamicMap["dob"]?.get(1))

        assertEquals("عبدالله سامي محمود صالح", names[2])
        assertEquals("583104927615", cards[2])
        assertEquals("1995/12/08", dynamicMap["dob"]?.get(2))
    }

    @Test
    fun testPdfAutoFitColumns_DistributionAndSum() {
        val headers = listOf("الاسم", "رقم البطاقة", "اسم الام", "تاريخ الميلاد", "المحافظة", "فصيلة الدم", "الهاتف", "المعرف")
        val fullHeaders = listOf("م") + headers
        val availableWidth = 842f - 48f // 794f in landscape A4

        // Serial column
        val serialWidth = 28f
        val remaining = availableWidth - serialWidth
        assertTrue(remaining > 700f)
        assertEquals(9, fullHeaders.size)
    }
}
