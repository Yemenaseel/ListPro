package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.DriveFileMove
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.FormatListNumbered
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.BottomSheetDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.model.ColumnType
import com.example.data.model.PersonEntity
import com.example.data.model.SheetEntity
import com.example.data.repository.DuplicateCheckResult
import com.example.ui.theme.AmberTertiary
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.TealSecondary
import kotlinx.coroutines.launch

/**
 * Dynamic ModalBottomSheet form that automatically generates text fields
 * based on the selected sheet's custom column definitions (TEXT, NUMBER).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditPersonBottomSheet(
    personToEdit: PersonEntity? = null,
    activeSheet: SheetEntity,
    allSheets: List<SheetEntity>,
    onDismiss: () -> Unit,
    onSavePerson: (
        primaryName: String,
        cardId: String?,
        dynamicData: Map<String, String>,
        forceCurrentSheetDuplicate: Boolean,
        onDuplicate: (DuplicateCheckResult) -> Unit,
        onSuccess: (String) -> Unit
    ) -> Unit,
    onMovePerson: (personId: Long, targetSheetId: Long) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val scope = rememberCoroutineScope()

    var primaryName by remember { mutableStateOf(personToEdit?.primary_name ?: "") }
    var uniqueCardId by remember { mutableStateOf(personToEdit?.unique_card_id ?: "") }

    // Map of dynamic columnId to value
    val dynamicValues = remember {
        mutableStateMapOf<String, String>().apply {
            personToEdit?.let { putAll(it.getDynamicData()) }
        }
    }

    var errorMessage by remember { mutableStateOf<String?>(null) }
    var currentSheetDuplicateWarning by remember { mutableStateOf<String?>(null) }
    var showMoveDialog by remember { mutableStateOf(false) }

    val dynamicColumns = activeSheet.getDynamicColumns()

    fun dismissSheet() {
        scope.launch {
            sheetState.hide()
            onDismiss()
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        dragHandle = { BottomSheetDefaults.DragHandle() },
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 6.dp,
        modifier = Modifier.imePadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp)
                .navigationBarsPadding()
                .padding(bottom = 32.dp)
        ) {
            // Header: Title & Active Sheet Tag
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (personToEdit == null) "إضافة شخص جديد" else "تعديل بيانات الشخص",
                        style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Surface(
                        color = NavyPrimary.copy(alpha = 0.1f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = "الكشف: ${activeSheet.title}",
                            style = MaterialTheme.typography.labelMedium.copy(
                                color = NavyPrimary,
                                fontWeight = FontWeight.SemiBold
                            ),
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }

                IconButton(
                    onClick = { dismissSheet() },
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Close,
                        contentDescription = "إغلاق النافذة",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // ==========================================
            // Section 1: Fixed Mandatory & System Fields
            // ==========================================
            Text(
                text = "البيانات الأساسية",
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Field: Primary Name (Full Arabic 4-part name)
            OutlinedTextField(
                value = primaryName,
                onValueChange = {
                    primaryName = it
                    errorMessage = null
                    currentSheetDuplicateWarning = null
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("person_name_input"),
                label = { Text("الاسم الكامل (رباعي) *") },
                placeholder = { Text("مثال: محمد أحمد علي سالم") },
                leadingIcon = {
                    Icon(Icons.Default.Person, contentDescription = null, tint = NavyPrimary)
                },
                trailingIcon = {
                    if (primaryName.isNotBlank()) {
                        IconButton(onClick = { primaryName = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "مسح", modifier = Modifier.size(18.dp))
                        }
                    }
                },
                singleLine = true,
                isError = errorMessage != null || currentSheetDuplicateWarning != null,
                shape = RoundedCornerShape(14.dp),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Text,
                    imeAction = if (dynamicColumns.isNotEmpty()) ImeAction.Next else ImeAction.Done
                )
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Field: Unique Card ID (Optional, Global Unique across all sheets)
            OutlinedTextField(
                value = uniqueCardId,
                onValueChange = {
                    uniqueCardId = it
                    errorMessage = null
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("person_card_input"),
                label = { Text("رقم البطاقة / الهوية (اختياري - فريد)") },
                placeholder = { Text("مثال: 987654321") },
                leadingIcon = {
                    Icon(Icons.Default.Badge, contentDescription = null, tint = TealSecondary)
                },
                trailingIcon = {
                    if (uniqueCardId.isNotBlank()) {
                        IconButton(onClick = { uniqueCardId = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "مسح", modifier = Modifier.size(18.dp))
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Ascii,
                    imeAction = if (dynamicColumns.isNotEmpty()) ImeAction.Next else ImeAction.Done
                )
            )

            Text(
                text = "يتم فحص رقم البطاقة تلقائياً لمنع تكراره عبر جميع الكشوفات.",
                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.outline),
                modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp)
            )

            Spacer(modifier = Modifier.height(20.dp))

            // ==========================================
            // Section 2: Dynamically Generated Custom Fields
            // ==========================================
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Tune,
                    contentDescription = null,
                    tint = TealSecondary,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "الحقول المخصصة للكشف (${dynamicColumns.size})",
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (dynamicColumns.isEmpty()) {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Info,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "لا توجد حقول مخصصة مضافة لهذا الكشف بعد. يمكنك إضافة حقول من شاشة 'إدارة الأعمدة'.",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                }
            } else {
                // Dynamically render an OutlinedTextField for each custom column
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    dynamicColumns.forEachIndexed { index, col ->
                        val currentValue = dynamicValues[col.id] ?: ""
                        val isNumber = col.type == ColumnType.NUMBER

                        OutlinedTextField(
                            value = currentValue,
                            onValueChange = { newVal ->
                                // For number columns, only accept digits or decimals
                                if (isNumber) {
                                    val cleaned = newVal.filter { it.isDigit() || it == '.' || it == '-' }
                                    dynamicValues[col.id] = cleaned
                                } else {
                                    dynamicValues[col.id] = newVal
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("dynamic_field_${col.id}"),
                            label = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(col.name)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Surface(
                                        color = if (isNumber) AmberTertiary.copy(alpha = 0.15f) else TealSecondary.copy(alpha = 0.15f),
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text(
                                            text = if (isNumber) "رقمي" else "نصي",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = if (isNumber) AmberTertiary else TealSecondary,
                                                fontWeight = FontWeight.Bold
                                            ),
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                        )
                                    }
                                }
                            },
                            placeholder = {
                                Text(if (isNumber) "أدخل قيمة عددية" else "أدخل النص هنا")
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = if (isNumber) Icons.Default.FormatListNumbered else Icons.Default.TextFields,
                                    contentDescription = null,
                                    tint = if (isNumber) AmberTertiary else TealSecondary
                                )
                            },
                            trailingIcon = {
                                if (currentValue.isNotBlank()) {
                                    IconButton(onClick = { dynamicValues[col.id] = "" }) {
                                        Icon(Icons.Default.Clear, contentDescription = "مسح", modifier = Modifier.size(16.dp))
                                    }
                                }
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            keyboardOptions = KeyboardOptions(
                                keyboardType = if (isNumber) KeyboardType.Number else KeyboardType.Text,
                                imeAction = if (index < dynamicColumns.size - 1) ImeAction.Next else ImeAction.Done
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // ==========================================
            // Validation & Duplication Alerts
            // ==========================================
            // 1. Error Banner (Rejection)
            AnimatedVisibility(
                visible = errorMessage != null,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                errorMessage?.let { err ->
                    Surface(
                        color = MaterialTheme.colorScheme.errorContainer,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Error, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = err,
                                style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onErrorContainer)
                            )
                        }
                    }
                }
            }

            // 2. Current Sheet Duplicate Warning
            AnimatedVisibility(
                visible = currentSheetDuplicateWarning != null,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                currentSheetDuplicateWarning?.let { warn ->
                    Surface(
                        color = AmberTertiary.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Warning, contentDescription = null, tint = AmberTertiary)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = warn,
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = AmberTertiary,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "الاسم مكرر في هذا الكشف. يمكنك التأكيد والاستمرار في الحفظ أو التعديل.",
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                Button(
                                    onClick = {
                                        onSavePerson(
                                            primaryName,
                                            uniqueCardId.takeIf { it.isNotBlank() },
                                            dynamicValues.toMap(),
                                            true, // forceCurrentSheetDuplicate
                                            { dupResult ->
                                                when (dupResult) {
                                                    is DuplicateCheckResult.CardDuplicate -> errorMessage = dupResult.message
                                                    is DuplicateCheckResult.OtherSheetNameDuplicate -> errorMessage = dupResult.message
                                                    else -> {}
                                                }
                                            },
                                            { dismissSheet() }
                                        )
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = AmberTertiary),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("تأكيد الحفظ رغم التكرار")
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // ==========================================
            // Action Buttons
            // ==========================================
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Save Button
                Button(
                    onClick = {
                        if (primaryName.isBlank()) {
                            errorMessage = "يرجى إدخال الاسم الكامل للشخص"
                            return@Button
                        }
                        errorMessage = null
                        currentSheetDuplicateWarning = null

                        onSavePerson(
                            primaryName,
                            uniqueCardId.takeIf { it.isNotBlank() },
                            dynamicValues.toMap(),
                            false,
                            { dupResult ->
                                when (dupResult) {
                                    is DuplicateCheckResult.CardDuplicate -> errorMessage = dupResult.message
                                    is DuplicateCheckResult.OtherSheetNameDuplicate -> errorMessage = dupResult.message
                                    is DuplicateCheckResult.CurrentSheetDuplicate -> currentSheetDuplicateWarning = dupResult.message
                                    DuplicateCheckResult.Valid -> {}
                                }
                            },
                            { dismissSheet() }
                        )
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("save_person_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = if (personToEdit == null) "حفظ السجل" else "تحديث البيانات",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                }

                // If editing, allow moving to another sheet directly
                if (personToEdit != null && allSheets.size > 1) {
                    FilledTonalButton(
                        onClick = { showMoveDialog = true },
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.DriveFileMove, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("نقل لكشف")
                    }
                }

                // Cancel Button
                OutlinedButton(
                    onClick = { dismissSheet() },
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("إلغاء")
                }
            }
        }
    }

    // Move to another sheet selection dialog
    if (showMoveDialog && personToEdit != null) {
        val targetSheets = allSheets.filterNot { it.id == activeSheet.id }
        var selectedSheetId by remember { mutableStateOf(targetSheets.firstOrNull()?.id ?: 0L) }

        AlertDialog(
            onDismissRequest = { showMoveDialog = false },
            title = { Text("اختر الكشف المراد النقل إليه") },
            text = {
                Column {
                    Text("سيتم نقل السجل '${personToEdit.primary_name}' إلى الكشف المحدد:")
                    Spacer(modifier = Modifier.height(12.dp))
                    for (sheet in targetSheets) {
                        Surface(
                            onClick = { selectedSheetId = sheet.id },
                            shape = RoundedCornerShape(10.dp),
                            color = if (selectedSheetId == sheet.id) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Text(
                                text = sheet.title,
                                modifier = Modifier.padding(14.dp),
                                fontWeight = if (selectedSheetId == sheet.id) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onMovePerson(personToEdit.id, selectedSheetId)
                        showMoveDialog = false
                        dismissSheet()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary)
                ) {
                    Text("نقل الآن")
                }
            },
            dismissButton = {
                TextButton(onClick = { showMoveDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }
}
