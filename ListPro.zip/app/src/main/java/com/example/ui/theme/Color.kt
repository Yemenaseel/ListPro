package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val NavyPrimary = Color(0xFF1E3A8A)
val NavyPrimaryVariant = Color(0xFF172554)
val NavyLight = Color(0xFF3B82F6)

val TealSecondary = Color(0xFF0D9488)
val TealLight = Color(0xFF14B8A6)
val AmberTertiary = Color(0xFFD97706)

val SuccessGreen = Color(0xFF10B981)
val ErrorRed = Color(0xFFDC2626)
val WarningOrange = Color(0xFFEA580C)

val Slate50 = Color(0xFFF8FAFC)
val Slate100 = Color(0xFFF1F5F9)
val Slate200 = Color(0xFFE2E8F0)
val Slate300 = Color(0xFFCBD5E1)
val Slate600 = Color(0xFF475569)
val Slate700 = Color(0xFF334155)
val Slate800 = Color(0xFF1E293B)
val Slate900 = Color(0xFF0F172A)
