package com.example.data.local

import android.content.Context
import android.content.SharedPreferences
import java.security.MessageDigest

/**
 * Handles persistent authentication storage.
 * Master password is not hardcoded; created on first use,
 * and changeable from settings.
 */
class AuthPreferences(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("app_auth_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_PASSWORD_HASH = "master_password_hash"
    }

    private fun hashPassword(password: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val bytes = digest.digest(password.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    fun isPasswordSet(): Boolean {
        return prefs.contains(KEY_PASSWORD_HASH) && !prefs.getString(KEY_PASSWORD_HASH, null).isNullOrBlank()
    }

    fun setMasterPassword(password: String): Boolean {
        if (password.isBlank()) return false
        val hash = hashPassword(password)
        prefs.edit().putString(KEY_PASSWORD_HASH, hash).apply()
        return true
    }

    fun verifyPassword(password: String): Boolean {
        val savedHash = prefs.getString(KEY_PASSWORD_HASH, null) ?: return false
        return hashPassword(password) == savedHash
    }

    fun changePassword(oldPassword: String, newPassword: String): Boolean {
        if (!verifyPassword(oldPassword)) return false
        return setMasterPassword(newPassword)
    }
}
