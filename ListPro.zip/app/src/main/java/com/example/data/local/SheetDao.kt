package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.SheetEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface SheetDao {
    @Query("SELECT * FROM sheets ORDER BY is_main DESC, id ASC")
    fun getAllSheets(): Flow<List<SheetEntity>>

    @Query("SELECT * FROM sheets ORDER BY is_main DESC, id ASC")
    suspend fun getAllSheetsList(): List<SheetEntity>

    @Query("SELECT * FROM sheets WHERE id = :id LIMIT 1")
    suspend fun getSheetById(id: Long): SheetEntity?

    @Query("SELECT * FROM sheets WHERE is_main = 1 LIMIT 1")
    suspend fun getMainSheet(): SheetEntity?

    @Query("SELECT COUNT(*) FROM sheets")
    suspend fun getSheetCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSheet(sheet: SheetEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSheets(sheets: List<SheetEntity>): List<Long>

    @Update
    suspend fun updateSheet(sheet: SheetEntity)

    @Delete
    suspend fun deleteSheet(sheet: SheetEntity)

    @Query("DELETE FROM sheets WHERE id = :id")
    suspend fun deleteSheetById(id: Long)

    @Query("DELETE FROM sheets")
    suspend fun deleteAllSheets()
}
