package com.example.data.service

import com.example.data.local.PersonDao
import com.example.data.local.SheetDao
import com.example.data.model.PersonEntity
import com.example.data.repository.DuplicateCheckResult
import com.example.util.ArabicNormalizer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Service responsible for cross-sheet duplication validation.
 *
 * Rules:
 * 1. Card Check (UniqueCardId):
 *    - If card number exists anywhere in the DB (for a different person), REJECT with:
 *      "رقم البطاقة مستخدم لشخص آخر ([الاسم]) في كشف: [اسم الكشف]".
 *
 * 2. Name Check (PrimaryName):
 *    - Normalized using ArabicNormalizer.
 *    - If the normalized name exists in another sheet, REJECT with:
 *      "الاسم مسجل مسبقاً في كشف: [اسم الكشف]".
 *    - If the normalized name exists in the active sheet, warn:
 *      "الاسم مكرر في الكشف الحالي" (allowing confirmation/update).
 */
class DuplicationCheckService(
    private val personDao: PersonDao,
    private val sheetDao: SheetDao
) {

    /**
     * Checks both Primary Name and Unique Card ID across the entire database (all sheets).
     */
    suspend fun checkDuplicate(
        targetSheetId: Long,
        primaryName: String,
        cardId: String?,
        editingPersonId: Long? = null
    ): DuplicateCheckResult = withContext(Dispatchers.IO) {
        val cleanedCard = ArabicNormalizer.cleanCardNumber(cardId)
        val normalizedName = ArabicNormalizer.normalizeArabic(primaryName)

        val allSheetsMap = sheetDao.getAllSheetsList().associateBy { it.id }
        val allPersons = personDao.getAllPersonsList()

        // 1. Global Card Check across ALL sheets
        if (cleanedCard.isNotBlank()) {
            for (p in allPersons) {
                if (editingPersonId != null && p.id == editingPersonId) continue
                val existingCleanedCard = ArabicNormalizer.cleanCardNumber(p.unique_card_id)
                if (existingCleanedCard == cleanedCard) {
                    val sheetName = allSheetsMap[p.sheet_id]?.title ?: "غير معروف"
                    return@withContext DuplicateCheckResult.CardDuplicate(
                        sheetTitle = sheetName,
                        personName = p.primary_name,
                        message = "رقم البطاقة مستخدم لشخص آخر (${p.primary_name}) في كشف: $sheetName"
                    )
                }
            }
        }

        // 2. Global Name Check across ALL sheets
        if (normalizedName.isNotBlank()) {
            var currentSheetDuplicatePerson: PersonEntity? = null

            for (p in allPersons) {
                if (editingPersonId != null && p.id == editingPersonId) continue
                val existingNormalizedName = ArabicNormalizer.normalizeArabic(p.primary_name)
                if (existingNormalizedName == normalizedName) {
                    if (p.sheet_id != targetSheetId) {
                        val otherSheetName = allSheetsMap[p.sheet_id]?.title ?: "غير معروف"
                        return@withContext DuplicateCheckResult.OtherSheetNameDuplicate(
                            sheetTitle = otherSheetName,
                            message = "الاسم مسجل مسبقاً في كشف: $otherSheetName"
                        )
                    } else {
                        currentSheetDuplicatePerson = p
                    }
                }
            }

            if (currentSheetDuplicatePerson != null) {
                return@withContext DuplicateCheckResult.CurrentSheetDuplicate(
                    existingPerson = currentSheetDuplicatePerson,
                    message = "الاسم مكرر في الكشف الحالي"
                )
            }
        }

        DuplicateCheckResult.Valid
    }
}
