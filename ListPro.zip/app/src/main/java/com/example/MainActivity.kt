package com.example

import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.local.AppDatabase
import com.example.data.local.AuthPreferences
import com.example.data.model.PersonEntity
import com.example.data.repository.RegistryRepository
import com.example.ui.components.AddEditPersonBottomSheet
import com.example.ui.components.AddEditPersonDialog
import com.example.ui.components.BulkAddWizardDialog
import com.example.ui.components.ChangePasswordDialog
import com.example.ui.components.ExcelColumnMappingDialog
import com.example.ui.components.SheetSelectorDialog
import com.example.ui.screens.BackupRestoreDialog
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.ExportOptionsDialog
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.ManageColumnsScreen
import com.example.ui.screens.RecordsScreen
import com.example.ui.screens.StatisticsScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.RegistryViewModel
import com.example.ui.viewmodel.RegistryViewModelFactory
import com.example.util.ExcelEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class AppScreen {
    DASHBOARD,
    RECORDS,
    MANAGE_COLUMNS,
    STATISTICS
}

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                AppRoot()
            }
        }
    }

    @Composable
    private fun AppRoot() {
        val context = this@MainActivity
        val scope = rememberCoroutineScope()

        val database = remember { AppDatabase.getDatabase(context.applicationContext) }
        val repository = remember { RegistryRepository(database) }
        val authPreferences = remember { AuthPreferences(context.applicationContext) }
        val viewModel: RegistryViewModel = viewModel(
            factory = RegistryViewModelFactory(repository, authPreferences)
        )

        val isPasswordSet by viewModel.isPasswordSet.collectAsState()
        val isAuthenticated by viewModel.isAuthenticated.collectAsState()
        val loginError by viewModel.loginError.collectAsState()

        val sheets by viewModel.sheets.collectAsState()
        val activeSheetId by viewModel.activeSheetId.collectAsState()
        val activeSheet by viewModel.activeSheet.collectAsState()

        val personsInActiveSheet by viewModel.personsInActiveSheet.collectAsState()
        val filteredPersons by viewModel.filteredPersons.collectAsState()
        val searchQuery by viewModel.searchQuery.collectAsState()
        val filterMode by viewModel.filterMode.collectAsState()

        val statistics by viewModel.statistics.collectAsState()
        val importPreviewTable by viewModel.importPreviewTable.collectAsState()
        val isImporting by viewModel.isImporting.collectAsState()
        val importSummaryMessage by viewModel.importSummaryMessage.collectAsState()

        var currentScreen by remember { mutableStateOf(AppScreen.DASHBOARD) }

        // Dialog states
        var showSheetSelector by remember { mutableStateOf(false) }
        var showAddEditPersonDialog by remember { mutableStateOf(false) }
        var showBulkAddWizard by remember { mutableStateOf(false) }
        var personToEdit by remember { mutableStateOf<PersonEntity?>(null) }
        var showExportDialog by remember { mutableStateOf(false) }
        var showBackupDialog by remember { mutableStateOf(false) }
        var showChangePasswordDialog by remember { mutableStateOf(false) }

        // Excel file picker
        val pickExcelLauncher = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.GetContent()
        ) { uri: Uri? ->
            if (uri != null) {
                scope.launch(Dispatchers.IO) {
                    try {
                        val parsed = ExcelEngine.readExcel(context, uri)
                        withContext(Dispatchers.Main) {
                            if (parsed.headers.isEmpty()) {
                                Toast.makeText(context, "ملف الإكسل فارغ أو غير متوافق.", Toast.LENGTH_LONG).show()
                            } else {
                                viewModel.setImportPreview(parsed)
                            }
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                        withContext(Dispatchers.Main) {
                            Toast.makeText(context, "خطأ في قراءة ملف الإكسل: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                        }
                    }
                }
            }
        }

        // Backup restore file picker
        val pickJsonRestoreLauncher = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.GetContent()
        ) { uri: Uri? ->
            if (uri != null) {
                scope.launch(Dispatchers.IO) {
                    try {
                        val jsonString = context.contentResolver.openInputStream(uri)?.use { stream ->
                            stream.bufferedReader().readText()
                        } ?: ""
                        withContext(Dispatchers.Main) {
                            viewModel.restoreBackup(jsonString) { success, msg ->
                                Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                            }
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                        withContext(Dispatchers.Main) {
                            Toast.makeText(context, "خطأ في قراءة ملف النسخة الاحتياطية", Toast.LENGTH_LONG).show()
                        }
                    }
                }
            }
        }

        // Handle Back button for secondary screens
        if (isAuthenticated && currentScreen != AppScreen.DASHBOARD) {
            BackHandler {
                currentScreen = AppScreen.DASHBOARD
            }
        }

        Box(modifier = Modifier.fillMaxSize()) {
            if (!isAuthenticated) {
                LoginScreen(
                    isPasswordSet = isPasswordSet,
                    onLoginSuccess = { viewModel.clearLoginError() },
                    loginError = loginError,
                    onAttemptLogin = { password -> viewModel.login(password) },
                    onSetupPassword = { password -> viewModel.setupMasterPassword(password) },
                    onClearError = { viewModel.clearLoginError() }
                )
            } else {
                when (currentScreen) {
                    AppScreen.DASHBOARD -> {
                        DashboardScreen(
                            activeSheet = activeSheet,
                            sheets = sheets,
                            personsInActiveSheet = personsInActiveSheet,
                            isImporting = isImporting,
                            importSummaryMessage = importSummaryMessage,
                            onClearImportSummary = { viewModel.clearImportSummary() },
                            onOpenSheetSelector = { showSheetSelector = true },
                            onNavigateToAddPerson = {
                                personToEdit = null
                                showAddEditPersonDialog = true
                            },
                            onNavigateToRecords = { currentScreen = AppScreen.RECORDS },
                            onNavigateToImportExcel = { pickExcelLauncher.launch("*/*") },
                            onNavigateToExport = { showExportDialog = true },
                            onNavigateToColumns = { currentScreen = AppScreen.MANAGE_COLUMNS },
                            onNavigateToStatistics = { currentScreen = AppScreen.STATISTICS },
                            onNavigateToBackup = { showBackupDialog = true },
                            onChangePasswordClick = { showChangePasswordDialog = true },
                            onLogout = { viewModel.logout() }
                        )
                    }

                    AppScreen.RECORDS -> {
                        RecordsScreen(
                            activeSheet = activeSheet,
                            persons = filteredPersons,
                            searchQuery = searchQuery,
                            filterMode = filterMode,
                            onSearchChange = { viewModel.setSearchQuery(it) },
                            onFilterChange = { viewModel.setFilterMode(it) },
                            onBack = { currentScreen = AppScreen.DASHBOARD },
                            onAddPersonClick = {
                                personToEdit = null
                                showAddEditPersonDialog = true
                            },
                            onBulkAddClick = {
                                showBulkAddWizard = true
                            },
                            onEditPersonClick = { person ->
                                personToEdit = person
                                showAddEditPersonDialog = true
                            },
                            onDeletePerson = { person ->
                                viewModel.deletePerson(person) {
                                    Toast.makeText(context, "تم حذف السجل بنجاح", Toast.LENGTH_SHORT).show()
                                }
                            },
                            onMovePersonClick = { person ->
                                personToEdit = person
                                showAddEditPersonDialog = true
                            }
                        )
                    }

                    AppScreen.MANAGE_COLUMNS -> {
                        ManageColumnsScreen(
                            sheet = activeSheet,
                            onBack = { currentScreen = AppScreen.DASHBOARD },
                            onAddColumn = { name, type, onResult ->
                                viewModel.addDynamicColumn(name, type, onResult)
                            },
                            onRenameColumn = { colId, newName, onResult ->
                                viewModel.renameDynamicColumn(colId, newName, onResult)
                            },
                            onDeleteColumn = { colId, onResult ->
                                viewModel.deleteDynamicColumn(colId, onResult)
                            }
                        )
                    }

                    AppScreen.STATISTICS -> {
                        StatisticsScreen(
                            stats = statistics,
                            onLoadStats = { viewModel.loadStatistics() },
                            onBack = { currentScreen = AppScreen.DASHBOARD }
                        )
                    }
                }
            }

            // Dialog: Sheet Selector / Manager
            if (showSheetSelector) {
                SheetSelectorDialog(
                    sheets = sheets,
                    activeSheetId = activeSheetId,
                    onSelectSheet = { sheetId -> viewModel.setActiveSheet(sheetId) },
                    onCreateSheet = { title -> viewModel.createSheet(title) },
                    onRenameSheet = { id, title -> viewModel.renameSheet(id, title) },
                    onDeleteSheet = { sheet ->
                        viewModel.deleteSheet(sheet) { _, msg ->
                            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                        }
                    },
                    onDismiss = { showSheetSelector = false }
                )
            }

            // Dynamic BottomSheet: Add / Edit Person Form
            if (showAddEditPersonDialog && activeSheet != null) {
                AddEditPersonBottomSheet(
                    personToEdit = personToEdit,
                    activeSheet = activeSheet!!,
                    allSheets = sheets,
                    onDismiss = {
                        showAddEditPersonDialog = false
                        personToEdit = null
                    },
                    onSavePerson = { primaryName, cardId, dynamicData, forceDuplicate, onDuplicate, onSuccess ->
                        viewModel.checkAndSavePerson(
                            personId = personToEdit?.id,
                            targetSheetId = activeSheet!!.id,
                            primaryName = primaryName,
                            cardId = cardId,
                            dynamicData = dynamicData,
                            forceCurrentSheetDuplicate = forceDuplicate,
                            onDuplicate = onDuplicate,
                            onSuccess = { msg ->
                                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                onSuccess(msg)
                            }
                        )
                    },
                    onMovePerson = { personId, targetSheetId ->
                        viewModel.movePerson(personId, targetSheetId) {
                            Toast.makeText(context, "تم نقل السجل بنجاح", Toast.LENGTH_SHORT).show()
                        }
                    }
                )
            }

            // Multi-Column Bulk Paste Wizard Dialog
            if (showBulkAddWizard && activeSheet != null) {
                BulkAddWizardDialog(
                    activeSheet = activeSheet!!,
                    onDismiss = { showBulkAddWizard = false },
                    onValidateRows = { sheetId, names, cards, dynamicMap ->
                        viewModel.validateBulkWizardRows(sheetId, names, cards, dynamicMap)
                    },
                    onSaveRows = { sheetId, rows, onComplete ->
                        viewModel.saveBulkWizardRows(sheetId, rows, onComplete)
                    }
                )
            }

            // Dialog: Excel Column Mapping
            importPreviewTable?.let { table ->
                if (activeSheet != null) {
                    ExcelColumnMappingDialog(
                        table = table,
                        activeSheet = activeSheet!!,
                        isImporting = isImporting,
                        onDismiss = { viewModel.setImportPreview(null) },
                        onConfirmImport = { nameColIdx, cardColIdx, dynamicColsMapping ->
                            viewModel.executeBulkImport(
                                sheetId = activeSheet!!.id,
                                nameColIdx = nameColIdx,
                                cardColIdx = cardColIdx,
                                dynamicColsMapping = dynamicColsMapping,
                                onFinished = { imported, skipped ->
                                    Toast.makeText(
                                        context,
                                        "تم استيراد $imported سجل بنجاح، وتخطي $skipped مكرر.",
                                        Toast.LENGTH_LONG
                                    ).show()
                                }
                            )
                        }
                    )
                }
            }

            // Dialog: Export Options
            if (showExportDialog) {
                ExportOptionsDialog(
                    activeSheet = activeSheet,
                    onDismiss = { showExportDialog = false },
                    onConfirmExport = { scopeType, format ->
                        viewModel.exportData(context, scopeType, format)
                    }
                )
            }

            // Dialog: Backup & Restore
            if (showBackupDialog) {
                BackupRestoreDialog(
                    onDismiss = { showBackupDialog = false },
                    onExportBackup = { viewModel.exportBackup(context) },
                    onPickRestoreFile = { pickJsonRestoreLauncher.launch("*/*") }
                )
            }

            // Dialog: Change Password
            if (showChangePasswordDialog) {
                ChangePasswordDialog(
                    onDismiss = { showChangePasswordDialog = false },
                    onChangePassword = { oldPass, newPass ->
                        val success = viewModel.changePassword(oldPass, newPass)
                        if (success) {
                            Toast.makeText(context, "تم تغيير كلمة المرور بنجاح", Toast.LENGTH_SHORT).show()
                        }
                        success
                    }
                )
            }
        }
    }
}
