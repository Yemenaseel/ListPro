package com.example.ui.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AuthPreferences
import com.example.data.model.ColumnDefinition
import com.example.data.model.ColumnType
import com.example.data.model.PersonEntity
import com.example.data.model.SheetEntity
import com.example.data.repository.DuplicateCheckResult
import com.example.data.repository.RegistryRepository
import com.example.data.repository.SheetStatistics
import com.example.util.ArabicNormalizer
import com.example.util.ExcelEngine
import com.example.util.FileSharingHelper
import com.example.util.ParsedExcelTable
import com.example.util.PdfExporter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

enum class ExportScope {
    ACTIVE_SHEET,
    ALL_SHEETS
}

enum class ExportFormat {
    EXCEL,
    CSV,
    PDF
}

enum class PersonFilter {
    ALL,
    WITH_CARD,
    WITHOUT_CARD
}

data class BulkWizardRow(
    val index: Int,
    val name: String,
    val card: String?,
    val dynamicValues: Map<String, String>,
    val status: BulkWizardStatus,
    val statusMessage: String
)

enum class BulkWizardStatus {
    VALID,
    WARNING_CURRENT_SHEET_DUPLICATE,
    ERROR_CARD_DUPLICATE,
    ERROR_OTHER_SHEET_DUPLICATE,
    ERROR_BATCH_DUPLICATE,
    ERROR_EMPTY_NAME
}

class RegistryViewModel(
    private val repository: RegistryRepository,
    private val authPreferences: AuthPreferences
) : ViewModel() {

    // -------------------------------------------------------------------------
    // 1. Authentication State
    // -------------------------------------------------------------------------
    private val _isPasswordSet = MutableStateFlow(authPreferences.isPasswordSet())
    val isPasswordSet: StateFlow<Boolean> = _isPasswordSet.asStateFlow()

    private val _isAuthenticated = MutableStateFlow(false)
    val isAuthenticated: StateFlow<Boolean> = _isAuthenticated.asStateFlow()

    private val _loginError = MutableStateFlow<String?>(null)
    val loginError: StateFlow<String?> = _loginError.asStateFlow()

    fun setupMasterPassword(password: String): Boolean {
        if (password.length < 4) {
            _loginError.value = "يجب أن تتكون كلمة المرور من 4 خانات على الأقل."
            return false
        }
        val success = authPreferences.setMasterPassword(password)
        if (success) {
            _isPasswordSet.value = true
            _isAuthenticated.value = true
            _loginError.value = null
        }
        return success
    }

    fun login(password: String): Boolean {
        return if (authPreferences.verifyPassword(password)) {
            _isAuthenticated.value = true
            _loginError.value = null
            true
        } else {
            _loginError.value = "كلمة المرور غير صحيحة، يرجى المحاولة مجدداً."
            false
        }
    }

    fun changePassword(oldPassword: String, newPassword: String): Boolean {
        if (newPassword.length < 4) {
            _loginError.value = "يجب أن تتكون كلمة المرور الجديدة من 4 خانات على الأقل."
            return false
        }
        val success = authPreferences.changePassword(oldPassword, newPassword)
        if (success) {
            _loginError.value = null
        } else {
            _loginError.value = "كلمة المرور الحالية غير صحيحة."
        }
        return success
    }

    fun logout() {
        _isAuthenticated.value = false
    }

    fun clearLoginError() {
        _loginError.value = null
    }

    // -------------------------------------------------------------------------
    // 2. Sheets Management
    // -------------------------------------------------------------------------
    val sheets: StateFlow<List<SheetEntity>> = repository.allSheets
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val _activeSheetId = MutableStateFlow<Long?>(null)
    val activeSheetId: StateFlow<Long?> = _activeSheetId.asStateFlow()

    val activeSheet: StateFlow<SheetEntity?> = combine(sheets, _activeSheetId) { list, id ->
        if (list.isEmpty()) null
        else if (id == null) list.firstOrNull()
        else list.find { it.id == id } ?: list.firstOrNull()
    }.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    init {
        viewModelScope.launch {
            val main = repository.ensureMainSheetExists()
            if (_activeSheetId.value == null) {
                _activeSheetId.value = main?.id
            }
        }
    }

    fun setActiveSheet(sheetId: Long) {
        _activeSheetId.value = sheetId
    }

    fun createSheet(title: String, onSuccess: (SheetEntity) -> Unit = {}) {
        val trimmed = title.trim()
        if (trimmed.isBlank()) return
        viewModelScope.launch {
            val newSheet = SheetEntity(
                title = trimmed,
                is_main = false,
                created_at = System.currentTimeMillis(),
                list_of_dynamic_columns = "[]"
            )
            val newId = repository.insertSheet(newSheet)
            val created = newSheet.copy(id = newId)
            _activeSheetId.value = newId
            onSuccess(created)
        }
    }

    fun renameSheet(sheetId: Long, newTitle: String) {
        val trimmed = newTitle.trim()
        if (trimmed.isBlank()) return
        viewModelScope.launch {
            val current = repository.getSheetById(sheetId)
            if (current != null) {
                repository.updateSheet(current.copy(title = trimmed))
            }
        }
    }

    fun deleteSheet(sheet: SheetEntity, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            repository.deleteSheet(sheet)
            // Switch active sheet to remaining sheet
            val remaining = repository.getAllSheetsList()
            _activeSheetId.value = remaining.firstOrNull()?.id
            onResult(true, "تم حذف الكشف بنجاح.")
        }
    }

    // -------------------------------------------------------------------------
    // 3. Dynamic Columns Engine
    // -------------------------------------------------------------------------
    fun addDynamicColumn(name: String, type: ColumnType, onResult: (Boolean, String) -> Unit) {
        val sheet = activeSheet.value ?: return
        val trimmed = name.trim()
        if (trimmed.isBlank()) {
            onResult(false, "اسم العمود لا يمكن أن يكون فارغاً.")
            return
        }
        val currentColumns = sheet.getDynamicColumns()
        if (currentColumns.any { it.name.equals(trimmed, ignoreCase = true) }) {
            onResult(false, "يوجد عمود بنفس الاسم بالفعل في هذا الكشف.")
            return
        }

        val newCol = ColumnDefinition(
            id = "col_${UUID.randomUUID().toString().take(8)}",
            name = trimmed,
            type = type
        )
        val updatedList = currentColumns + newCol
        viewModelScope.launch {
            repository.updateSheet(sheet.withDynamicColumns(updatedList))
            onResult(true, "تمت إضافة العمود بنجاح.")
        }
    }

    fun renameDynamicColumn(columnId: String, newName: String, onResult: (Boolean, String) -> Unit) {
        val sheet = activeSheet.value ?: return
        val trimmed = newName.trim()
        if (trimmed.isBlank()) {
            onResult(false, "اسم العمود لا يمكن أن يكون فارغاً.")
            return
        }
        val currentColumns = sheet.getDynamicColumns()
        val updated = currentColumns.map {
            if (it.id == columnId) it.copy(name = trimmed) else it
        }
        viewModelScope.launch {
            repository.updateSheet(sheet.withDynamicColumns(updated))
            onResult(true, "تم تعديل اسم العمود.")
        }
    }

    fun deleteDynamicColumn(columnId: String, onResult: (Boolean, String) -> Unit) {
        val sheet = activeSheet.value ?: return
        val currentColumns = sheet.getDynamicColumns()
        val updated = currentColumns.filterNot { it.id == columnId }
        viewModelScope.launch {
            repository.updateSheet(sheet.withDynamicColumns(updated))
            onResult(true, "تم حذف العمود من الكشف.")
        }
    }

    // -------------------------------------------------------------------------
    // 4. Persons & Records State
    // -------------------------------------------------------------------------
    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val personsInActiveSheet: StateFlow<List<PersonEntity>> = _activeSheetId.flatMapLatest { id ->
        if (id == null) {
            repository.allSheets.flatMapLatest { sheets ->
                val firstId = sheets.firstOrNull()?.id ?: 0L
                repository.getPersonsBySheet(firstId)
            }
        } else {
            repository.getPersonsBySheet(id)
        }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _filterMode = MutableStateFlow(PersonFilter.ALL)
    val filterMode: StateFlow<PersonFilter> = _filterMode.asStateFlow()

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setFilterMode(mode: PersonFilter) {
        _filterMode.value = mode
    }

    val filteredPersons: StateFlow<List<PersonEntity>> = combine(
        personsInActiveSheet,
        _searchQuery,
        _filterMode
    ) { persons, query, filter ->
        var list = persons

        // Apply Card presence filter
        list = when (filter) {
            PersonFilter.ALL -> list
            PersonFilter.WITH_CARD -> list.filter { !it.unique_card_id.isNullOrBlank() }
            PersonFilter.WITHOUT_CARD -> list.filter { it.unique_card_id.isNullOrBlank() }
        }

        // Apply strict normalized search
        val q = query.trim()
        if (q.isNotEmpty()) {
            val normQuery = ArabicNormalizer.normalizeArabic(q)
            val cleanCardQuery = ArabicNormalizer.cleanCardNumber(q)

            list = list.filter { person ->
                val normName = ArabicNormalizer.normalizeArabic(person.primary_name)
                val cleanCard = ArabicNormalizer.cleanCardNumber(person.unique_card_id)

                val nameMatches = normName.contains(normQuery)
                val cardMatches = cleanCardQuery.isNotBlank() && cleanCard.contains(cleanCardQuery)

                // Also check dynamic fields
                val dynamicMatches = person.getDynamicData().values.any { valStr ->
                    ArabicNormalizer.normalizeArabic(valStr).contains(normQuery) ||
                            (cleanCardQuery.isNotBlank() && ArabicNormalizer.cleanCardNumber(valStr).contains(cleanCardQuery))
                }

                nameMatches || cardMatches || dynamicMatches
            }
        }
        list
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // -------------------------------------------------------------------------
    // 5. Add / Edit / Move / Delete Person
    // -------------------------------------------------------------------------
    fun checkAndSavePerson(
        personId: Long? = null,
        targetSheetId: Long,
        primaryName: String,
        cardId: String?,
        dynamicData: Map<String, String>,
        forceCurrentSheetDuplicate: Boolean = false,
        onDuplicate: (DuplicateCheckResult) -> Unit,
        onSuccess: (String) -> Unit
    ) {
        val trimmedName = primaryName.trim()
        if (trimmedName.isBlank()) {
            onDuplicate(DuplicateCheckResult.OtherSheetNameDuplicate("", "الاسم الرباعي إجباري ولا يمكن تركه فارغاً."))
            return
        }

        viewModelScope.launch {
            val cleanedCard = ArabicNormalizer.cleanCardNumber(cardId).ifBlank { null }
            val checkResult = repository.checkDuplicate(
                targetSheetId = targetSheetId,
                primaryName = trimmedName,
                cardId = cleanedCard,
                editingPersonId = personId
            )

            when (checkResult) {
                is DuplicateCheckResult.CardDuplicate -> {
                    onDuplicate(checkResult)
                    return@launch
                }
                is DuplicateCheckResult.OtherSheetNameDuplicate -> {
                    onDuplicate(checkResult)
                    return@launch
                }
                is DuplicateCheckResult.CurrentSheetDuplicate -> {
                    if (!forceCurrentSheetDuplicate) {
                        onDuplicate(checkResult)
                        return@launch
                    }
                    // If user confirmed to proceed with current sheet duplicate, proceed to save
                }
                is DuplicateCheckResult.Valid -> {
                    // Valid
                }
            }

            if (personId == null) {
                // New person
                val newPerson = PersonEntity(
                    sheet_id = targetSheetId,
                    primary_name = trimmedName,
                    unique_card_id = cleanedCard,
                    dynamic_data_map = PersonEntity.mapToJsonString(dynamicData),
                    timestamp = System.currentTimeMillis()
                )
                repository.insertPerson(newPerson)
                onSuccess("تمت إضافة السجل بنجاح.")
            } else {
                // Update person
                val existing = repository.getPersonsBySheetList(targetSheetId).find { it.id == personId }
                    ?: repository.getAllPersonsList().find { it.id == personId }

                val updatedPerson = PersonEntity(
                    id = personId,
                    sheet_id = targetSheetId,
                    primary_name = trimmedName,
                    unique_card_id = cleanedCard,
                    dynamic_data_map = PersonEntity.mapToJsonString(dynamicData),
                    timestamp = existing?.timestamp ?: System.currentTimeMillis()
                )
                repository.updatePerson(updatedPerson)
                onSuccess("تم تعديل السجل بنجاح.")
            }
        }
    }

    fun movePerson(personId: Long, targetSheetId: Long, onSuccess: () -> Unit) {
        viewModelScope.launch {
            repository.movePerson(personId, targetSheetId)
            onSuccess()
        }
    }

    fun deletePerson(person: PersonEntity, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            repository.deletePerson(person)
            onSuccess()
        }
    }

    // -------------------------------------------------------------------------
    // 6. Statistics
    // -------------------------------------------------------------------------
    private val _statistics = MutableStateFlow<SheetStatistics?>(null)
    val statistics: StateFlow<SheetStatistics?> = _statistics.asStateFlow()

    fun loadStatistics() {
        viewModelScope.launch {
            val sheetId = _activeSheetId.value ?: return@launch
            _statistics.value = repository.getStatistics(sheetId)
        }
    }

    // -------------------------------------------------------------------------
    // 7. Bulk Excel Import Engine
    // -------------------------------------------------------------------------
    private val _importPreviewTable = MutableStateFlow<ParsedExcelTable?>(null)
    val importPreviewTable: StateFlow<ParsedExcelTable?> = _importPreviewTable.asStateFlow()

    private val _isImporting = MutableStateFlow(false)
    val isImporting: StateFlow<Boolean> = _isImporting.asStateFlow()

    private val _importSummaryMessage = MutableStateFlow<String?>(null)
    val importSummaryMessage: StateFlow<String?> = _importSummaryMessage.asStateFlow()

    fun setImportPreview(table: ParsedExcelTable?) {
        _importPreviewTable.value = table
    }

    fun clearImportSummary() {
        _importSummaryMessage.value = null
    }

    /**
     * Executes the bulk import using column mapping:
     * - nameColIdx: index in Excel row for Primary Name
     * - cardColIdx: index in Excel row for Card ID (optional, -1 if none)
     * - dynamicColsMapping: map of Dynamic Column ID -> index in Excel row
     */
    fun executeBulkImport(
        sheetId: Long,
        nameColIdx: Int,
        cardColIdx: Int,
        dynamicColsMapping: Map<String, Int>,
        onFinished: (importedCount: Int, skippedCount: Int) -> Unit
    ) {
        val table = _importPreviewTable.value ?: return
        _isImporting.value = true

        viewModelScope.launch(Dispatchers.IO) {
            val allPersons = repository.getAllPersonsList().toMutableList()
            val existingCards = mutableSetOf<String>()
            val existingNamesBySheet = mutableMapOf<Long, MutableSet<String>>()
            val allSheets = repository.getAllSheetsList().associateBy { it.id }

            for (p in allPersons) {
                val c = ArabicNormalizer.cleanCardNumber(p.unique_card_id)
                if (c.isNotBlank()) existingCards.add(c)

                val n = ArabicNormalizer.normalizeArabic(p.primary_name)
                if (n.isNotBlank()) {
                    existingNamesBySheet.getOrPut(p.sheet_id) { mutableSetOf() }.add(n)
                }
            }

            var importedCount = 0
            var skippedCount = 0
            val personsToInsert = mutableListOf<PersonEntity>()

            for (row in table.rows) {
                val rawName = if (nameColIdx in row.indices) row[nameColIdx].trim() else ""
                if (rawName.isBlank()) {
                    skippedCount++
                    continue
                }

                val normalizedName = ArabicNormalizer.normalizeArabic(rawName)
                val rawCard = if (cardColIdx >= 0 && cardColIdx in row.indices) row[cardColIdx].trim() else ""
                val cleanedCard = ArabicNormalizer.cleanCardNumber(rawCard).ifBlank { null }

                // Check card clash across ALL sheets
                if (cleanedCard != null && existingCards.contains(cleanedCard)) {
                    skippedCount++
                    continue
                }

                // Check name clash across other sheets
                var nameExistsInOtherSheet = false
                for ((sId, namesSet) in existingNamesBySheet) {
                    if (sId != sheetId && namesSet.contains(normalizedName)) {
                        nameExistsInOtherSheet = true
                        break
                    }
                }
                if (nameExistsInOtherSheet) {
                    skippedCount++
                    continue
                }

                // Check name clash in current sheet
                val currentSheetNames = existingNamesBySheet.getOrPut(sheetId) { mutableSetOf() }
                if (currentSheetNames.contains(normalizedName)) {
                    skippedCount++
                    continue
                }

                // Dynamic columns data
                val dynamicMap = mutableMapOf<String, String>()
                for ((colId, colIdx) in dynamicColsMapping) {
                    if (colIdx in row.indices) {
                        dynamicMap[colId] = row[colIdx].trim()
                    }
                }

                // Valid record -> add to insert batch
                val newEntity = PersonEntity(
                    sheet_id = sheetId,
                    primary_name = rawName,
                    unique_card_id = cleanedCard,
                    dynamic_data_map = PersonEntity.mapToJsonString(dynamicMap),
                    timestamp = System.currentTimeMillis()
                )
                personsToInsert.add(newEntity)

                // Track in-memory sets to catch intra-batch duplicates
                if (cleanedCard != null) existingCards.add(cleanedCard)
                currentSheetNames.add(normalizedName)
                importedCount++
            }

            if (personsToInsert.isNotEmpty()) {
                repository.insertPersons(personsToInsert)
            }

            withContext(Dispatchers.Main) {
                _isImporting.value = false
                _importPreviewTable.value = null
                val summary = "تم استيراد $importedCount سجل بنجاح، وتخطي $skippedCount مكرر."
                _importSummaryMessage.value = summary
                onFinished(importedCount, skippedCount)
            }
        }
    }

    // -------------------------------------------------------------------------
    // 7.1 Multi-Column Bulk Paste Wizard
    // -------------------------------------------------------------------------
    suspend fun validateBulkWizardRows(
        sheetId: Long,
        names: List<String>,
        cards: List<String>,
        dynamicColumnsValues: Map<String, List<String>>
    ): List<BulkWizardRow> = withContext(Dispatchers.IO) {
        val allPersons = repository.getAllPersonsList()
        val allSheets = repository.getAllSheetsList().associateBy { it.id }

        val dbCards = mutableSetOf<String>()
        val dbNamesBySheet = mutableMapOf<Long, MutableSet<String>>()

        for (p in allPersons) {
            val c = ArabicNormalizer.cleanCardNumber(p.unique_card_id)
            if (c.isNotBlank()) dbCards.add(c)

            val n = ArabicNormalizer.normalizeArabic(p.primary_name)
            if (n.isNotBlank()) {
                dbNamesBySheet.getOrPut(p.sheet_id) { mutableSetOf() }.add(n)
            }
        }

        val batchSeenCards = mutableSetOf<String>()
        val batchSeenNames = mutableSetOf<String>()

        val rowCount = names.size
        val result = mutableListOf<BulkWizardRow>()

        for (i in 0 until rowCount) {
            val rawName = names[i].trim()
            if (rawName.isBlank()) {
                result.add(
                    BulkWizardRow(
                        index = i + 1,
                        name = "",
                        card = null,
                        dynamicValues = emptyMap(),
                        status = BulkWizardStatus.ERROR_EMPTY_NAME,
                        statusMessage = "الاسم فارغ"
                    )
                )
                continue
            }

            val rawCard = cards.getOrNull(i)?.trim() ?: ""
            val cleanCard = ArabicNormalizer.cleanCardNumber(rawCard).ifBlank { null }
            val normName = ArabicNormalizer.normalizeArabic(rawName)

            val dynamicRowMap = mutableMapOf<String, String>()
            for ((colId, valuesList) in dynamicColumnsValues) {
                val v = valuesList.getOrNull(i)?.trim() ?: ""
                if (v.isNotBlank()) {
                    dynamicRowMap[colId] = v
                }
            }

            // Check card duplication
            var status = BulkWizardStatus.VALID
            var msg = "جاهز للإضافة"

            if (cleanCard != null) {
                if (dbCards.contains(cleanCard)) {
                    status = BulkWizardStatus.ERROR_CARD_DUPLICATE
                    msg = "رقم البطاقة ($cleanCard) مسجل مسبقاً في النظام"
                } else if (batchSeenCards.contains(cleanCard)) {
                    status = BulkWizardStatus.ERROR_BATCH_DUPLICATE
                    msg = "رقم البطاقة ($cleanCard) مكرر أكثر من مرة في هذه القائمة"
                }
            }

            if (status == BulkWizardStatus.VALID) {
                // Check name duplication in other sheets
                var foundInOtherSheet: Long? = null
                for ((sId, setOfNames) in dbNamesBySheet) {
                    if (sId != sheetId && setOfNames.contains(normName)) {
                        foundInOtherSheet = sId
                        break
                    }
                }

                if (foundInOtherSheet != null) {
                    val otherSheetName = allSheets[foundInOtherSheet]?.title ?: "كشف آخر"
                    status = BulkWizardStatus.ERROR_OTHER_SHEET_DUPLICATE
                    msg = "الاسم مسجل في '$otherSheetName' - يمنع التكرار"
                } else {
                    // Check duplicate in current sheet
                    val inCurrentSheet = dbNamesBySheet[sheetId]?.contains(normName) == true
                    val inBatch = batchSeenNames.contains(normName)
                    if (inCurrentSheet || inBatch) {
                        status = BulkWizardStatus.WARNING_CURRENT_SHEET_DUPLICATE
                        msg = if (inCurrentSheet) "الاسم مسجل مسبقاً في هذا الكشف (تحذير تشابه)" else "الاسم مكرر داخل القائمة الحالية (تحذير تشابه)"
                    }
                }
            }

            if (cleanCard != null) batchSeenCards.add(cleanCard)
            batchSeenNames.add(normName)

            result.add(
                BulkWizardRow(
                    index = i + 1,
                    name = rawName,
                    card = cleanCard,
                    dynamicValues = dynamicRowMap,
                    status = status,
                    statusMessage = msg
                )
            )
        }

        result
    }

    fun saveBulkWizardRows(
        sheetId: Long,
        rowsToSave: List<BulkWizardRow>,
        onSuccess: (savedCount: Int) -> Unit
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val entities = rowsToSave.map { row ->
                PersonEntity(
                    sheet_id = sheetId,
                    primary_name = row.name,
                    unique_card_id = row.card,
                    dynamic_data_map = PersonEntity.mapToJsonString(row.dynamicValues),
                    timestamp = System.currentTimeMillis()
                )
            }
            if (entities.isNotEmpty()) {
                repository.insertPersons(entities)
            }
            withContext(Dispatchers.Main) {
                onSuccess(entities.size)
            }
        }
    }

    // -------------------------------------------------------------------------
    // 8. Dynamic Export System (XLSX, CSV, PDF)
    // -------------------------------------------------------------------------
    fun exportData(
        context: Context,
        scope: ExportScope,
        format: ExportFormat
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val allSheets = repository.getAllSheetsList().associateBy { it.id }
            val active = activeSheet.value

            val (title, headers, rows) = buildExportDataset(scope, active, allSheets)

            val safeTitle = title.replace(Regex("[^a-zA-Z0-9\\u0600-\\u06FF]"), "_")

            when (format) {
                ExportFormat.EXCEL -> {
                    val fileName = "${safeTitle}_${System.currentTimeMillis()}.xlsx"
                    FileSharingHelper.shareFile(context, fileName, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") { fos ->
                        ExcelEngine.exportToXlsx(headers, rows, fos)
                    }
                }
                ExportFormat.CSV -> {
                    val fileName = "${safeTitle}_${System.currentTimeMillis()}.csv"
                    FileSharingHelper.shareFile(context, fileName, "text/csv") { fos ->
                        ExcelEngine.exportToCsv(headers, rows, fos)
                    }
                }
                ExportFormat.PDF -> {
                    val fileName = "${safeTitle}_${System.currentTimeMillis()}.pdf"
                    FileSharingHelper.shareFile(context, fileName, "application/pdf") { fos ->
                        PdfExporter.exportToPdf(context, title, headers, rows, fos)
                    }
                }
            }
        }
    }

    private suspend fun buildExportDataset(
        scope: ExportScope,
        activeSheet: SheetEntity?,
        allSheetsMap: Map<Long, SheetEntity>
    ): Triple<String, List<String>, List<List<String>>> {
        return if (scope == ExportScope.ACTIVE_SHEET && activeSheet != null) {
            val dynamicCols = activeSheet.getDynamicColumns()
            val headers = mutableListOf<String>()
            headers.add("الاسم")
            headers.add("رقم البطاقة")
            for (c in dynamicCols) {
                headers.add(c.name)
            }

            val persons = repository.getPersonsBySheetList(activeSheet.id)
                .sortedWith(compareBy { ArabicNormalizer.normalizeArabic(it.primary_name) })

            val rows = persons.map { p ->
                val dyn = p.getDynamicData()
                val r = mutableListOf<String>()
                r.add(p.primary_name)
                r.add(p.unique_card_id ?: "")
                for (c in dynamicCols) {
                    r.add(dyn[c.id] ?: "")
                }
                r
            }
            Triple(activeSheet.title, headers, rows)
        } else {
            // ALL SHEETS
            // Collect all unique dynamic columns across sheets
            val allPersons = repository.getAllPersonsList()
                .sortedWith(compareBy({ it.sheet_id }, { ArabicNormalizer.normalizeArabic(it.primary_name) }))
            val headers = mutableListOf<String>()
            headers.add("اسم الكشف")
            headers.add("الاسم الرباعي")
            headers.add("رقم البطاقة")

            // Collect all column names
            val colMap = mutableMapOf<String, String>() // colId to colName
            for (s in allSheetsMap.values) {
                for (c in s.getDynamicColumns()) {
                    colMap[c.id] = c.name
                }
            }
            for (colName in colMap.values.distinct()) {
                headers.add(colName)
            }

            val distinctColNames = colMap.values.distinct()

            val rows = allPersons.map { p ->
                val sTitle = allSheetsMap[p.sheet_id]?.title ?: "غير معروف"
                val dyn = p.getDynamicData()
                val r = mutableListOf<String>()
                r.add(sTitle)
                r.add(p.primary_name)
                r.add(p.unique_card_id ?: "")

                // Fill by distinct column names
                for (targetColName in distinctColNames) {
                    val matchingKey = dyn.keys.find { k -> colMap[k] == targetColName }
                    r.add(matchingKey?.let { dyn[it] } ?: "")
                }
                r
            }
            Triple("كافة_الكشوفات_والسجلات", headers, rows)
        }
    }

    // -------------------------------------------------------------------------
    // 9. Full System Backup & Restore (JSON)
    // -------------------------------------------------------------------------
    fun exportBackup(context: Context) {
        viewModelScope.launch(Dispatchers.IO) {
            val json = repository.exportAllDataAsJson()
            val fileName = "backup_sheets_registry_${System.currentTimeMillis()}.json"
            FileSharingHelper.shareFile(context, fileName, "application/json") { fos ->
                fos.write(json.toByteArray(Charsets.UTF_8))
            }
        }
    }

    fun restoreBackup(jsonString: String, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val success = repository.restoreAllDataFromJson(jsonString)
            if (success) {
                val sheets = repository.getAllSheetsList()
                _activeSheetId.value = sheets.firstOrNull()?.id
                onResult(true, "تمت استعادة كافة البيانات بنجاح.")
            } else {
                onResult(false, "فشلت استعادة البيانات. يرجى التحقق من تنسيق ملف النسخة الاحتياطية.")
            }
        }
    }
}
