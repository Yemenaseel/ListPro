package com.example.data.model

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import org.json.JSONObject

@Entity(
    tableName = "persons",
    foreignKeys = [
        ForeignKey(
            entity = SheetEntity::class,
            parentColumns = ["id"],
            childColumns = ["sheet_id"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["sheet_id"]),
        Index(value = ["unique_card_id"])
    ]
)
data class PersonEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val sheet_id: Long,
    val primary_name: String,
    val unique_card_id: String? = null,
    val dynamic_data_map: String = "{}",
    val timestamp: Long = System.currentTimeMillis()
) {
    fun getDynamicData(): Map<String, String> {
        val map = mutableMapOf<String, String>()
        if (dynamic_data_map.isBlank()) return map
        try {
            val json = JSONObject(dynamic_data_map)
            val keys = json.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                map[key] = json.optString(key, "")
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return map
    }

    fun withDynamicData(data: Map<String, String>): PersonEntity {
        val json = JSONObject()
        for ((key, value) in data) {
            json.put(key, value)
        }
        return this.copy(dynamic_data_map = json.toString())
    }

    companion object {
        fun mapToJsonString(data: Map<String, String>): String {
            val json = JSONObject()
            for ((key, value) in data) {
                json.put(key, value)
            }
            return json.toString()
        }
    }
}
