package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.local.PersonDao
import com.example.data.local.SheetDao
import com.example.data.model.PersonEntity
import com.example.data.model.SheetEntity
import com.example.data.service.DuplicationCheckService
import com.example.util.ArabicNormalizer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

sealed class DuplicateCheckResult {
    object Valid : DuplicateCheckResult()
    data class CurrentSheetDuplicate(val existingPerson: PersonEntity, val message: String) : DuplicateCheckResult()
    data class OtherSheetNameDuplicate(val sheetTitle: String, val message: String) : DuplicateCheckResult()
    data class CardDuplicate(val sheetTitle: String, val personName: String, val message: String) : DuplicateCheckResult()
}

data class SheetStatistics(
    val sheetTitle: String,
    val totalInSheet: Int,
    val withCardCount: Int,
    val withoutCardCount: Int,
    val globalTotalPersons: Int,
    val duplicateCardsAcrossAllSheets: Int,
    val allSheetsSummary: List<Pair<String, Int>>
)

class RegistryRepository(
    private val database: AppDatabase
) {
    private val sheetDao: SheetDao = database.sheetDao()
    private val personDao: PersonDao = database.personDao()
    val duplicationCheckService = DuplicationCheckService(personDao, sheetDao)

    val allSheets: Flow<List<SheetEntity>> = sheetDao.getAllSheets()

    suspend fun ensureMainSheetExists(): SheetEntity? = withContext(Dispatchers.IO) {
        sheetDao.getAllSheetsList().firstOrNull()
    }

    suspend fun getAllSheetsList(): List<SheetEntity> = withContext(Dispatchers.IO) {
        sheetDao.getAllSheetsList()
    }

    suspend fun getSheetById(sheetId: Long): SheetEntity? = withContext(Dispatchers.IO) {
        sheetDao.getSheetById(sheetId)
    }

    suspend fun insertSheet(sheet: SheetEntity): Long = withContext(Dispatchers.IO) {
        sheetDao.insertSheet(sheet)
    }

    suspend fun updateSheet(sheet: SheetEntity) = withContext(Dispatchers.IO) {
        sheetDao.updateSheet(sheet)
    }

    suspend fun deleteSheet(sheet: SheetEntity) = withContext(Dispatchers.IO) {
        personDao.deletePersonsBySheet(sheet.id)
        sheetDao.deleteSheet(sheet)
    }

    fun getPersonsBySheet(sheetId: Long): Flow<List<PersonEntity>> {
        return personDao.getPersonsBySheet(sheetId)
    }

    suspend fun getPersonsBySheetList(sheetId: Long): List<PersonEntity> = withContext(Dispatchers.IO) {
        personDao.getPersonsBySheetList(sheetId)
    }

    suspend fun getAllPersonsList(): List<PersonEntity> = withContext(Dispatchers.IO) {
        personDao.getAllPersonsList()
    }

    val allPersons: Flow<List<PersonEntity>> = personDao.getAllPersons()

    val deletedPersons: Flow<List<PersonEntity>> = personDao.getDeletedPersons()
    val deletedCount: Flow<Int> = personDao.countDeletedPersons()

    suspend fun insertPerson(person: PersonEntity): Long = withContext(Dispatchers.IO) {
        personDao.insertPerson(person)
    }

    suspend fun insertPersons(persons: List<PersonEntity>) = withContext(Dispatchers.IO) {
        personDao.insertPersons(persons)
    }

    suspend fun updatePerson(person: PersonEntity) = withContext(Dispatchers.IO) {
        personDao.updatePerson(person)
    }

    suspend fun updatePersons(persons: List<PersonEntity>) = withContext(Dispatchers.IO) {
        personDao.updatePersons(persons)
    }

    suspend fun softDeletePerson(id: Long) = withContext(Dispatchers.IO) {
        personDao.softDeletePerson(id)
    }

    suspend fun softDeletePersons(ids: List<Long>) = withContext(Dispatchers.IO) {
        personDao.softDeletePersons(ids)
    }

    suspend fun restorePerson(id: Long) = withContext(Dispatchers.IO) {
        personDao.restorePerson(id)
    }

    suspend fun restorePersons(ids: List<Long>) = withContext(Dispatchers.IO) {
        personDao.restorePersons(ids)
    }

    suspend fun deletePermanently(id: Long) = withContext(Dispatchers.IO) {
        personDao.deletePermanently(id)
    }

    suspend fun emptyRecycleBin() = withContext(Dispatchers.IO) {
        personDao.emptyRecycleBin()
    }

    suspend fun movePersonsToSheet(ids: List<Long>, targetSheetId: Long) = withContext(Dispatchers.IO) {
        personDao.movePersonsToSheet(ids, targetSheetId)
    }

    suspend fun deletePerson(person: PersonEntity) = withContext(Dispatchers.IO) {
        personDao.softDeletePerson(person.id)
    }

    suspend fun deletePersonById(id: Long) = withContext(Dispatchers.IO) {
        personDao.softDeletePerson(id)
    }

    suspend fun movePerson(personId: Long, targetSheetId: Long) = withContext(Dispatchers.IO) {
        personDao.movePersonsToSheet(listOf(personId), targetSheetId)
    }

    /**
     * Global Cross-Sheet Duplication Checking:
     * - Check unique card number across ALL sheets.
     * - Check primary name across ALL sheets:
     *     - If in another sheet -> Reject.
     *     - If in current sheet -> CurrentSheetDuplicate (allows user to update or confirm).
     */
    suspend fun checkDuplicate(
        targetSheetId: Long,
        primaryName: String,
        cardId: String?,
        editingPersonId: Long? = null
    ): DuplicateCheckResult = duplicationCheckService.checkDuplicate(
        targetSheetId = targetSheetId,
        primaryName = primaryName,
        cardId = cardId,
        editingPersonId = editingPersonId
    )

    suspend fun getStatistics(activeSheetId: Long): SheetStatistics = withContext(Dispatchers.IO) {
        val sheets = sheetDao.getAllSheetsList()
        val allPersons = personDao.getAllPersonsList()
        val activeSheet = sheets.find { it.id == activeSheetId } ?: sheets.firstOrNull()

        val activePersons = allPersons.filter { it.sheet_id == activeSheet?.id }
        val totalInSheet = activePersons.size
        val withCard = activePersons.count { !it.unique_card_id.isNullOrBlank() }
        val withoutCard = totalInSheet - withCard

        val globalTotal = allPersons.size

        // Calculate card clashes / duplicate cards across database
        val cardCounts = mutableMapOf<String, Int>()
        for (p in allPersons) {
            val c = ArabicNormalizer.cleanCardNumber(p.unique_card_id)
            if (c.isNotBlank()) {
                cardCounts[c] = (cardCounts[c] ?: 0) + 1
            }
        }
        val duplicateCardsCount = cardCounts.count { it.value > 1 }

        val sheetSummary = sheets.map { s ->
            s.title to allPersons.count { it.sheet_id == s.id }
        }

        SheetStatistics(
            sheetTitle = activeSheet?.title ?: "",
            totalInSheet = totalInSheet,
            withCardCount = withCard,
            withoutCardCount = withoutCard,
            globalTotalPersons = globalTotal,
            duplicateCardsAcrossAllSheets = duplicateCardsCount,
            allSheetsSummary = sheetSummary
        )
    }

    // -------------------------------------------------------------------------
    // Full System Backup & Restore (JSON)
    // -------------------------------------------------------------------------

    suspend fun exportAllDataAsJson(): String = withContext(Dispatchers.IO) {
        val sheets = sheetDao.getAllSheetsList()
        val persons = personDao.getAllPersonsList()

        val root = JSONObject()
        root.put("version", 1)
        root.put("exported_at", System.currentTimeMillis())

        val sheetsArray = JSONArray()
        for (s in sheets) {
            val sObj = JSONObject()
            sObj.put("id", s.id)
            sObj.put("title", s.title)
            sObj.put("is_main", s.is_main)
            sObj.put("created_at", s.created_at)
            sObj.put("list_of_dynamic_columns", s.list_of_dynamic_columns)
            sheetsArray.put(sObj)
        }
        root.put("sheets", sheetsArray)

        val personsArray = JSONArray()
        for (p in persons) {
            val pObj = JSONObject()
            pObj.put("id", p.id)
            pObj.put("sheet_id", p.sheet_id)
            pObj.put("primary_name", p.primary_name)
            pObj.put("unique_card_id", p.unique_card_id ?: "")
            pObj.put("dynamic_data_map", p.dynamic_data_map)
            pObj.put("timestamp", p.timestamp)
            personsArray.put(pObj)
        }
        root.put("persons", personsArray)

        root.toString(2)
    }

    suspend fun restoreAllDataFromJson(jsonString: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val root = JSONObject(jsonString)
            val sheetsArray = root.getJSONArray("sheets")
            val personsArray = root.getJSONArray("persons")

            val restoredSheets = mutableListOf<SheetEntity>()
            for (i in 0 until sheetsArray.length()) {
                val sObj = sheetsArray.getJSONObject(i)
                restoredSheets.add(
                    SheetEntity(
                        id = sObj.optLong("id", 0),
                        title = sObj.optString("title", "كشف"),
                        is_main = sObj.optBoolean("is_main", false),
                        created_at = sObj.optLong("created_at", System.currentTimeMillis()),
                        list_of_dynamic_columns = sObj.optString("list_of_dynamic_columns", "[]")
                    )
                )
            }

            val restoredPersons = mutableListOf<PersonEntity>()
            for (i in 0 until personsArray.length()) {
                val pObj = personsArray.getJSONObject(i)
                val card = pObj.optString("unique_card_id", "").ifBlank { null }
                restoredPersons.add(
                    PersonEntity(
                        id = pObj.optLong("id", 0),
                        sheet_id = pObj.optLong("sheet_id", 0),
                        primary_name = pObj.optString("primary_name", ""),
                        unique_card_id = card,
                        dynamic_data_map = pObj.optString("dynamic_data_map", "{}"),
                        timestamp = pObj.optLong("timestamp", System.currentTimeMillis())
                    )
                )
            }

            // Wipe database and restore
            personDao.deleteAllPersons()
            sheetDao.deleteAllSheets()

            sheetDao.insertSheets(restoredSheets)
            personDao.insertPersons(restoredPersons)

            // Verify main sheet exists
            ensureMainSheetExists()
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
}
