package com.example.util

/**
 * Utility for strict Arabic text normalization and card number sanitization.
 *
 * Requirements:
 * - Trim and collapse multiple spaces.
 * - Unify "عبد الله" and "عبــد الله" to "عبدالله".
 * - Normalize all Alef variations (أ, إ, آ, ٱ) to a bare Alef (ا).
 * - Normalize Taa Marbuta (ة) to Haa (ه).
 * - Remove Tatweel/Kashida (ـ) and Tashkeel (diacritics).
 * - Normalize Alef Maqsura (ى) to Yaa (ي).
 * - cleanCardNumber: Remove all spaces, dashes, dots, and parentheses, and convert Arabic-Indic digits.
 */
object ArabicNormalizer {

    // Arabic diacritics regex: Fathatan, Dammatan, Kasratan, Fatha, Damma, Kasra, Shadda, Sukun, etc.
    private val TASHKEEL_REGEX = Regex("[\\u064B-\\u065F\\u0670]")

    // Tatweel / Kashida character
    private const val TATWEEL = '\u0640'

    /**
     * Strictly normalizes Arabic text for duplicate checking and searching.
     */
    fun normalizeArabic(input: String?): String {
        if (input.isNullOrBlank()) return ""

        var text = input.trim()

        // 1. Remove Tatweel (Kashida)
        text = text.replace(TATWEEL.toString(), "")

        // 2. Remove Tashkeel (diacritics)
        text = text.replace(TASHKEEL_REGEX, "")

        // 3. Unify "عبد" combinations: "عبد الله", "عبد الرحمن", "عبــد الله", etc.
        // Replace "عبد" followed by whitespace with "عبد" directly connected to the following name
        text = text.replace(Regex("عبد\\s+"), "عبد")

        // 4. Normalize Alef variations (أ, إ, آ, ٱ) to bare Alef (ا)
        text = text.replace('أ', 'ا')
            .replace('إ', 'ا')
            .replace('آ', 'ا')
            .replace('ٱ', 'ا')

        // 5. Normalize Taa Marbuta (ة) to Haa (ه)
        text = text.replace('ة', 'ه')

        // 6. Normalize Alef Maqsura (ى) to Yaa (ي)
        text = text.replace('ى', 'ي')

        // 7. Collapse multiple spaces into a single space
        text = text.replace(Regex("\\s+"), " ").trim()

        return text
    }

    /**
     * Sanitizes and cleans a national/personal card number:
     * - Removes spaces, dashes, dots, parentheses, slashes.
     * - Converts Arabic-Indic digits (٠-٩) to standard ASCII digits (0-9).
     */
    fun cleanCardNumber(input: String?): String {
        if (input.isNullOrBlank()) return ""

        // Convert Arabic/Eastern digits to ASCII
        val converted = StringBuilder()
        for (ch in input) {
            when (ch) {
                '٠' -> converted.append('0')
                '١' -> converted.append('1')
                '٢' -> converted.append('2')
                '٣' -> converted.append('3')
                '٤' -> converted.append('4')
                '٥' -> converted.append('5')
                '٦' -> converted.append('6')
                '٧' -> converted.append('7')
                '٨' -> converted.append('8')
                '٩' -> converted.append('9')
                // Persian/Urdu digits if any
                '۰' -> converted.append('0')
                '۱' -> converted.append('1')
                '۲' -> converted.append('2')
                '۳' -> converted.append('3')
                '۴' -> converted.append('4')
                '۵' -> converted.append('5')
                '۶' -> converted.append('6')
                '۷' -> converted.append('7')
                '۸' -> converted.append('8')
                '۹' -> converted.append('9')
                else -> converted.append(ch)
            }
        }

        // Remove spaces, dashes, dots, parentheses, slashes
        return converted.toString().replace(Regex("[\\s\\-\\.\\(\\)\\/\\\\]"), "").trim()
    }
}
