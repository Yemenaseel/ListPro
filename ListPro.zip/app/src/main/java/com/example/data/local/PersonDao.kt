package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.PersonEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface PersonDao {
    @Query("SELECT * FROM persons WHERE sheet_id = :sheetId ORDER BY primary_name ASC, id ASC")
    fun getPersonsBySheet(sheetId: Long): Flow<List<PersonEntity>>

    @Query("SELECT * FROM persons WHERE sheet_id = :sheetId ORDER BY primary_name ASC, id ASC")
    suspend fun getPersonsBySheetList(sheetId: Long): List<PersonEntity>

    @Query("SELECT * FROM persons ORDER BY sheet_id ASC, primary_name ASC, id ASC")
    fun getAllPersons(): Flow<List<PersonEntity>>

    @Query("SELECT * FROM persons ORDER BY sheet_id ASC, primary_name ASC, id ASC")
    suspend fun getAllPersonsList(): List<PersonEntity>

    @Query("SELECT * FROM persons WHERE id = :id LIMIT 1")
    suspend fun getPersonById(id: Long): PersonEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPerson(person: PersonEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPersons(persons: List<PersonEntity>): List<Long>

    @Update
    suspend fun updatePerson(person: PersonEntity)

    @Delete
    suspend fun deletePerson(person: PersonEntity)

    @Query("DELETE FROM persons WHERE id = :id")
    suspend fun deletePersonById(id: Long)

    @Query("DELETE FROM persons WHERE sheet_id = :sheetId")
    suspend fun deletePersonsBySheet(sheetId: Long)

    @Query("SELECT COUNT(*) FROM persons WHERE sheet_id = :sheetId")
    suspend fun countPersonsInSheet(sheetId: Long): Int

    @Query("SELECT COUNT(*) FROM persons")
    suspend fun countPersonsTotal(): Int

    @Query("SELECT COUNT(*) FROM persons WHERE sheet_id = :sheetId AND unique_card_id IS NOT NULL AND TRIM(unique_card_id) != ''")
    suspend fun countPersonsWithCardInSheet(sheetId: Long): Int

    @Query("SELECT COUNT(*) FROM persons WHERE sheet_id = :sheetId AND (unique_card_id IS NULL OR TRIM(unique_card_id) = '')")
    suspend fun countPersonsWithoutCardInSheet(sheetId: Long): Int

    @Query("DELETE FROM persons")
    suspend fun deleteAllPersons()
}
