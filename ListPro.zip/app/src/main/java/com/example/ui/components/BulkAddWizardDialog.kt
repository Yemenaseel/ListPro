package com.example.ui.components

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.FormatListNumbered
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.ColumnType
import com.example.data.model.SheetEntity
import com.example.ui.theme.AmberTertiary
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TealSecondary
import com.example.ui.viewmodel.BulkWizardRow
import com.example.ui.viewmodel.BulkWizardStatus
import kotlinx.coroutines.launch

/**
 * Metadata for a wizard column step
 */
private data class WizardColumnDef(
    val key: String,
    val title: String,
    val description: String,
    val isMandatory: Boolean,
    val icon: ImageVector,
    val placeholderExample: String
)

/**
 * Multi-Column Bulk Paste Wizard Dialog:
 * Iterates through all sheet columns step-by-step:
 * 1. Primary Names (Required, one per line)
 * 2. Card IDs (Optional, one per line)
 * 3..N. Dynamic Columns (one per line)
 * Final Step: Preview and duplicate check before bulk saving.
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun BulkAddWizardDialog(
    activeSheet: SheetEntity,
    onDismiss: () -> Unit,
    onValidateRows: suspend (
        sheetId: Long,
        names: List<String>,
        cards: List<String>,
        dynamicColumnsValues: Map<String, List<String>>
    ) -> List<BulkWizardRow>,
    onSaveRows: (sheetId: Long, rows: List<BulkWizardRow>, onComplete: (Int) -> Unit) -> Unit
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val scope = rememberCoroutineScope()

    // 1. Build columns list for this active sheet
    val dynamicColumns = activeSheet.getDynamicColumns()
    val wizardColumns = remember(activeSheet) {
        val list = mutableListOf<WizardColumnDef>()
        // Column 1: Primary Name
        list.add(
            WizardColumnDef(
                key = "primary_name",
                title = "الاسم الكامل (رباعي)",
                description = "إلزامي - الصق قائمة الأسماء هنا، كل سطر يمثل اسماً لشخص.",
                isMandatory = true,
                icon = Icons.Default.Person,
                placeholderExample = "محمد أحمد عبدالله علي\nأحمد خالد محمد حسن\nعبدالله سامي محمود صالح\nخالد حسن عبدالرحمن محمد\nيوسف علي أحمد محمود"
            )
        )
        // Column 2: Unique Card ID
        list.add(
            WizardColumnDef(
                key = "unique_card_id",
                title = "رقم البطاقة / الهوية",
                description = "اختياري - الصق أرقام البطاقات بالترتيب المطابق للأسماء (يمكن التخطي إذا لم تتوفر).",
                isMandatory = false,
                icon = Icons.Default.Badge,
                placeholderExample = "123456789012\n274819563027\n583104927615\n761392840516\n905217438629"
            )
        )
        // Dynamic columns defined in active sheet
        for (col in dynamicColumns) {
            val isNumber = col.type == ColumnType.NUMBER
            list.add(
                WizardColumnDef(
                    key = col.id,
                    title = col.name,
                    description = "الصق قيم '${col.name}' بالترتيب المطابق للأسماء (${if (isNumber) "أرقام" else "نصوص"}).",
                    isMandatory = false,
                    icon = if (isNumber) Icons.Default.FormatListNumbered else Icons.Default.TextFields,
                    placeholderExample = if (isNumber) "35\n28\n42\n19\n31" else "قيمة 1\nقيمة 2\nقيمة 3"
                )
            )
        }
        list
    }

    val totalSteps = wizardColumns.size + 1 // +1 for Preview step
    var currentStepIndex by remember { mutableIntStateOf(0) }

    // Map to store raw text for each column key
    val columnTexts = remember { mutableStateMapOf<String, String>() }

    // Preview state
    var isValidating by remember { mutableStateOf(false) }
    var isSaving by remember { mutableStateOf(false) }
    var previewRows by remember { mutableStateOf<List<BulkWizardRow>>(emptyList()) }

    // Helper: Split text to lines
    fun getLines(text: String): List<String> {
        return text.lines().map { it.trim() }.filter { it.isNotEmpty() }
    }

    val namesText = columnTexts["primary_name"] ?: ""
    val namesLines = remember(namesText) { getLines(namesText) }

    // Function to run preview validation
    fun triggerValidation() {
        isValidating = true
        scope.launch {
            val names = getLines(columnTexts["primary_name"] ?: "")
            val cards = getLines(columnTexts["unique_card_id"] ?: "")
            val dynamicMap = mutableMapOf<String, List<String>>()
            for (col in dynamicColumns) {
                dynamicMap[col.id] = getLines(columnTexts[col.id] ?: "")
            }

            val validated = onValidateRows(activeSheet.id, names, cards, dynamicMap)
            previewRows = validated
            isValidating = false
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = "معالج الإدخال الجماعي بالأعمدة",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "الكشف: ${activeSheet.title}",
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Outlined.Close, contentDescription = "إغلاق")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .imePadding()
            ) {
                // ==========================================
                // Stepper Progress Header
                // ==========================================
                val progress = (currentStepIndex + 1).toFloat() / totalSteps.toFloat()
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier.fillMaxWidth(),
                    color = NavyPrimary,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (currentStepIndex < wizardColumns.size)
                            "الخطوة ${currentStepIndex + 1} من $totalSteps: ${wizardColumns[currentStepIndex].title}"
                        else
                            "الخطوة الأخيرة: معاينة وتأكيد الحفظ",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = NavyPrimary
                        )
                    )

                    Surface(
                        color = NavyPrimary.copy(alpha = 0.1f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = "${namesLines.size} اسم مسجل",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = NavyPrimary,
                                fontWeight = FontWeight.SemiBold
                            ),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }

                // ==========================================
                // Screen Content: Column Entry OR Preview
                // ==========================================
                if (currentStepIndex < wizardColumns.size) {
                    val currentCol = wizardColumns[currentStepIndex]
                    val rawText = columnTexts[currentCol.key] ?: ""
                    val currentLines = getLines(rawText)

                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 16.dp)
                    ) {
                        Spacer(modifier = Modifier.height(6.dp))

                        // Column Banner Card
                        ElevatedCard(
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    modifier = Modifier.size(44.dp),
                                    shape = CircleShape,
                                    color = TealSecondary.copy(alpha = 0.12f)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = currentCol.icon,
                                            contentDescription = null,
                                            tint = TealSecondary,
                                            modifier = Modifier.size(24.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.width(12.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = currentCol.title,
                                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Surface(
                                            color = if (currentCol.isMandatory) ErrorRed.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant,
                                            shape = RoundedCornerShape(4.dp)
                                        ) {
                                            Text(
                                                text = if (currentCol.isMandatory) "إلزامي" else "اختياري",
                                                style = MaterialTheme.typography.labelSmall.copy(
                                                    color = if (currentCol.isMandatory) ErrorRed else MaterialTheme.colorScheme.onSurfaceVariant,
                                                    fontWeight = FontWeight.Bold
                                                ),
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = currentCol.description,
                                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Live Counts & Match Feedback Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "عدد الأسطر المدخلة: ${currentLines.size}",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                            )

                            if (currentStepIndex > 0 && namesLines.isNotEmpty()) {
                                val isMatched = currentLines.size == namesLines.size
                                val isSkipped = currentLines.isEmpty()

                                Surface(
                                    color = when {
                                        isSkipped -> MaterialTheme.colorScheme.surfaceVariant
                                        isMatched -> SuccessGreen.copy(alpha = 0.15f)
                                        else -> AmberTertiary.copy(alpha = 0.15f)
                                    },
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(
                                        text = when {
                                            isSkipped -> "فارغ (سيتم تركه بدون قيم)"
                                            isMatched -> "✓ متطابق مع الأسماء (${currentLines.size})"
                                            currentLines.size < namesLines.size -> "تنبيه: ${currentLines.size} سطر مقابل ${namesLines.size} اسم"
                                            else -> "تنبيه: ${currentLines.size} سطر أكثر من الأسماء"
                                        },
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = when {
                                                isSkipped -> MaterialTheme.colorScheme.onSurfaceVariant
                                                isMatched -> SuccessGreen
                                                else -> AmberTertiary
                                            },
                                            fontWeight = FontWeight.Bold
                                        ),
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Big Multi-line Text Area
                        OutlinedTextField(
                            value = rawText,
                            onValueChange = { columnTexts[currentCol.key] = it },
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f)
                                .testTag("wizard_input_${currentCol.key}"),
                            placeholder = {
                                Text(
                                    text = "الصق القيم هنا (سطر لكل شخص):\n\n${currentCol.placeholderExample}",
                                    style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.outline)
                                )
                            },
                            shape = RoundedCornerShape(14.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = NavyPrimary,
                                unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                            )
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // Quick Actions Bar: Paste, Clear, Skip
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            FilledTonalButton(
                                onClick = {
                                    val clip = clipboardManager.getText()?.text ?: ""
                                    if (clip.isNotBlank()) {
                                        columnTexts[currentCol.key] = clip
                                        Toast.makeText(context, "تم اللصق من الحافظة", Toast.LENGTH_SHORT).show()
                                    } else {
                                        Toast.makeText(context, "الحافظة فارغة", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.ContentPaste, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("لصق من الحافظة")
                            }

                            if (rawText.isNotBlank()) {
                                OutlinedButton(
                                    onClick = { columnTexts[currentCol.key] = "" },
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Icon(Icons.Default.Clear, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("مسح")
                                }
                            }

                            if (!currentCol.isMandatory) {
                                Spacer(modifier = Modifier.weight(1f))
                                TextButton(
                                    onClick = {
                                        columnTexts[currentCol.key] = ""
                                        currentStepIndex++
                                        if (currentStepIndex == wizardColumns.size) {
                                            triggerValidation()
                                        }
                                    }
                                ) {
                                    Icon(Icons.Default.SkipNext, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("تخطي هذا العمود")
                                }
                            }
                        }
                    }
                } else {
                    // ==========================================
                    // Final Step: Preview, Deduplication Check & Save
                    // ==========================================
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 16.dp)
                    ) {
                        Spacer(modifier = Modifier.height(8.dp))

                        if (isValidating) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    CircularProgressIndicator(color = NavyPrimary)
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text("جارٍ فحص ومطابقة السجلات والازدواجية...")
                                }
                            }
                        } else {
                            val validCount = previewRows.count { it.status == BulkWizardStatus.VALID }
                            val warningCount = previewRows.count { it.status == BulkWizardStatus.WARNING_CURRENT_SHEET_DUPLICATE }
                            val errorCount = previewRows.count {
                                it.status == BulkWizardStatus.ERROR_CARD_DUPLICATE ||
                                        it.status == BulkWizardStatus.ERROR_OTHER_SHEET_DUPLICATE ||
                                        it.status == BulkWizardStatus.ERROR_BATCH_DUPLICATE ||
                                        it.status == BulkWizardStatus.ERROR_EMPTY_NAME
                            }

                            // Summary Bar
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Surface(
                                    color = SuccessGreen.copy(alpha = 0.12f),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(10.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text(text = "$validCount", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = SuccessGreen))
                                        Text(text = "جاهز للإضافة", style = MaterialTheme.typography.labelSmall.copy(color = SuccessGreen))
                                    }
                                }

                                if (warningCount > 0) {
                                    Surface(
                                        color = AmberTertiary.copy(alpha = 0.12f),
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(10.dp),
                                            horizontalAlignment = Alignment.CenterHorizontally
                                        ) {
                                            Text(text = "$warningCount", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = AmberTertiary))
                                            Text(text = "تحذير تشابه", style = MaterialTheme.typography.labelSmall.copy(color = AmberTertiary))
                                        }
                                    }
                                }

                                if (errorCount > 0) {
                                    Surface(
                                        color = ErrorRed.copy(alpha = 0.12f),
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(10.dp),
                                            horizontalAlignment = Alignment.CenterHorizontally
                                        ) {
                                            Text(text = "$errorCount", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = ErrorRed))
                                            Text(text = "مرفوض / مكرر", style = MaterialTheme.typography.labelSmall.copy(color = ErrorRed))
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Text(
                                text = "معاينة ربط الأشخاص بالبيانات (${previewRows.size} شخص):",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            // List of parsed rows
                            LazyColumn(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                items(previewRows, key = { it.index }) { row ->
                                    ElevatedCard(
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    modifier = Modifier.weight(1f)
                                                ) {
                                                    Surface(
                                                        shape = CircleShape,
                                                        color = NavyPrimary.copy(alpha = 0.1f),
                                                        modifier = Modifier.size(28.dp)
                                                    ) {
                                                        Box(contentAlignment = Alignment.Center) {
                                                            Text(
                                                                text = "${row.index}",
                                                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                                                            )
                                                        }
                                                    }

                                                    Spacer(modifier = Modifier.width(8.dp))

                                                    Text(
                                                        text = row.name.ifBlank { "(اسم فارغ)" },
                                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                                    )
                                                }

                                                // Status indicator
                                                Surface(
                                                    color = when (row.status) {
                                                        BulkWizardStatus.VALID -> SuccessGreen.copy(alpha = 0.15f)
                                                        BulkWizardStatus.WARNING_CURRENT_SHEET_DUPLICATE -> AmberTertiary.copy(alpha = 0.15f)
                                                        else -> ErrorRed.copy(alpha = 0.15f)
                                                    },
                                                    shape = RoundedCornerShape(6.dp)
                                                ) {
                                                    Text(
                                                        text = when (row.status) {
                                                            BulkWizardStatus.VALID -> "سليم"
                                                            BulkWizardStatus.WARNING_CURRENT_SHEET_DUPLICATE -> "تحذير"
                                                            else -> "مرفوض"
                                                        },
                                                        style = MaterialTheme.typography.labelSmall.copy(
                                                            color = when (row.status) {
                                                                BulkWizardStatus.VALID -> SuccessGreen
                                                                BulkWizardStatus.WARNING_CURRENT_SHEET_DUPLICATE -> AmberTertiary
                                                                else -> ErrorRed
                                                            },
                                                            fontWeight = FontWeight.Bold
                                                        ),
                                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                    )
                                                }
                                            }

                                            Spacer(modifier = Modifier.height(6.dp))

                                            // Card & Dynamic Columns chips
                                            FlowRow(
                                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                                verticalArrangement = Arrangement.spacedBy(4.dp)
                                            ) {
                                                if (!row.card.isNullOrBlank()) {
                                                    Surface(
                                                        color = TealSecondary.copy(alpha = 0.1f),
                                                        shape = RoundedCornerShape(6.dp)
                                                    ) {
                                                        Text(
                                                            text = "البطاقة: ${row.card}",
                                                            style = MaterialTheme.typography.labelSmall.copy(color = TealSecondary, fontWeight = FontWeight.Bold),
                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                        )
                                                    }
                                                } else {
                                                    Surface(
                                                        color = MaterialTheme.colorScheme.surfaceVariant,
                                                        shape = RoundedCornerShape(6.dp)
                                                    ) {
                                                        Text(
                                                            text = "بدون بطاقة",
                                                            style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.outline),
                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                        )
                                                    }
                                                }

                                                for ((colId, v) in row.dynamicValues) {
                                                    val colName = dynamicColumns.find { it.id == colId }?.name ?: colId
                                                    Surface(
                                                        color = MaterialTheme.colorScheme.surfaceVariant,
                                                        shape = RoundedCornerShape(6.dp)
                                                    ) {
                                                        Text(
                                                            text = "$colName: $v",
                                                            style = MaterialTheme.typography.labelSmall,
                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                        )
                                                    }
                                                }
                                            }

                                            // Detailed status message
                                            if (row.status != BulkWizardStatus.VALID) {
                                                Spacer(modifier = Modifier.height(4.dp))
                                                Text(
                                                    text = row.statusMessage,
                                                    style = MaterialTheme.typography.bodySmall.copy(
                                                        color = if (row.status == BulkWizardStatus.WARNING_CURRENT_SHEET_DUPLICATE) AmberTertiary else ErrorRed,
                                                        fontWeight = FontWeight.Medium
                                                    )
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // ==========================================
                // Bottom Wizard Navigation Bar
                // ==========================================
                Surface(
                    shadowElevation = 8.dp,
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Back Button
                        if (currentStepIndex > 0) {
                            OutlinedButton(
                                onClick = { currentStepIndex-- },
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("السابق")
                            }
                        } else {
                            TextButton(onClick = onDismiss) {
                                Text("إلغاء المعالج")
                            }
                        }

                        // Next / Save Button
                        if (currentStepIndex < wizardColumns.size) {
                            Button(
                                onClick = {
                                    val currentCol = wizardColumns[currentStepIndex]
                                    if (currentCol.isMandatory && namesLines.isEmpty()) {
                                        Toast.makeText(context, "يرجى لصق أو كتابة الأسماء أولاً للمتابعة", Toast.LENGTH_SHORT).show()
                                        return@Button
                                    }
                                    currentStepIndex++
                                    if (currentStepIndex == wizardColumns.size) {
                                        triggerValidation()
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.testTag("wizard_next_button")
                            ) {
                                Text(if (currentStepIndex == wizardColumns.size - 1) "الانتقال للمعاينة" else "التالي")
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(16.dp))
                            }
                        } else {
                            // Final Save Button
                            val saveableRows = previewRows.filter {
                                it.status == BulkWizardStatus.VALID || it.status == BulkWizardStatus.WARNING_CURRENT_SHEET_DUPLICATE
                            }

                            Button(
                                onClick = {
                                    if (saveableRows.isEmpty()) {
                                        Toast.makeText(context, "لا توجد سجلات صالحة للحفظ", Toast.LENGTH_SHORT).show()
                                        return@Button
                                    }
                                    isSaving = true
                                    onSaveRows(activeSheet.id, saveableRows) { savedCount ->
                                        isSaving = false
                                        Toast.makeText(context, "تم حفظ $savedCount شخص بنجاح!", Toast.LENGTH_LONG).show()
                                        onDismiss()
                                    }
                                },
                                enabled = !isSaving && !isValidating && saveableRows.isNotEmpty(),
                                colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.testTag("wizard_save_all_button")
                            ) {
                                if (isSaving) {
                                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("جارٍ الحفظ...")
                                } else {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("تأكيد وحفظ (${saveableRows.size} شخص)")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
