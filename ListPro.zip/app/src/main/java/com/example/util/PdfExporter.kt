package com.example.util

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import androidx.core.content.res.ResourcesCompat
import com.example.R
import java.io.OutputStream

/**
 * PDF Exporter providing layout and typography matching the official registry format:
 * - Dynamic orientation: Landscape if columns > 4, Portrait if columns <= 4.
 * - Sheet title centered at the top in PT Bold Heading size 16.
 * - RTL table with auto-numbering column 'م' on the far right.
 * - Smart auto-fit for all columns based on header and cell content length.
 * - Strict cell clipping and auto-scaling to prevent any text overlapping or overflow.
 * - Table header in #D9D9D9 background with solid black borders and PT Bold Heading.
 * - Strict black grid borders for all data rows and cells.
 */
object PdfExporter {

    fun exportToPdf(
        context: Context,
        title: String,
        headers: List<String>,
        rows: List<List<String>>,
        outputStream: OutputStream
    ) {
        // Complete table columns: 'م' on the far right, followed by user columns
        val fullHeaders = mutableListOf<String>()
        fullHeaders.add("م")
        fullHeaders.addAll(headers)

        val totalColumns = fullHeaders.size

        // Orientation rule: > 4 columns -> Landscape (A4: 842x595), <= 4 columns -> Portrait (A4: 595x842)
        val isLandscape = totalColumns > 4
        val pageWidth = if (isLandscape) 842 else 595
        val pageHeight = if (isLandscape) 595 else 842
        val margin = if (isLandscape) 24f else 30f

        val document = PdfDocument()

        // Load PT Bold Heading font or fallback to bold
        val ptBoldHeadingTypeface = try {
            ResourcesCompat.getFont(context, R.font.pt_bold_heading) ?: Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        } catch (_: Exception) {
            Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }

        // Font sizes adjusted by column count to guarantee crisp legibility
        val headerFontSize = when {
            totalColumns > 8 -> 10f
            totalColumns > 5 -> 11f
            else -> 12.5f
        }

        val cellFontSize = when {
            totalColumns > 8 -> 8.5f
            totalColumns > 5 -> 9.5f
            else -> 10.5f
        }

        val rowHeight = when {
            totalColumns > 8 -> 23f
            totalColumns > 5 -> 24f
            else -> 26f
        }
        val headerHeight = 32f

        // Paints
        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            textSize = 15f
            typeface = ptBoldHeadingTypeface
            textAlign = Paint.Align.CENTER
        }

        val headerTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            textSize = headerFontSize
            typeface = ptBoldHeadingTypeface
            textAlign = Paint.Align.CENTER
        }

        val headerBgPaint = Paint().apply {
            color = Color.parseColor("#D9D9D9")
            style = Paint.Style.FILL
        }

        val cellBorderPaint = Paint().apply {
            color = Color.BLACK
            strokeWidth = 0.85f
            style = Paint.Style.STROKE
        }

        val cellTextBoldPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            textSize = cellFontSize
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }

        val cellTextRegularPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            textSize = cellFontSize
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        }

        val footerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.DKGRAY
            textSize = 8.5f
            textAlign = Paint.Align.CENTER
        }

        // Available table width
        val availableWidth = pageWidth - (margin * 2)

        // Calculate smart auto-fit column widths (proportional to header and content)
        val colWidths = calculateAutoFitColumnWidths(
            headers = fullHeaders,
            rows = rows,
            availableWidth = availableWidth,
            headerPaint = headerTextPaint,
            cellPaint = cellTextRegularPaint
        )

        val startY = 56f
        val bottomMargin = 28f

        val maxRowsPerPage = ((pageHeight - startY - bottomMargin - headerHeight) / rowHeight).toInt().coerceAtLeast(1)
        val totalPages = if (rows.isEmpty()) 1 else ((rows.size + maxRowsPerPage - 1) / maxRowsPerPage).coerceAtLeast(1)

        var currentRowIdx = 0

        for (pageNumber in 1..totalPages) {
            val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
            val page = document.startPage(pageInfo)
            val canvas = page.canvas

            // 1. Title: Centered at top, PT Bold Heading
            canvas.drawText(title, pageWidth / 2f, 38f, titlePaint)

            // 2. Table Header
            var y = startY
            drawTableHeader(
                canvas = canvas,
                headers = fullHeaders,
                colWidths = colWidths,
                startY = y,
                headerHeight = headerHeight,
                margin = margin,
                pageWidth = pageWidth,
                bgPaint = headerBgPaint,
                borderPaint = cellBorderPaint,
                textPaint = headerTextPaint
            )
            y += headerHeight

            // 3. Table Rows
            val rowsForThisPage = minOf(maxRowsPerPage, rows.size - currentRowIdx)
            for (i in 0 until rowsForThisPage) {
                val rowNumber = currentRowIdx + 1
                val rawRowData = rows[currentRowIdx]

                // Full row: [rowNumber] + rawRowData
                val fullRowData = mutableListOf<String>()
                fullRowData.add(rowNumber.toString())
                fullRowData.addAll(rawRowData)

                drawTableRow(
                    canvas = canvas,
                    fullRowData = fullRowData,
                    colWidths = colWidths,
                    startY = y,
                    rowHeight = rowHeight,
                    margin = margin,
                    pageWidth = pageWidth,
                    borderPaint = cellBorderPaint,
                    boldPaint = cellTextBoldPaint,
                    regularPaint = cellTextRegularPaint
                )

                y += rowHeight
                currentRowIdx++
            }

            // 4. Footer
            val footerText = "صفحة $pageNumber من $totalPages"
            canvas.drawText(footerText, pageWidth / 2f, pageHeight - 12f, footerPaint)

            document.finishPage(page)
        }

        document.writeTo(outputStream)
        document.close()
    }

    /**
     * Calculates column widths with smart auto-fit:
     * - Column 0 ('م'): Compact fixed width (approx 26-28pt).
     * - Columns 1..N: Proportional distribution based on measured header and row data,
     *   ensuring the table exactly spans availableWidth without clipping or overflowing.
     */
    private fun calculateAutoFitColumnWidths(
        headers: List<String>,
        rows: List<List<String>>,
        availableWidth: Float,
        headerPaint: Paint,
        cellPaint: Paint
    ): List<Float> {
        val count = headers.size
        if (count == 0) return emptyList()
        if (count == 1) return listOf(availableWidth)

        // Column 0 is serial number 'م'
        val serialWidth = 28f
        val remainingAvailable = (availableWidth - serialWidth).coerceAtLeast(100f)

        val desiredWidths = FloatArray(count)
        desiredWidths[0] = serialWidth

        val sampleLimit = minOf(rows.size, 100)

        for (col in 1 until count) {
            val headerText = headers[col]
            val headerW = headerPaint.measureText(headerText) + 10f

            var maxDataW = 0f
            for (r in 0 until sampleLimit) {
                val row = rows[r]
                val cellText = if (col - 1 in row.indices) row[col - 1] else ""
                if (cellText.isNotBlank()) {
                    val w = cellPaint.measureText(cellText) + 8f
                    if (w > maxDataW) maxDataW = w
                }
            }

            var desired = maxOf(headerW, maxDataW)

            // Intelligent weighting by column semantics:
            val lowerH = headerText.trim()
            when {
                lowerH.contains("اسم") && !lowerH.contains("ام") -> {
                    // Full Name column: highest priority
                    desired = maxOf(desired, 120f)
                }
                lowerH.contains("بطاق") || lowerH.contains("هوي") -> {
                    // Card / ID: 10-14 digits
                    desired = desired.coerceIn(70f, 95f)
                }
                lowerH.contains("هاتف") || lowerH.contains("تلفون") || lowerH.contains("جوال") || lowerH.contains("رقم") -> {
                    // Phone / Number
                    desired = desired.coerceIn(65f, 85f)
                }
                lowerH.contains("تاريخ") || lowerH.contains("ميلاد") -> {
                    // Date
                    desired = desired.coerceIn(60f, 80f)
                }
                lowerH.contains("فصيل") || lowerH.contains("دم") -> {
                    // Blood Group: short
                    desired = desired.coerceIn(36f, 50f)
                }
                lowerH.contains("محافظ") || lowerH.contains("سكن") || lowerH.contains("مدين") -> {
                    // City / Governorate
                    desired = desired.coerceIn(60f, 90f)
                }
                else -> {
                    desired = maxOf(desired, 50f)
                }
            }

            desiredWidths[col] = desired
        }

        // Sum desired for cols 1..count-1
        var sumDesiredRemaining = 0f
        for (col in 1 until count) {
            sumDesiredRemaining += desiredWidths[col]
        }

        val result = FloatArray(count)
        result[0] = serialWidth

        val scale = remainingAvailable / sumDesiredRemaining
        for (col in 1 until count) {
            result[col] = desiredWidths[col] * scale
        }

        // Adjust any fractional rounding difference into the widest column
        val finalSum = result.sum()
        val diff = availableWidth - finalSum
        val widestCol = (1 until count).maxByOrNull { result[it] } ?: 1
        result[widestCol] += diff

        return result.toList()
    }

    private fun drawTableHeader(
        canvas: Canvas,
        headers: List<String>,
        colWidths: List<Float>,
        startY: Float,
        headerHeight: Float,
        margin: Float,
        pageWidth: Int,
        bgPaint: Paint,
        borderPaint: Paint,
        textPaint: Paint
    ) {
        val totalTableWidth = colWidths.sum()
        val rightX = (pageWidth - margin)

        // Draw header background rectangle
        canvas.drawRect(
            rightX - totalTableWidth,
            startY,
            rightX,
            startY + headerHeight,
            bgPaint
        )

        // Draw cells from Right to Left (RTL)
        var currentRight = rightX
        for (i in headers.indices) {
            val w = colWidths[i]
            val left = currentRight - w
            val right = currentRight
            val top = startY
            val bottom = startY + headerHeight

            // Cell border
            canvas.drawRect(left, top, right, bottom, borderPaint)

            // Header text with auto-fit and cell clipping
            val text = headers[i]
            drawAutoFitText(
                canvas = canvas,
                text = text,
                left = left,
                top = top,
                right = right,
                bottom = bottom,
                paint = textPaint,
                align = Paint.Align.CENTER,
                paddingHorizontal = 3f,
                allowScaling = true
            )

            currentRight -= w
        }
    }

    private fun drawTableRow(
        canvas: Canvas,
        fullRowData: List<String>,
        colWidths: List<Float>,
        startY: Float,
        rowHeight: Float,
        margin: Float,
        pageWidth: Int,
        borderPaint: Paint,
        boldPaint: Paint,
        regularPaint: Paint
    ) {
        val rightX = (pageWidth - margin)
        var currentRight = rightX

        for (i in colWidths.indices) {
            val w = colWidths[i]
            val left = currentRight - w
            val right = currentRight
            val top = startY
            val bottom = startY + rowHeight

            // Draw crisp solid black border
            canvas.drawRect(left, top, right, bottom, borderPaint)

            val text = if (i < fullRowData.size) fullRowData[i] else ""
            if (text.isNotBlank()) {
                when (i) {
                    0 -> {
                        // 'م' column: Centered, Bold
                        drawAutoFitText(
                            canvas = canvas,
                            text = text,
                            left = left,
                            top = top,
                            right = right,
                            bottom = bottom,
                            paint = boldPaint,
                            align = Paint.Align.CENTER,
                            paddingHorizontal = 2f
                        )
                    }
                    1 -> {
                        // 'الاسم' column: Bold, Right-aligned with padding
                        drawAutoFitText(
                            canvas = canvas,
                            text = text,
                            left = left,
                            top = top,
                            right = right,
                            bottom = bottom,
                            paint = boldPaint,
                            align = Paint.Align.RIGHT,
                            paddingHorizontal = 5f
                        )
                    }
                    2 -> {
                        // 'رقم البطاقة': Centered, Bold
                        drawAutoFitText(
                            canvas = canvas,
                            text = text,
                            left = left,
                            top = top,
                            right = right,
                            bottom = bottom,
                            paint = boldPaint,
                            align = Paint.Align.CENTER,
                            paddingHorizontal = 3f
                        )
                    }
                    else -> {
                        // Custom dynamic columns: Centered, Regular
                        drawAutoFitText(
                            canvas = canvas,
                            text = text,
                            left = left,
                            top = top,
                            right = right,
                            bottom = bottom,
                            paint = regularPaint,
                            align = Paint.Align.CENTER,
                            paddingHorizontal = 3f
                        )
                    }
                }
            }

            currentRight -= w
        }
    }

    /**
     * Draws text strictly clipped within cell bounds, automatically scaling font size down
     * if the text is wider than the cell, and cleanly truncating with ellipsis if needed.
     * Prevents any text bleeding or overlapping between columns.
     */
    private fun drawAutoFitText(
        canvas: Canvas,
        text: String,
        left: Float,
        top: Float,
        right: Float,
        bottom: Float,
        paint: Paint,
        align: Paint.Align,
        paddingHorizontal: Float = 3f,
        allowScaling: Boolean = true
    ) {
        if (text.isBlank()) return
        val cellWidth = right - left
        val cellHeight = bottom - top
        val usableWidth = (cellWidth - (paddingHorizontal * 2)).coerceAtLeast(1f)

        canvas.save()
        // Clip strictly to cell boundaries
        canvas.clipRect(left + 0.5f, top + 0.5f, right - 0.5f, bottom - 0.5f)

        val originalTextSize = paint.textSize
        var measuredW = paint.measureText(text)

        if (allowScaling && measuredW > usableWidth) {
            val minTextSize = originalTextSize * 0.70f // down to 70% font size
            val idealSize = originalTextSize * (usableWidth / measuredW)
            paint.textSize = idealSize.coerceAtLeast(minTextSize)
            measuredW = paint.measureText(text)
        }

        // Ellipsize if still wider after auto-scale
        val displayText = if (measuredW > usableWidth) {
            ellipsize(text, usableWidth, paint)
        } else {
            text
        }

        paint.textAlign = align
        val yPos = top + (cellHeight / 2f) - ((paint.descent() + paint.ascent()) / 2f)
        val xPos = when (align) {
            Paint.Align.RIGHT -> right - paddingHorizontal
            Paint.Align.CENTER -> left + (cellWidth / 2f)
            Paint.Align.LEFT -> left + paddingHorizontal
        }

        canvas.drawText(displayText, xPos, yPos, paint)

        // Restore paint text size & canvas clip
        paint.textSize = originalTextSize
        canvas.restore()
    }

    private fun ellipsize(text: String, maxWidth: Float, paint: Paint): String {
        if (paint.measureText(text) <= maxWidth) return text
        val ellipsis = "..."
        val ellipsisWidth = paint.measureText(ellipsis)
        if (ellipsisWidth >= maxWidth) return ""

        var low = 0
        var high = text.length
        var bestIndex = 0

        while (low <= high) {
            val mid = (low + high) / 2
            val sub = text.substring(0, mid) + ellipsis
            if (paint.measureText(sub) <= maxWidth) {
                bestIndex = mid
                low = mid + 1
            } else {
                high = mid - 1
            }
        }
        return if (bestIndex > 0) text.substring(0, bestIndex) + ellipsis else ""
    }
}
