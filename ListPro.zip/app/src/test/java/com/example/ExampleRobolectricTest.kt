package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.ColumnDefinition
import com.example.data.model.ColumnType
import com.example.data.model.PersonEntity
import com.example.data.model.SheetEntity
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("إدارة الكشوفات", appName)
  }

  @Test
  fun testRoomEntities_DynamicColumnsSerialization() {
    val cols = listOf(
      ColumnDefinition("col_1", "اسم الأم", ColumnType.TEXT),
      ColumnDefinition("col_2", "العمر", ColumnType.NUMBER)
    )
    val sheet = SheetEntity(
      id = 1,
      title = "كشف الاختبار",
      is_main = true
    ).withDynamicColumns(cols)

    val parsedCols = sheet.getDynamicColumns()
    assertEquals(2, parsedCols.size)
    assertEquals("col_1", parsedCols[0].id)
    assertEquals("اسم الأم", parsedCols[0].name)
    assertEquals(ColumnType.TEXT, parsedCols[0].type)
    assertEquals("العمر", parsedCols[1].name)
    assertEquals(ColumnType.NUMBER, parsedCols[1].type)
  }

  @Test
  fun testRoomEntities_PersonDynamicDataMap() {
    val dynamicData = mapOf("col_1" to "فاطمة", "col_2" to "30")
    val person = PersonEntity(
      id = 10,
      sheet_id = 1,
      primary_name = "محمد أحمد علي",
      unique_card_id = "12345678"
    ).withDynamicData(dynamicData)

    val retrievedData = person.getDynamicData()
    assertEquals("فاطمة", retrievedData["col_1"])
    assertEquals("30", retrievedData["col_2"])
  }
}
