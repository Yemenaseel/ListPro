package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.PersonEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface PersonDao {
    @Query("SELECT * FROM persons WHERE sheet_id = :sheetId AND is_deleted = 0 ORDER BY primary_name ASC, id ASC")
    fun getPersonsBySheet(sheetId: Long): Flow<List<PersonEntity>>

    @Query("SELECT * FROM persons WHERE sheet_id = :sheetId AND is_deleted = 0 ORDER BY primary_name ASC, id ASC")
    suspend fun getPersonsBySheetList(sheetId: Long): List<PersonEntity>

    @Query("SELECT * FROM persons WHERE is_deleted = 0 ORDER BY sheet_id ASC, primary_name ASC, id ASC")
    fun getAllPersons(): Flow<List<PersonEntity>>

    @Query("SELECT * FROM persons WHERE is_deleted = 0 ORDER BY sheet_id ASC, primary_name ASC, id ASC")
    suspend fun getAllPersonsList(): List<PersonEntity>

    @Query("SELECT * FROM persons WHERE is_deleted = 1 ORDER BY deleted_at DESC, id DESC")
    fun getDeletedPersons(): Flow<List<PersonEntity>>

    @Query("SELECT COUNT(*) FROM persons WHERE is_deleted = 1")
    fun countDeletedPersons(): Flow<Int>

    @Query("SELECT * FROM persons WHERE id = :id LIMIT 1")
    suspend fun getPersonById(id: Long): PersonEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPerson(person: PersonEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPersons(persons: List<PersonEntity>): List<Long>

    @Update
    suspend fun updatePerson(person: PersonEntity)

    // Soft delete (Recycle Bin)
    @Query("UPDATE persons SET is_deleted = 1, deleted_at = :deletedAt WHERE id = :id")
    suspend fun softDeletePerson(id: Long, deletedAt: Long = System.currentTimeMillis())

    @Query("UPDATE persons SET is_deleted = 1, deleted_at = :deletedAt WHERE id IN (:ids)")
    suspend fun softDeletePersons(ids: List<Long>, deletedAt: Long = System.currentTimeMillis())

    // Restore from Recycle Bin
    @Query("UPDATE persons SET is_deleted = 0, deleted_at = NULL WHERE id = :id")
    suspend fun restorePerson(id: Long)

    @Query("UPDATE persons SET is_deleted = 0, deleted_at = NULL WHERE id IN (:ids)")
    suspend fun restorePersons(ids: List<Long>)

    // Permanent delete
    @Query("DELETE FROM persons WHERE id = :id")
    suspend fun deletePermanently(id: Long)

    @Query("DELETE FROM persons WHERE is_deleted = 1")
    suspend fun emptyRecycleBin()

    @Query("DELETE FROM persons WHERE sheet_id = :sheetId")
    suspend fun deletePersonsBySheet(sheetId: Long)

    @Query("DELETE FROM persons")
    suspend fun deleteAllPersons()

    // Bulk Move between sheets
    @Query("UPDATE persons SET sheet_id = :targetSheetId WHERE id IN (:ids)")
    suspend fun movePersonsToSheet(ids: List<Long>, targetSheetId: Long)

    // Statistics queries
    @Query("SELECT COUNT(*) FROM persons WHERE sheet_id = :sheetId AND is_deleted = 0")
    suspend fun countPersonsInSheet(sheetId: Long): Int

    @Query("SELECT COUNT(*) FROM persons WHERE is_deleted = 0")
    suspend fun countPersonsTotal(): Int

    @Query("SELECT COUNT(*) FROM persons WHERE sheet_id = :sheetId AND is_deleted = 0 AND unique_card_id IS NOT NULL AND TRIM(unique_card_id) != ''")
    suspend fun countPersonsWithCardInSheet(sheetId: Long): Int

    @Query("SELECT COUNT(*) FROM persons WHERE sheet_id = :sheetId AND is_deleted = 0 AND (unique_card_id IS NULL OR TRIM(unique_card_id) = '')")
    suspend fun countPersonsWithoutCardInSheet(sheetId: Long): Int
}
